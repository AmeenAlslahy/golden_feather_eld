import 'package:flutter_test/flutter_test.dart';
import 'package:golden_feather_eld/backend/contracts/hardware_backend.dart';
import 'package:golden_feather_eld/backend/contracts/vehicle_backend.dart';
import 'package:golden_feather_eld/core/network/network_info.dart';
import 'package:golden_feather_eld/core/result/result.dart';
import 'package:golden_feather_eld/features/vehicle/data/repositories/vehicle_repository_impl.dart';
import 'package:mocktail/mocktail.dart';

class MockVehicleBackend extends Mock implements VehicleBackend {}
class MockHardwareBackend extends Mock implements HardwareBackend {}
class MockNetworkInfo extends Mock implements NetworkInfo {}

void main() {
  late MockVehicleBackend mockBackend;
  late MockHardwareBackend mockHardwareBackend;
  late MockNetworkInfo mockNetworkInfo;
  late VehicleRepositoryImpl repository;

  setUp(() {
    mockBackend = MockVehicleBackend();
    mockHardwareBackend = MockHardwareBackend();
    mockNetworkInfo = MockNetworkInfo();
    repository = VehicleRepositoryImpl(
      vehicleBackend: mockBackend,
      hardwareBackend: mockHardwareBackend,
      networkInfo: mockNetworkInfo,
    );

    when(() => mockNetworkInfo.isConnected).thenReturn(true);
  });

  group('VehicleRepositoryImpl Tests', () {
    test('successfully parses list of vehicles from getMyVehicles', () async {
      when(() => mockBackend.getMyVehicles(driverId: any(named: 'driverId')))
          .thenAnswer((_) async => ok({
                'data': [
                  {
                    'id': 1001,
                    'name': 'شاحنة فولفو - Truck #1001',
                    'vin': '1FUJGLDR5PL100101',
                    'model': 'Volvo FH16',
                    'assignedToCurrentDriver': true,
                    'currentlyUsedByCurrentDriver': false,
                  },
                  {
                    'id': 1002,
                    'name': 'مرسيدس أكتروس - Truck #1002',
                    'vin': '4V4NC9EH1PN100202',
                    'model': 'Actros 1845',
                    'assignedToCurrentDriver': false,
                    'currentlyUsedByCurrentDriver': false,
                  }
                ]
              }));

      final result = await repository.getVehicles();

      expect(result.isRight(), isTrue);
      result.fold(
        (failure) => fail('Should not fail: $failure'),
        (vehicles) {
          expect(vehicles.length, equals(2));
          expect(vehicles[0].id, equals('1001'));
          expect(vehicles[0].name, equals('شاحنة فولفو - Truck #1001'));
          expect(vehicles[0].isAssigned, isTrue);
          expect(vehicles[1].id, equals('1002'));
          expect(vehicles[1].isAssigned, isFalse);
        },
      );
    });
  });
}
