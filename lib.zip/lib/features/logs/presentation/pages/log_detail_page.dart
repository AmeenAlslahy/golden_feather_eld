import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_radius.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/eld_card.dart';
import '../../../../routes.dart';
import '../providers/logs_provider.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import 'package:signature/signature.dart';
import '../../../vehicle/domain/entities/vehicle.dart';
import '../widgets/log_graph.dart';
import '../widgets/vehicle_picker_dialog.dart';
import '../widgets/codriver_picker_dialog.dart';
import 'inspection_preview_page.dart';
import 'trailers_page.dart';
import 'shipping_documents_page.dart';
import '../../domain/entities/daily_log.dart';
import 'edit_log_page.dart';

/// شاشة تفاصيل اليوم
class LogDetailPage extends ConsumerStatefulWidget {
  const LogDetailPage({super.key});

  @override
  ConsumerState<LogDetailPage> createState() => _LogDetailPageState();
}

class _LogDetailPageState extends ConsumerState<LogDetailPage> {
  int _currentIndex = 0;
  late SignatureController _signatureController;

  bool _isInit = false;

  @override
  void initState() {
    super.initState();
    // سيتم تهيئة الألوان من Theme في didChangeDependencies
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInit) {
      _signatureController = SignatureController(
        penStrokeWidth: 3,
        penColor: Theme.of(context).colorScheme.primary,
        exportBackgroundColor: Theme.of(context).colorScheme.surface,
      );
      _isInit = true;
    }
  }

  @override
  void dispose() {
    _signatureController.dispose();
    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    final selectedLog = ref.watch(logsProvider).selectedLog;
//     final dashboard = ref.watch(dashboardDataProvider);

    if (selectedLog == null) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Center(child: Text(context.loc.noData)),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.surface),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          selectedLog.formattedDate,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: AppColors.surface,
              ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.visibility, color: AppColors.surface),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const InspectionPreviewPage(),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.add, color: AppColors.surface, size: 28),
            onPressed: () async {
              final successMsg = context.loc.eventAddedSuccess;
              // 🆕 إنشاء حدث جديد فارغ
              final newEvent = LogEvent(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                status: 'OFF',
                statusArabic: 'خارج الخدمة',
                startTime: DateTime.now(),
                duration: Duration.zero,
                location: '',
              );

              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditLogPage(
                    event: newEvent,
                    isNewEvent: true, // 🆕 وضع الإضافة
                  ),
                ),
              );

              // إذا تم الحفظ بنجاح، أضف الحدث للسجل
              if (result == true && mounted) {
                ref.read(logsProvider.notifier).addEvent(newEvent);
                if (mounted) {
                  // ignore: use_build_context_synchronously
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(successMsg),
                      backgroundColor: AppColors.successGreen,
                    ),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: _buildBodyContent(selectedLog),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          border: Border(
              top: BorderSide(color: Theme.of(context).dividerColor, width: 1)),
        ),
        child: BottomNavigationBar(
          backgroundColor: Theme.of(context).colorScheme.surface,
          selectedItemColor: Theme.of(context).colorScheme.primary,
          unselectedItemColor: Theme.of(context).colorScheme.onSurfaceVariant,
          currentIndex: _currentIndex,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.access_time),
              label: context.loc.events,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.assignment),
              label: context.loc.form,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.check_circle_outline),
              label: context.loc.certify,
            ),
          ],
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
        ),
      ),
    );
  }

  Widget _buildBodyContent(dynamic selectedLog) {
    switch (_currentIndex) {
      case 0:
        return _buildEventsTab(selectedLog);
      case 1:
        return _buildFormTab();
      case 2:
        return _buildCertifyTab();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildEventsTab(dynamic selectedLog) {
    return Column(
      children: [
        // الرسم البياني المبسط
        LogGraph(events: selectedLog.events),
        // قائمة الأحداث
        Expanded(
          child: Container(
            color: Theme.of(context).colorScheme.surface,
            child: ListView.builder(
              padding: EdgeInsets.zero,
              itemCount: selectedLog.events.length,
              itemBuilder: (context, index) {
                final event = selectedLog.events[index];
                return _LogEventTile(
                  event: event,
                  onTap: () {
                    ref
                        .read(logsProvider.notifier)
                        .toggleEventExpansion(event.id);
                  },
                  onEdit: () {
                    context.push(AppRoutes.editLog.replaceAll(':id', event.id),
                        extra: event);
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFormTab() {
    final dashboard = ref.watch(dashboardDataProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildFormRow(context.loc.driver, dashboard.driverName),
          Divider(color: Theme.of(context).dividerColor, height: 1),
          _buildFormRow(
            context.loc.vehicles,
            dashboard.vehicleDisplayName,
            onEdit: () async {
              final vehicle = await showDialog<Vehicle>(
                context: context,
                builder: (_) =>
                    VehiclePickerDialog(currentVehicleId: dashboard.vehicleId),
              );
              if (vehicle != null && mounted) {
                ref.read(dashboardDataProvider.notifier).updateVehicle(vehicle);
              }
            },
          ),
          Divider(color: Theme.of(context).dividerColor, height: 1),
          _buildFormRow(
            context.loc.trailers,
            dashboard.trailerId ?? '-',
            onEdit: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TrailersPage()),
              );
            },
          ),
          Divider(color: Theme.of(context).dividerColor, height: 1),
          _buildFormRow(
            context.loc.shippingDocuments,
            dashboard.shippingDocuments ?? '-',
            onEdit: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const ShippingDocumentsPage()),
              );
            },
          ),
          Divider(color: Theme.of(context).dividerColor, height: 1),
          _buildFormRow(
            context.loc.coDriver,
            dashboard.coDriverName ?? '-',
            onEdit: () async {
              final coDriver = await showDialog<CoDriver>(
                context: context,
                builder: (_) => CoDriverPickerDialog(
                    currentCoDriverId: dashboard.coDriverId ?? 'none'),
              );
              if (coDriver != null && mounted) {
                ref
                    .read(dashboardDataProvider.notifier)
                    .updateCoDriver(coDriver);
              }
            },
          ),
          const SizedBox(height: AppSpacing.xl),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.successGreen,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.button),
              ),
              elevation: 0,
            ),
            child: Text(
              context.loc.saveButton,
              style: const TextStyle(
                fontSize: AppTypography.bodySize,
                fontWeight: AppTypography.bold,
                color: AppColors.surface,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormRow(String title, String value, {VoidCallback? onEdit}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: AppTypography.bodySize,
                    fontWeight: AppTypography.semiBold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: AppTypography.subtitleSize,
                  ),
                ),
              ],
            ),
          ),
          if (onEdit != null)
            IconButton(
              icon: const Icon(Icons.edit, size: 20),
              onPressed: onEdit,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
        ],
      ),
    );
  }

  Widget _buildCertifyTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        children: [
          // مربع الصورة / التوقيع
          EldCard(
            child: Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.imagePlaceholder),
                border: Border.all(
                  color: AppColors.border,
                  width: 1,
                  style: BorderStyle.solid,
                ),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          context.loc.imageNotAvailable,
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                                fontWeight: AppTypography.bold,
                              ),
                        ),
                      ],
                    ),
                  ),
                  Signature(
                    controller: _signatureController,
                    height: 200,
                    backgroundColor: AppColors.transparent,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.sm),

          // Clear signature
          InkWell(
            onTap: () {
              _signatureController.clear();
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                context.loc.clearSignature,
                style: const TextStyle(
                  fontSize: AppTypography.subtitleSize,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xl),

          // نص التصديق القانوني
          Text(
            context.loc.certifyDeclaration,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: AppTypography.bodySize,
              fontWeight: AppTypography.regular,
              height: 1.5,
            ),
          ),
          const SizedBox(height: AppSpacing.xl),

          // زران
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: null,
              style: ElevatedButton.styleFrom(
                disabledBackgroundColor: AppColors.border,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.button),
                ),
                elevation: 0,
              ),
              child: Text(
                context.loc.notReady,
                style: const TextStyle(
                  fontSize: AppTypography.bodySize,
                  fontWeight: AppTypography.bold,
                  color: AppColors.surface,
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                // تصديق
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.successGreen,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.button),
                ),
                elevation: 0,
              ),
              child: Text(
                context.loc.agree,
                style: const TextStyle(
                  fontSize: AppTypography.bodySize,
                  fontWeight: AppTypography.bold,
                  color: AppColors.surface,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// عنصر حدث في القائمة
class _LogEventTile extends StatelessWidget {
  final dynamic event;
  final VoidCallback onTap;
  final VoidCallback onEdit;

  const _LogEventTile({
    required this.event,
    required this.onTap,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    final isExpanded = event.isExpanded ?? false;
    final color = _getStatusColor(event.status);

    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          border: Border(
              bottom:
                  BorderSide(color: Theme.of(context).dividerColor, width: 1)),
        ),
        padding: const EdgeInsets.symmetric(
            vertical: AppSpacing.sm, horizontal: AppSpacing.md),
        child: Column(
          children: [
            // الصف الرئيسي
            Row(
              children: [
                // الشريط اللوني الجانبي + اسم الحالة
                Container(
                  width: 4,
                  height: 20,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                SizedBox(
                  width: 32,
                  child: Text(
                    event.status,
                    style: const TextStyle(
                      fontSize: AppTypography.bodySize,
                      fontWeight: AppTypography.semiBold,
                    ),
                  ),
                ),

                // الوقت
                Expanded(
                  flex: 2,
                  child: Text(
                    '${event.formattedStartTime} ${DateTime.now().timeZoneName.substring(0, 3).toUpperCase()}',
                    style: const TextStyle(
                      fontSize: AppTypography.bodySize,
                    ),
                  ),
                ),

                // المدة
                Expanded(
                  flex: 2,
                  child: Text(
                    event.formattedDuration,
                    style: const TextStyle(
                      fontSize: AppTypography.bodySize,
                    ),
                  ),
                ),

                // أيقونة القلم
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(
                    Icons.edit,
                    size: 22,
                  ),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            // المحتوى الموسع
            AnimatedCrossFade(
              firstChild: const SizedBox.shrink(),
              secondChild: _ExpandedContent(event: event),
              crossFadeState: isExpanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 300),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'D':
        return AppColors.successGreen;
      case 'ON':
        return AppColors.warningYellow;
      case 'SB':
        return AppColors.primaryBlue;
      case 'OFF':
        return AppColors.textSecondary;
      default:
        return AppColors.textSecondary;
    }
  }
}

/// المحتوى الموسع للحدث
class _ExpandedContent extends StatelessWidget {
  final dynamic event;

  const _ExpandedContent({required this.event});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        top: AppSpacing.md,
        left: AppSpacing.md,
        right: AppSpacing.md,
      ),
      child: Column(
        children: [
          const Divider(color: AppColors.border),
          const SizedBox(height: AppSpacing.sm),
          _expandedRow(context.loc.startTime, event.formattedStartTime),
          _expandedRow(context.loc.duration, event.formattedDuration),
          _expandedRow(context.loc.location, event.location),
          if (event.odometer != null)
            _expandedRow(context.loc.odometer,
                '${event.odometer!.toStringAsFixed(1)} ${context.loc.miles}'),
          if (event.engineHours != null)
            _expandedRow(context.loc.engineHours,
                '${event.engineHours!.toStringAsFixed(1)} ${context.loc.hour}'),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }

  Widget _expandedRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.xs),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: const TextStyle(
              fontSize: AppTypography.captionSize,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: AppTypography.captionSize,
                fontWeight: AppTypography.semiBold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
