import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/datasources/logs_mock_data.dart';
import '../../domain/entities/daily_log.dart';

/// حالة شاشة السجلات
class LogsState {
  final List<DailyLog> logs;
  final DailyLog? selectedLog;
  final bool isLoading;

  const LogsState({
    this.logs = const [],
    this.selectedLog,
    this.isLoading = false,
  });

  LogsState copyWith({
    List<DailyLog>? logs,
    DailyLog? selectedLog,
    bool? isLoading,
  }) {
    return LogsState(
      logs: logs ?? this.logs,
      selectedLog: selectedLog ?? this.selectedLog,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

/// مزود السجلات
final logsProvider = StateNotifierProvider<LogsNotifier, LogsState>((ref) {
  return LogsNotifier();
});

class LogsNotifier extends StateNotifier<LogsState> {
  LogsNotifier() : super(const LogsState()) {
    _loadLogs();
  }

  void _loadLogs() {
    state = state.copyWith(isLoading: true);
    // محاكاة تحميل
    Future.delayed(const Duration(milliseconds: 500), () {
      final logs = LogsMockData.getLogs();
      state = LogsState(logs: logs, isLoading: false);
    });
  }

  /// تحديد سجل محدد للتفاصيل
  void selectLog(DailyLog log) {
    state = state.copyWith(selectedLog: log);
  }

  /// تبديل توسيع حدث
  void toggleEventExpansion(String eventId) {
    if (state.selectedLog == null) return;

    final updatedEvents = state.selectedLog!.events.map((e) {
      if (e.id == eventId) {
        return e.copyWith(isExpanded: !e.isExpanded);
      }
      return e;
    }).toList();

    final updatedLog = DailyLog(
      id: state.selectedLog!.id,
      date: state.selectedLog!.date,
      totalDrivingHours: state.selectedLog!.totalDrivingHours,
      isFormComplete: state.selectedLog!.isFormComplete,
      isCertified: state.selectedLog!.isCertified,
      events: updatedEvents,
    );

    state = state.copyWith(selectedLog: updatedLog);
  }

  /// تصديق السجل
  void certifyLog(String logId) {
    final updatedLogs = state.logs.map((log) {
      if (log.id == logId) {
        return DailyLog(
          id: log.id,
          date: log.date,
          totalDrivingHours: log.totalDrivingHours,
          isFormComplete: log.isFormComplete,
          isCertified: true,
          events: log.events,
        );
      }
      return log;
    }).toList();

    state = state.copyWith(logs: updatedLogs);
  }

  /// إضافة حدث جديد للسجل المحدد
  void addEvent(LogEvent event) {
    if (state.selectedLog == null) return;

    final updatedEvents = <LogEvent>[...state.selectedLog!.events, event];
    
    final updatedLog = DailyLog(
      id: state.selectedLog!.id,
      date: state.selectedLog!.date,
      totalDrivingHours: state.selectedLog!.totalDrivingHours,
      isFormComplete: state.selectedLog!.isFormComplete,
      isCertified: state.selectedLog!.isCertified,
      events: updatedEvents,
    );

    // Update the selected log
    state = state.copyWith(selectedLog: updatedLog);

    // Update the log in the main logs list
    final updatedLogs = state.logs.map((log) {
      if (log.id == updatedLog.id) return updatedLog;
      return log;
    }).toList();

    state = state.copyWith(logs: updatedLogs);
  }
}



