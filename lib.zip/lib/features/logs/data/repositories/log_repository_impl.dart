import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/repositories/log_repository.dart';
import '../datasources/log_local_data_source.dart';
import '../../domain/entities/daily_log.dart';
import '../../domain/entities/audit_entry.dart';
import '../../../../core/engine/tracking/duty_status_tracker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/logger.dart';

class LogRepositoryImpl implements LogRepository {
  final LogLocalDataSource _localDataSource;

  LogRepositoryImpl(this._localDataSource);

  @override
  Future<Either<Failure, List<LogEvent>>> getEvents(DateTime date) async {
    try {
      final events = await _localDataSource.getEvents(date);
      return Right(events);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.getEvents error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء جلب الأحداث'));
    }
  }

  @override
  Future<Either<Failure, bool>> addEvent(LogEvent event) async {
    try {
      final success = await _localDataSource.addEvent(event);
      return Right(success);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.addEvent error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء إضافة الحدث'));
    }
  }

  @override
  Future<Either<Failure, bool>> updateEvent(LogEvent event) async {
    try {
      final success = await _localDataSource.updateEvent(event);
      return Right(success);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.updateEvent error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء تحديث الحدث'));
    }
  }

  @override
  Future<Either<Failure, List<DutyPeriod>>> getPeriods(DateTime date) async {
    try {
      final periods = await _localDataSource.getPeriods(date);
      return Right(periods);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.getPeriods error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء جلب الفترات'));
    }
  }

  @override
  Future<Either<Failure, bool>> savePeriod(DutyPeriod period) async {
    try {
      final success = await _localDataSource.savePeriod(period);
      return Right(success);
    } catch (e) {
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء حفظ الفترة'));
    }
  }

  @override
  Future<Either<Failure, bool>> logAudit(AuditEntry entry) async {
    try {
      final success = await _localDataSource.logAudit(entry);
      return Right(success);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.logAudit error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء حفظ التدقيق'));
    }
  }

  @override
  Future<Either<Failure, List<AuditEntry>>> getAuditEntries(DateTime date) async {
    try {
      final entries = await _localDataSource.getAuditEntries(date);
      return Right(entries);
    } catch (e) {
      AppLogger.error('LogRepositoryImpl.getAuditEntries error', e);
      return Left(CacheFailure(message: e.toString(), arabicMessage: 'حدث خطأ أثناء جلب التدقيق'));
    }
  }
}

final logRepositoryProvider = Provider<LogRepository>((ref) {
  final localDataSource = ref.watch(logLocalDataSourceProvider);
  return LogRepositoryImpl(localDataSource);
});
