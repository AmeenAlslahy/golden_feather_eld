import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/datasources/vehicle_mock_data.dart';
import '../../domain/entities/vehicle.dart';

/// حالة شاشة المركبات
class VehicleState {
  final List<Vehicle> vehicles;
  final Vehicle? selectedVehicle;
  final String searchQuery;
  final bool isLoading;

  const VehicleState({
    this.vehicles = const [],
    this.selectedVehicle,
    this.searchQuery = '',
    this.isLoading = false,
  });

  List<Vehicle> get filteredVehicles {
    if (searchQuery.isEmpty) return vehicles;
    return vehicles.where((v) {
      final query = searchQuery.toLowerCase();
      return v.id.contains(query) ||
          v.name.toLowerCase().contains(query) ||
          v.year.contains(query);
    }).toList();
  }

  VehicleState copyWith({
    List<Vehicle>? vehicles,
    Vehicle? selectedVehicle,
    String? searchQuery,
    bool? isLoading,
  }) {
    return VehicleState(
      vehicles: vehicles ?? this.vehicles,
      selectedVehicle: selectedVehicle ?? this.selectedVehicle,
      searchQuery: searchQuery ?? this.searchQuery,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

/// مزود المركبات
final vehicleProvider =
    StateNotifierProvider<VehicleNotifier, VehicleState>((ref) {
  return VehicleNotifier();
});

class VehicleNotifier extends StateNotifier<VehicleState> {
  VehicleNotifier() : super(const VehicleState()) {
    _loadVehicles();
  }

  void _loadVehicles() {
    state = state.copyWith(isLoading: true);
    Future.delayed(const Duration(milliseconds: 800), () {
      state = VehicleState(
        vehicles: VehicleMockData.getVehicles(),
        isLoading: false,
      );
    });
  }

  /// البحث عن مركبة
  void search(String query) {
    state = state.copyWith(searchQuery: query);
  }

  /// اختيار مركبة
  Future<void> selectVehicle(Vehicle vehicle) async {
    state = state.copyWith(selectedVehicle: vehicle, isLoading: true);
    // محاكاة اتصال بالخادم
    await Future.delayed(const Duration(milliseconds: 500));
    state = state.copyWith(
      selectedVehicle: vehicle,
      isLoading: false,
    );
  }
}
