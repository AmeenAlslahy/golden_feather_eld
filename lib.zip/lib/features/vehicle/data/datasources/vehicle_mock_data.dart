import '../../domain/entities/vehicle.dart';

/// بيانات وهمية للمركبات
class VehicleMockData {
  static List<Vehicle> getVehicles() {
    return [
      const Vehicle(
        id: '646',
        name: 'VOLVO TT',
        year: '2015',
        type: 'شاحنة',
        vin: '1FUJGLDR5CSBJ0527',
        isAssigned: true,
      ),
      const Vehicle(
        id: '712',
        name: 'FREIGHTLINER CASCADIA',
        year: '2018',
        type: 'شاحنة',
        vin: '3AKJGLDR5HSBJ0823',
        isAssigned: true,
      ),
      const Vehicle(
        id: '825',
        name: 'KENWORTH T680',
        year: '2020',
        type: 'شاحنة',
        vin: '1XKJGLDR5LSBJ1204',
        isAssigned: false,
      ),
      const Vehicle(
        id: '903',
        name: 'PETERBILT 579',
        year: '2019',
        type: 'شاحنة',
        vin: '1XPJGLDR5KSBJ0956',
        isAssigned: true,
      ),
      const Vehicle(
        id: '1050',
        name: 'INTERNATIONAL LT',
        year: '2021',
        type: 'شاحنة',
        vin: '3HSJGLDR5MSBJ1508',
        isAssigned: false,
      ),
    ];
  }
}
