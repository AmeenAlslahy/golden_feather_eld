import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:signature/signature.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_radius.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/eld_card.dart';
// import '../../../../l10n/app_localizations.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../home/presentation/widgets/eld_drawer.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import '../../domain/entities/dvir_report.dart';
import '../providers/dvir_provider.dart';

class DvirFormState {
  final InspectionType selectedType;
  final List<ItemInspectionResult> items;
  final VehicleCondition condition;
  final bool isSubmitting;

  DvirFormState({
    required this.selectedType,
    required this.items,
    required this.condition,
    this.isSubmitting = false,
  });

  DvirFormState copyWith({
    InspectionType? selectedType,
    List<ItemInspectionResult>? items,
    VehicleCondition? condition,
    bool? isSubmitting,
  }) {
    return DvirFormState(
      selectedType: selectedType ?? this.selectedType,
      items: items ?? this.items,
      condition: condition ?? this.condition,
      isSubmitting: isSubmitting ?? this.isSubmitting,
    );
  }
}

class DvirFormNotifier extends StateNotifier<DvirFormState> {
  DvirFormNotifier(super.state);

  void setType(InspectionType type) => state = state.copyWith(selectedType: type);
  void setCondition(VehicleCondition condition) => state = state.copyWith(condition: condition);
  void setSubmitting(bool isSubmitting) => state = state.copyWith(isSubmitting: isSubmitting);
  
  void toggleDefect(int index) {
    final newItems = List<ItemInspectionResult>.from(state.items);
    final item = newItems[index];
    newItems[index] = item.copyWith(
      isDefective: !item.isDefective,
      defectDescription: item.isDefective ? null : item.defectDescription,
    );
    state = state.copyWith(items: newItems);
  }
}

final dvirFormProvider = StateNotifierProvider.autoDispose.family<DvirFormNotifier, DvirFormState, DvirReport?>(
  (ref, existingReport) {
    if (existingReport != null) {
      return DvirFormNotifier(DvirFormState(
        selectedType: existingReport.type,
        items: existingReport.items.map((item) => ItemInspectionResult(
          item: item.item,
          isDefective: item.isDefective,
          defectDescription: item.defectDescription,
        )).toList(),
        condition: existingReport.condition,
      ));
    } else {
      return DvirFormNotifier(DvirFormState(
        selectedType: InspectionType.preTrip,
        items: InspectionItem.values.map((item) => ItemInspectionResult(item: item)).toList(),
        condition: VehicleCondition.safe,
      ));
    }
  }
);

/// شاشة إنشاء/تعديل تقرير DVIR
class DvirFormPage extends ConsumerStatefulWidget {
  final DvirReport? existingReport;

  const DvirFormPage({super.key, this.existingReport});

  @override
  ConsumerState<DvirFormPage> createState() => _DvirFormPageState();
}

class _DvirFormPageState extends ConsumerState<DvirFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _notesController = TextEditingController();
  final SignatureController _signatureController = SignatureController(
    penStrokeWidth: 3,
    penColor: AppColors.textPrimary,
    exportBackgroundColor: AppColors.surface,
  );

  final List<String> _dtcCodes = ['P0420', 'P0301']; // محاكاة من ECM

  @override
  void initState() {
    super.initState();
    if (widget.existingReport != null) {
      _notesController.text = widget.existingReport!.notes ?? '';
    }
  }

  @override
  void dispose() {
    _notesController.dispose();
    _signatureController.dispose();
    super.dispose();
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    ref.read(dvirFormProvider(widget.existingReport).notifier).setSubmitting(true);

    final dashboard = ref.read(dashboardDataProvider);
    final formState = ref.read(dvirFormProvider(widget.existingReport));
    final signatureData = await _signatureController.toPngBytes();

    final report = DvirReport(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: formState.selectedType,
      date: DateTime.now(),
      driverName: dashboard.driverName,
      vehicleId: dashboard.vehicleId,
      trailerId: dashboard.trailerId,
      odometer: 125000.0, // من ECM
      items: formState.items,
      dtcCodes: _dtcCodes,
      notes: _notesController.text.isNotEmpty ? _notesController.text : null,
      signature: signatureData != null ? 'signature_${DateTime.now().millisecondsSinceEpoch}' : null,
      condition: formState.condition,
      isSubmitted: true,
    );

    await ref.read(dvirProvider.notifier).createReport(report);

    if (mounted) {
      ref.read(dvirFormProvider(widget.existingReport).notifier).setSubmitting(false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ ${context.loc.reportSavedSuccess}'),
          backgroundColor: AppColors.successGreen,
        ),
      );
      Navigator.pop(context);
    }
  }

  void _toggleDefect(int index) {
    ref.read(dvirFormProvider(widget.existingReport).notifier).toggleDefect(index);
  }

  @override
  Widget build(BuildContext context) {
    final formState = ref.watch(dvirFormProvider(widget.existingReport));
    final dashboard = ref.watch(dashboardDataProvider);
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final hasDefects = formState.items.any((item) => item.isDefective);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      drawer: const EldDrawer(),
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlue,
        title: Text(
          widget.existingReport != null ? context.loc.editReport : context.loc.newReport,
          style: const TextStyle(
            fontSize: AppTypography.bodySize,
            fontWeight: AppTypography.bold,
            color: AppColors.surface,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ========== ١. نوع الفحص ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.loc.inspectionType,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Row(
                      children: [
                        Expanded(
                          child: _buildTypeButton(
                            type: InspectionType.preTrip,
                            label: isArabic
                                ? InspectionType.preTrip.arabicName
                                : InspectionType.preTrip.englishName,
                            icon: Icons.play_circle,
                            isSelected: formState.selectedType == InspectionType.preTrip,
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: _buildTypeButton(
                            type: InspectionType.postTrip,
                            label: isArabic
                                ? InspectionType.postTrip.arabicName
                                : InspectionType.postTrip.englishName,
                            icon: Icons.stop_circle,
                            isSelected: formState.selectedType == InspectionType.postTrip,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // ========== ٢. معلومات المركبة ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.loc.vehicleInfo,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    _buildInfoRow(context.loc.vehicle, dashboard.vehicleDisplayName),
                    if (dashboard.trailerId != null)
                      _buildInfoRow(context.loc.trailer, dashboard.trailerId!),
                    _buildInfoRow(context.loc.driver, dashboard.driverName),
                    _buildInfoRow(context.loc.dateLabel, DateTime.now().toString().substring(0, 10)),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // ========== ٣. رموز أعطال المحرك (DTC) ==========
              if (_dtcCodes.isNotEmpty) ...[
                EldCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.build, color: AppColors.warningYellow, size: 20),
                          const SizedBox(width: AppSpacing.sm),
                          Text(
                            context.loc.dtcCodes,
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      Wrap(
                        spacing: AppSpacing.sm,
                        runSpacing: AppSpacing.xs,
                        children: _dtcCodes.map((code) => Chip(
                          label: Text(code, style: const TextStyle(fontSize: 12)),
                          backgroundColor: AppColors.warningYellow.withValues(alpha: 0.1),
                        )).toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
              ],

              // ========== ٤. قائمة الفحص ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          context.loc.mechanicalChecklist,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const Spacer(),
                        if (hasDefects)
                          Text(
                            '${formState.items.where((i) => i.isDefective).length} ${context.loc.defectsFound}',
                            style: const TextStyle(
                              color: AppColors.dangerRed,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    ...List.generate(formState.items.length, (index) {
                      final item = formState.items[index];
                      return _buildInspectionItem(index, item, isArabic);
                    }),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // ========== ٥. الملاحظات ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.loc.additionalNotes,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    AppTextField(
                      controller: _notesController,
                      hint: context.loc.notesHint,
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // ========== ٦. حالة المركبة ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.loc.vehicleCondition,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    ...VehicleCondition.values.map((condition) {
                      final isSelected = formState.condition == condition;
                      return RadioListTile<VehicleCondition>(
                        title: Text(
                          isArabic ? condition.arabicName : condition.englishName,
                          style: TextStyle(
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            color: condition == VehicleCondition.unsafe
                                ? AppColors.dangerRed
                                : condition == VehicleCondition.needsRepair
                                    ? AppColors.warningYellow
                                    : AppColors.successGreen,
                          ),
                        ),
                        value: condition,
                        groupValue: formState.condition,
                        onChanged: (value) {
                          ref.read(dvirFormProvider(widget.existingReport).notifier).setCondition(value!);
                        },
                        activeColor: condition == VehicleCondition.unsafe
                            ? AppColors.dangerRed
                            : condition == VehicleCondition.needsRepair
                                ? AppColors.warningYellow
                                : AppColors.successGreen,
                        contentPadding: EdgeInsets.zero,
                      );
                    }),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // ========== ٧. التوقيع ==========
              EldCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.loc.driverSignature,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Container(
                      height: 150,
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.border),
                        borderRadius: BorderRadius.circular(AppRadius.imagePlaceholder),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(AppRadius.imagePlaceholder - 1),
                        child: Signature(
                          controller: _signatureController,
                          backgroundColor: AppColors.surface,
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    TextButton.icon(
                      onPressed: () => _signatureController.clear(),
                      icon: const Icon(Icons.clear, size: 16),
                      label: Text(context.loc.clearSignature),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              // ========== ٨. زر الحفظ ==========
              AppButton(
                label: widget.existingReport != null ? context.loc.updateReport : context.loc.saveReport,
                icon: Icons.save,
                isLoading: formState.isSubmitting,
                onPressed: formState.isSubmitting ? null : _handleSubmit,
              ),
              const SizedBox(height: AppSpacing.lg),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypeButton({
    required InspectionType type,
    required String label,
    required IconData icon,
    required bool isSelected,
  }) {
    return InkWell(
      onTap: () => ref.read(dvirFormProvider(widget.existingReport).notifier).setType(type),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primaryBlue.withValues(alpha: 0.1)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(AppRadius.card),
          border: Border.all(
            color: isSelected ? AppColors.primaryBlue : AppColors.border,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected ? AppColors.primaryBlue : AppColors.textSecondary,
              size: 28,
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? AppColors.primaryBlue : AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInspectionItem(int index, ItemInspectionResult item, bool isArabic) {
    return InkWell(
      onTap: () => _toggleDefect(index),
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: AppSpacing.sm,
          horizontal: AppSpacing.xs,
        ),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: AppColors.border.withValues(alpha: 0.5)),
          ),
        ),
        child: Row(
          children: [
            // أيقونة الحالة
            Icon(
              item.isDefective ? Icons.cancel : Icons.check_circle,
              color: item.isDefective ? AppColors.dangerRed : AppColors.successGreen,
              size: 22,
            ),
            const SizedBox(width: AppSpacing.sm),
            // اسم العنصر
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isArabic ? item.item.arabicName : item.item.englishName,
                    style: TextStyle(
                      fontSize: AppTypography.bodySize,
                      fontWeight: item.isDefective ? FontWeight.bold : FontWeight.normal,
                      color: item.isDefective ? AppColors.dangerRed : AppColors.textPrimary,
                    ),
                  ),
                  if (item.isDefective && item.defectDescription != null)
                    Text(
                      item.defectDescription!,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.dangerRed,
                      ),
                    ),
                ],
              ),
            ),
            // مؤشر التبديل
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: item.isDefective
                    ? AppColors.dangerRed.withValues(alpha: 0.1)
                    : AppColors.successGreen.withValues(alpha: 0.1),
              ),
              child: Icon(
                item.isDefective ? Icons.close : Icons.done,
                size: 14,
                color: item.isDefective ? AppColors.dangerRed : AppColors.successGreen,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.xs),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        ],
      ),
    );
  }
}
