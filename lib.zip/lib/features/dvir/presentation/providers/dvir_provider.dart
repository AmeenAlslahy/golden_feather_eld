import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/datasources/dvir_mock_data.dart';
import '../../domain/entities/dvir_report.dart';

/// حالة شاشة DVIR
class DvirState {
  final List<DvirReport> reports;
  final DvirReport? currentReport;
  final bool isLoading;

  const DvirState({
    this.reports = const [],
    this.currentReport,
    this.isLoading = false,
  });

  DvirState copyWith({
    List<DvirReport>? reports,
    DvirReport? currentReport,
    bool? isLoading,
  }) {
    return DvirState(
      reports: reports ?? this.reports,
      currentReport: currentReport ?? this.currentReport,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

/// مزود DVIR
final dvirProvider = StateNotifierProvider<DvirNotifier, DvirState>((ref) {
  return DvirNotifier();
});

class DvirNotifier extends StateNotifier<DvirState> {
  DvirNotifier() : super(const DvirState()) {
    _loadDvirs();
  }

  void _loadDvirs() {
    state = state.copyWith(isLoading: true);
    Future.delayed(const Duration(milliseconds: 500), () {
      state = DvirState(
        reports: DvirMockData.getDvirs(),
        isLoading: false,
      );
    });
  }

  /// إنشاء تقرير جديد
  Future<void> createReport(DvirReport report) async {
    final updatedReports = [report, ...state.reports];
    state = state.copyWith(reports: updatedReports);
  }

  /// تحديث تقرير موجود
  void updateReport(DvirReport report) {
    final updatedReports = state.reports.map((r) {
      return r.id == report.id ? report : r;
    }).toList();
    state = state.copyWith(reports: updatedReports);
  }
}
