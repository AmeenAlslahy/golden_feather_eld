import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/engine/hos_rules_engine.dart';
import '../../../../core/engine/hos_state_machine.dart';

/// مزود حالة HOS
final hosStatusProvider = StateNotifierProvider<HosNotifier, HosStatusUpdate>((ref) {
  final engine = ref.watch(hosEngineProvider);
  return HosNotifier(engine);
});

class HosNotifier extends StateNotifier<HosStatusUpdate> {
  final HosRulesEngine _engine;
  Timer? _refreshTimer;

  HosNotifier(this._engine) : super(_engine.currentStatus) {
    _startRefreshTimer();
  }

  void _startRefreshTimer() {
    // تحديث الحالة كل دقيقة لتحديث المؤقتات في الواجهة
    _refreshTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      refresh();
    });
  }

  /// تغيير حالة الخدمة
  void changeStatus(DutyStatus newStatus, {String? annotation}) {
    _engine.manualTransition(newStatus, annotation: annotation);
    refresh();
  }
  
  /// تحديث الحالة
  void refresh() {
    state = _engine.currentStatus;
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}



