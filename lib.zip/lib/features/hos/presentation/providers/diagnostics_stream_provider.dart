import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/engine/diagnostics/diagnostics_engine.dart';

/// مزود يراقب حالة محرك التشخيصات (DiagnosticsEngine)
/// وبما أن المحرك لا يعرض Stream حالياً ولا يمكننا تعديله (حسب القواعد)،
/// نقوم بعمل Polling خفيف للـ State لإبقاء الـ UI متزامناً (Reactive).
final diagnosticsStreamProvider = StreamProvider.autoDispose<DiagnosticsState>((ref) async* {
  final engine = ref.watch(diagnosticsEngineProvider);
  
  // نحتفظ بآخر حالة مرجعية لتفادي التحديثات الوهمية
  DiagnosticsState lastState = engine.state;
  yield lastState;

  while (true) {
    await Future.delayed(const Duration(seconds: 1));
    if (engine.state != lastState) {
      lastState = engine.state;
      yield lastState;
    }
  }
});
