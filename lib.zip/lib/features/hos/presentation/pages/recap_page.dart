import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/extensions/context_extensions.dart';
import 'package:intl/intl.dart';

class RecapPage extends StatelessWidget {
  const RecapPage({super.key});

  @override
  Widget build(BuildContext context) {
    // هذه البيانات وهمية حتى يتم ربطها لاحقاً بمحرك HOS
    final now = DateTime.now();
    final List<Map<String, dynamic>> recapDays = List.generate(7, (index) {
      final date = now.subtract(Duration(days: 7 - index));
      // بيانات وهمية
      final hours = index == 3 ? 00.77 : (index == 4 ? 05.26 : 00.00);
      return {
        'day': DateFormat('EEEE').format(date),
        'date': DateFormat('MMM d').format(date),
        'hours': hours,
      };
    });

    const totalLast7Days = 06.03;
    const workedToday = 11.16;
    const availableToday = 52.81;
    const availableTomorrow = 52.81;

    return Container(
      color: Theme.of(context).colorScheme.surface,
      child: ListView(
        children: [
          // جدول الأيام السبعة
          ...recapDays.map((dayData) => _buildRow(
                title: dayData['day'],
                subtitle: dayData['date'],
                value: dayData['hours'].toStringAsFixed(2).padLeft(5, '0'),
              )),
          
          const Divider(height: 1, color: AppColors.border),
          _buildRow(
            title: context.loc.total,
            subtitle: context.loc.last7Days,
            value: totalLast7Days.toStringAsFixed(2).padLeft(5, '0'),
            isBold: true,
          ),
          
          const Divider(height: 1, color: AppColors.border),
          _buildRow(
            title: context.loc.hoursWorkedToday,
            value: workedToday.toStringAsFixed(2).padLeft(5, '0'),
            isBold: true,
          ),
          
          const Divider(height: 1, color: AppColors.border),
          _buildRow(
            title: context.loc.hoursAvailableToday,
            value: availableToday.toStringAsFixed(2).padLeft(5, '0'),
            isBold: true,
          ),
          
          const Divider(height: 1, color: AppColors.border),
          _buildRow(
            title: context.loc.hoursAvailableTomorrow,
            value: availableTomorrow.toStringAsFixed(2).padLeft(5, '0'),
            isBold: true,
          ),
        ],
      ),
    );
  }

  Widget _buildRow({
    required String title,
    String? subtitle,
    required String value,
    bool isBold = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.border, width: 1)),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              title,
              style: TextStyle(
                fontSize: 15,
                fontWeight: isBold ? AppTypography.bold : AppTypography.semiBold,
                
              ),
            ),
          ),
          if (subtitle != null)
            Expanded(
              flex: 2,
              child: Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 15,
                  
                ),
              ),
            ),
          Expanded(
            flex: 1,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: AppTypography.semiBold,
                
                fontFamily: 'monospace', // لتوحيد عرض الأرقام كما طلب العميل
              ),
            ),
          ),
        ],
      ),
    );
  }
}



