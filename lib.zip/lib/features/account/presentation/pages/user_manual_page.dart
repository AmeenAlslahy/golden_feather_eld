import 'package:flutter/material.dart';
import 'manual_detail_page.dart';

class UserManualPage extends StatelessWidget {
  const UserManualPage({super.key});

  @override
  Widget build(BuildContext context) {
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    return ManualDetailPage(
      title: isArabic ? 'دليل المستخدم' : 'User Manual',
      content: _getUserManualContent(isArabic),
    );
  }

  List<ManualSection> _getUserManualContent(bool isArabic) {
    return [
      ManualSection(
        title: isArabic ? 'مقدمة' : 'Introduction',
        steps: [
          isArabic
              ? 'هذا دليل استخدام نظام السجلات الإلكترونية المتوافق مع معايير السلامة الدولية.'
              : 'This is the user manual for the international safety-compliant ELD system.'
        ],
        isNumbered: false,
      ),
      ManualSection(
        title: isArabic ? 'تسجيل الدخول' : 'Login',
        steps: [
          isArabic ? 'افتح التطبيق وأدخل اسم المستخدم وكلمة المرور الخاصة بك.' : 'Open the app and enter your username and password.',
          isArabic ? 'تأكد من إعطاء كافة الصلاحيات المطلوبة (الموقع، البلوتوث).' : 'Ensure all required permissions (Location, Bluetooth) are granted.',
        ],
      ),
      ManualSection(
        title: isArabic ? 'الربط بالمركبة' : 'Connecting to Vehicle',
        steps: [
          isArabic ? 'انتقل إلى شاشة الربط واختر جهاز الـ ELD الخاص بك من القائمة.' : 'Go to the connection screen and select your ELD device from the list.',
          isArabic ? 'تأكد من أن مؤشر البلوتوث يضيء باللون الأخضر في الشاشة الرئيسية.' : 'Ensure the Bluetooth indicator is green on the home screen.',
        ],
      ),
      ManualSection(
        title: isArabic ? 'تحديث الحالة' : 'Updating Status',
        steps: [
          isArabic ? 'من الشاشة الرئيسية، اضغط على الدائرة لتغيير حالتك (ON, OFF, D, SB).' : 'From the home screen, tap the circle to change your status (ON, OFF, D, SB).',
          isArabic ? 'ستتحول الحالة إلى D تلقائياً عند تحرك المركبة.' : 'Status will automatically change to D when the vehicle moves.',
        ],
      ),
      ManualSection(
        title: isArabic ? 'التفتيش والمصادقة' : 'Inspection & Certification',
        steps: [
          isArabic ? 'في نهاية اليوم، اذهب إلى "السجلات" وقم بتوقيع والمصادقة على يومك.' : 'At the end of the day, go to "Logs" and certify your day with your signature.',
          isArabic ? 'في حال التفتيش، افتح شاشة "التفتيش" واتبع التعليمات.' : 'In case of an inspection, open the "Inspection" screen and follow the instructions.',
        ],
      ),
    ];
  }
}
