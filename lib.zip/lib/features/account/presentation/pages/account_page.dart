import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/eld_card.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import '../../../home/presentation/widgets/eld_drawer.dart';

/// شاشة معلومات الحساب
class AccountPage extends ConsumerWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashboard = ref.watch(dashboardDataProvider);
    final loc = context.loc;
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlue,
        title: Text(
          loc.account,
          style: const TextStyle(
            fontSize: AppTypography.bodySize,
            fontWeight: AppTypography.bold,
            color: AppColors.surface,
          ),
        ),
        centerTitle: true,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: AppColors.surface),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      drawer: const EldDrawer(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ========== صورة واسم السائق ==========
            Center(
              child: Column(
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.person,
                      size: 44,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    dashboard.driverName,
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Driver',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.outline,
                      fontSize: AppTypography.captionSize,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xl),

            // ========== معلومات الحساب ==========
            EldCard(
              child: Column(
                children: [
                  _buildInfoRow(
                    context,
                    isArabic ? 'اسم المستخدم' : 'Username',
                    'amin.alsalhi',
                  ),
                  const Divider(color: AppColors.border),
                  _buildInfoRow(
                    context,
                    isArabic ? 'البريد الإلكتروني' : 'Email',
                    'amin@company.com',
                  ),
                  const Divider(color: AppColors.border),
                  _buildInfoRow(
                    context,
                    isArabic ? 'رقم الرخصة' : 'License Number',
                    'CDL-582491',
                  ),
                  const Divider(color: AppColors.border),
                  _buildInfoRow(
                    context,
                    isArabic ? 'الناقل' : 'Carrier',
                    'Golden Feather Transport',
                  ),
                  const Divider(color: AppColors.border),
                  _buildInfoRow(
                    context,
                    isArabic ? 'رقم USDOT' : 'USDOT Number',
                    '1234567',
                  ),
                  const Divider(color: AppColors.border),
                  _buildInfoRow(
                    context,
                    isArabic ? 'العنوان' : 'Address',
                    '123 Main St, Riyadh, SA',
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),

            // ========== رسالة تنبيه ==========
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: AppColors.warningYellow.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, color: AppColors.warningYellow, size: 20),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(
                      isArabic
                          ? 'يرجى الاتصال بمدير الأسطول لتغيير المعلومات'
                          : 'Please contact fleet manager to change information',
                      style: const TextStyle(
                        fontSize: AppTypography.captionSize,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: AppSpacing.md,
        horizontal: AppSpacing.xs,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: AppTypography.bodySize,
              color: AppColors.textSecondary,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: AppTypography.bodySize,
              fontWeight: AppTypography.semiBold,
            ),
          ),
        ],
      ),
    );
  }
}
