import 'package:flutter_riverpod/flutter_riverpod.dart';

/// بيانات لوحة القيادة
class DashboardData {
  final String driverName;
  final String? driverLicense;
  final String vehicleId;
  final String vehicleDisplayName;
  final String? trailerId;
  final String? shippingDocuments;
  final String? coDriverName;
  final String? coDriverId;
  final String? documentsInfo;

  const DashboardData({
    required this.driverName,
    this.driverLicense,
    required this.vehicleId,
    required this.vehicleDisplayName,
    this.trailerId,
    this.shippingDocuments,
    this.coDriverName,
    this.coDriverId,
    this.documentsInfo,
  });

  DashboardData copyWith({
    String? driverName,
    String? driverLicense,
    String? vehicleId,
    String? vehicleDisplayName,
    String? trailerId,
    String? shippingDocuments,
    String? coDriverName,
    String? coDriverId,
    String? documentsInfo,
  }) {
    return DashboardData(
      driverName: driverName ?? this.driverName,
      driverLicense: driverLicense ?? this.driverLicense,
      vehicleId: vehicleId ?? this.vehicleId,
      vehicleDisplayName: vehicleDisplayName ?? this.vehicleDisplayName,
      trailerId: trailerId ?? this.trailerId,
      shippingDocuments: shippingDocuments ?? this.shippingDocuments,
      coDriverName: coDriverName ?? this.coDriverName,
      coDriverId: coDriverId ?? this.coDriverId,
      documentsInfo: documentsInfo ?? this.documentsInfo,
    );
  }

  static const development = DashboardData(
    driverName: 'Amin Alsalhi',
    driverLicense: 'CDL-582491',
    vehicleId: '646',
    vehicleDisplayName: '2015 VOLVO TT',
    trailerId: '1402',
    shippingDocuments: 'empty, 000516183',
    coDriverName: 'None',
    coDriverId: 'none',
    documentsInfo: null,
  );
}

class DashboardNotifier extends StateNotifier<DashboardData> {
  DashboardNotifier() : super(DashboardData.development);

  void updateVehicle(dynamic vehicle) {
    if (vehicle == null) return;
    state = state.copyWith(
      vehicleId: vehicle.id ?? vehicle.number, // Adjust based on your Vehicle entity
      vehicleDisplayName: vehicle.number ?? vehicle.model ?? '',
    );
  }

  void updateCoDriver(dynamic coDriver) {
    if (coDriver == null) return;
    state = state.copyWith(
      coDriverId: coDriver.id,
      coDriverName: coDriver.name,
    );
  }
}

final dashboardDataProvider = StateNotifierProvider<DashboardNotifier, DashboardData>((ref) {
  return DashboardNotifier();
});
