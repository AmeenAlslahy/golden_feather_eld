import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../hos/presentation/pages/hos_page.dart';
import '../../../hos/presentation/pages/recap_page.dart';
import '../../../sync/presentation/widgets/sync_status_indicator.dart';
import '../../../../core/widgets/connection_status_indicator.dart';
import '../widgets/eld_drawer.dart';
import '../widgets/eld_bottom_nav.dart';
import '../providers/dashboard_provider.dart';

final homeNavIndexProvider = StateProvider<int>((ref) => 0);

/// الشاشة الرئيسية لتطبيق ELD
class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  // قائمة الصفحات التي تظهر في المحتوى الرئيسي
  static const List<Widget> _pages = [
    StatusDashboard(),  // الشاشة الرئيسية - حالة السائق
    RecapPage(),        // ملخص أسبوعي
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashboard = ref.watch(dashboardDataProvider);
    final currentNavIndex = ref.watch(homeNavIndexProvider);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      // ========== شريط العنوان ==========
      appBar: AppBar(
        title: Text(
          currentNavIndex == 0 ? '${dashboard.driverName} - ${dashboard.vehicleId}' : context.loc.hoursRecap,
          style: const TextStyle(
            fontSize: AppTypography.bodySize,
            fontWeight: AppTypography.bold,
            color: AppColors.surface,
          ),
        ),
        centerTitle: currentNavIndex == 1, // توسيط العنوان في شاشة Recap
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: AppColors.surface),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: currentNavIndex == 0 ? [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.0),
            child: ConnectionStatusIndicator(),
          ),
          const SyncStatusIndicator(),
          // أيقونة تحذير فقط في شاشة Status
          IconButton(
            icon: const Icon(
              Icons.warning_amber,
              color: AppColors.warningYellow,
              size: 28,
            ),
            onPressed: () {
              // إظهار التنبيهات
            },
          ),
        ] : null,
      ),

      // ========== الدرج الجانبي ==========
      drawer: const EldDrawer(),

      // ========== المحتوى الرئيسي ==========
      body: _pages[currentNavIndex],

      // ========== شريط التنقل السفلي ==========
      bottomNavigationBar: EldBottomNav(
        currentIndex: currentNavIndex,
        onTap: (index) {
          ref.read(homeNavIndexProvider.notifier).state = index;
        },
      ),
    );
  }
}

// ========== صفحات مؤقتة ==========

/// شاشة الحالة - نعرض داخلها HosPage
class StatusDashboard extends StatelessWidget {
  const StatusDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold داخل Scaffold ليس جيداً، لكن مؤقتاً لعرض محتوى HosPage
    // تم إزالة الـ AppBar من HosPage في التحديث القادم أو يتم تجاهله.
    // لتفادي تكرار الـ AppBar هنا سنقوم فقط بعرض HosPage
    return const HosPage(); 
  }
}





