import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../sync/presentation/providers/sync_provider.dart';
import '../../../../core/extensions/context_extensions.dart';

/// مؤشر حالة المزامنة
class SyncStatusIndicator extends ConsumerWidget {
  const SyncStatusIndicator({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final syncState = ref.watch(syncStateProvider);

    if (syncState.totalPending == 0 && !syncState.isSyncing) return const SizedBox.shrink();

    return InkWell(
      onTap: () {
        ref.read(syncStateProvider.notifier).syncNow();
      },
      child: Center(
        child: Container(
          margin: const EdgeInsets.only(right: AppSpacing.sm),
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.sm,
            vertical: AppSpacing.xs,
          ),
          decoration: BoxDecoration(
            color: syncState.isSyncing
                ? AppColors.primaryBlue.withValues(alpha: 0.1)
                : AppColors.warningYellow.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                syncState.isSyncing ? Icons.sync : Icons.sync_problem,
                size: 14,
                color: syncState.isSyncing
                    ? AppColors.primaryBlue
                    : AppColors.warningYellow,
              ),
              const SizedBox(width: 4),
              Text(
                syncState.isSyncing
                    ? context.loc.syncing
                    : context.loc.syncPending(syncState.totalPending.toString()),
                style: TextStyle(
                  fontSize: 11,
                  color: syncState.isSyncing
                      ? AppColors.primaryBlue
                      : AppColors.warningYellow,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (syncState.totalFailed > 0) ...[
                const SizedBox(width: 4),
                Text(
                  '(${context.loc.syncFailed(syncState.totalFailed.toString())})',
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.dangerRed,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
