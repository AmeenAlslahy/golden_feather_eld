import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/core_providers.dart';
import '../../domain/repositories/offline_queue.dart';
import '../../domain/repositories/sync_repository.dart';
import '../../domain/usecases/sync_engine.dart';
import '../datasources/sync_local_data_source.dart';
import '../repositories/memory_offline_queue.dart';
import '../repositories/sync_repository_impl.dart';

final syncLocalDataSourceProvider = Provider<SyncLocalDataSource>((ref) {
  return SyncLocalDataSourceImpl();
});

final offlineQueueProvider = Provider<OfflineQueue>((ref) {
  return MemoryOfflineQueue();
});

final syncRepositoryProvider = Provider<SyncRepository>((ref) {
  return SyncRepositoryImpl(
    localDataSource: ref.watch(syncLocalDataSourceProvider),
    networkInfo: ref.watch(networkInfoProvider),
    dispatcher: ref.watch(syncDispatcherProvider),
  );
});

final syncDispatcherProvider = Provider<RemoteEventDispatcher>((ref) {
  throw UnimplementedError('Provide RemoteEventDispatcher');
});
