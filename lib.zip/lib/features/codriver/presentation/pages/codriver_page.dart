import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/eld_card.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import '../../../home/presentation/widgets/eld_drawer.dart';
import '../../domain/entities/codriver.dart';
import '../providers/codriver_provider.dart';

/// شاشة السائق المساعد
class CoDriverPage extends ConsumerStatefulWidget {
  const CoDriverPage({super.key});

  @override
  ConsumerState<CoDriverPage> createState() => _CoDriverPageState();
}

class _CoDriverPageState extends ConsumerState<CoDriverPage> {
  String? _selectedId;

  @override
  Widget build(BuildContext context) {
    final codriverState = ref.watch(codriverProvider);
    final dashboard = ref.watch(dashboardDataProvider);
    final loc = context.loc;
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final drivers = [CoDriver.none, ...codriverState.availableDrivers];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlue,
        title: Text(
          loc.coDriver,
          style: const TextStyle(
            fontSize: AppTypography.bodySize,
            fontWeight: AppTypography.bold,
            color: AppColors.surface,
          ),
        ),
        centerTitle: true,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: AppColors.surface),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      drawer: const EldDrawer(),
      body: codriverState.isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ========== السائق الحالي ==========
                  EldCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? 'السائق الحالي' : 'Current Driver',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Row(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                color: AppColors.primaryBlue.withValues(alpha: 0.1),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person,
                                color: AppColors.primaryBlue,
                                size: 28,
                              ),
                            ),
                            const SizedBox(width: AppSpacing.md),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    dashboard.driverName,
                                    style: const TextStyle(
                                      fontSize: AppTypography.bodySize,
                                      fontWeight: AppTypography.bold,
                                    ),
                                  ),
                                  Text(
                                    'Driver',
                                    style: TextStyle(
                                      fontSize: AppTypography.smallSize,
                                      color: Theme.of(context).colorScheme.outline,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: AppSpacing.sm,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.successGreen.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'Active',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: AppColors.successGreen,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ========== اختيار سائق مساعد ==========
                  EldCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? 'اختيار سائق مساعد' : 'Select Co-Driver',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        ...drivers.map((driver) {
                          final isSelected = driver.id ==
                              (_selectedId ?? codriverState.selectedCoDriver?.id ?? 'none');
                          return RadioListTile<String>(
                            title: Text(
                              driver.name,
                              style: TextStyle(
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                fontSize: AppTypography.bodySize,
                              ),
                            ),
                            subtitle: driver.licenseNumber != null
                                ? Text(
                                    'License: ${driver.licenseNumber}',
                                    style: const TextStyle(fontSize: 12),
                                  )
                                : null,
                            value: driver.id,
                            groupValue: _selectedId ?? codriverState.selectedCoDriver?.id ?? 'none',
                            onChanged: (value) {
                              setState(() => _selectedId = value);
                              final selected = drivers.firstWhere((d) => d.id == value);
                              ref.read(codriverProvider.notifier).selectCoDriver(selected);
                            },
                            activeColor: AppColors.primaryBlue,
                            contentPadding: EdgeInsets.zero,
                          );
                        }),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.xl),

                  // ========== زر تبديل الأدوار ==========
                  AppButton(
                    label: isArabic ? 'تبديل الأدوار' : 'SWITCH DRIVERS',
                    icon: Icons.swap_horiz,
                    isLoading: codriverState.isSwitching,
                    onPressed: codriverState.isSwitching
                        ? null
                        : () async {
                            final confirm = await showDialog<bool>(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: Text(isArabic ? 'تأكيد التبديل' : 'Confirm Switch'),
                                content: Text(
                                  isArabic
                                      ? 'هل أنت متأكد من تبديل الأدوار؟ ستصبح السائق المساعد.'
                                      : 'Are you sure you want to switch roles? You will become the co-driver.',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, false),
                                    child: Text(MaterialLocalizations.of(context).cancelButtonLabel),
                                  ),
                                  FilledButton(
                                    onPressed: () => Navigator.pop(context, true),
                                    child: Text(MaterialLocalizations.of(context).okButtonLabel),
                                  ),
                                ],
                              ),
                            );

                            if (confirm == true && mounted) {
                              await ref.read(codriverProvider.notifier).switchDrivers();
                              if (mounted) {
                                // ignore: use_build_context_synchronously
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      isArabic
                                          ? '✅ تم تبديل الأدوار بنجاح'
                                          : '✅ Roles switched successfully',
                                    ),
                                    backgroundColor: AppColors.successGreen,
                                  ),
                                );
                                // ignore: use_build_context_synchronously
                                context.go('/home');
                              }
                            }
                          },
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ========== معلومات إضافية ==========
                  if (codriverState.selectedCoDriver != null &&
                      codriverState.selectedCoDriver!.id != 'none')
                    EldCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isArabic ? 'السائق المساعد المحدد' : 'Selected Co-Driver',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: AppSpacing.sm),
                          Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: AppColors.warningYellow.withValues(alpha: 0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.person_outline,
                                  color: AppColors.warningYellow,
                                  size: 22,
                                ),
                              ),
                              const SizedBox(width: AppSpacing.md),
                              Expanded(
                                child: Text(
                                  codriverState.selectedCoDriver!.name,
                                  style: const TextStyle(
                                    fontSize: AppTypography.bodySize,
                                    fontWeight: AppTypography.semiBold,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: AppSpacing.sm,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.warningYellow.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Text(
                                  'Co-Driver',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: AppColors.warningYellow,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}
