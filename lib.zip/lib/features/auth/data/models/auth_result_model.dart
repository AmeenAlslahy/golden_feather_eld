import '../../domain/entities/auth_result.dart';
import 'user_model.dart';

/// نموذج نتيجة المصادقة
class AuthResultModel extends AuthResult {
  const AuthResultModel({
    required super.user,
    required super.token,
    required super.refreshToken,
    required super.expiresAt,
  });

  /// إنشاء من JSON
  factory AuthResultModel.fromJson(Map<String, dynamic> json) {
    return AuthResultModel(
      user: UserModel.fromJson(json['user'] ?? {}),
      token: json['token'] ?? json['access_token'] ?? '',
      refreshToken: json['refresh_token'] ?? '',
      expiresAt: DateTime.tryParse(json['expires_at'] ?? '') ??
          DateTime.now().add(const Duration(hours: 24)),
    );
  }

  /// التحويل إلى JSON
  Map<String, dynamic> toJson() {
    return {
      'user': UserModel.fromEntity(user).toJson(),
      'token': token,
      'refresh_token': refreshToken,
      'expires_at': expiresAt.toIso8601String(),
    };
  }
}



