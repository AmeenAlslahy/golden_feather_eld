import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/entities/nano_auth_entities.dart';
import '../../domain/entities/nano_auth_failures.dart';
import '../../domain/repositories/nano_auth_repository.dart';
import '../datasources/nano_auth_remote_data_source.dart';
import '../datasources/nano_token_store.dart';

class NanoAuthRepositoryImpl implements NanoAuthRepository {
  final NanoAuthRemoteDataSource remoteDataSource;
  final NanoTokenStore tokenStore;

  NanoAuthRepositoryImpl({
    required this.remoteDataSource,
    required this.tokenStore,
  });

  @override
  Future<Either<Failure, NanoAccessSession>> login(NanoCredentials credentials, String baseUrl) async {
    try {
      final session = await remoteDataSource.login(credentials, baseUrl);
      await tokenStore.saveSession(session);
      return Right(session);
    } catch (e) {
      if (e is Failure) {
        return Left(e);
      }
      return Left(ServerFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> logout() async {
    try {
      await tokenStore.clearSession();
      // Wait for backend contract if there's a specific logout endpoint to call
      return const Right(null);
    } catch (e) {
      if (e is Failure) return Left(e);
      return Left(SecureStorageFailure(message: e.toString()));
    }
  }

  @override
  Future<Either<Failure, NanoAccessSession?>> restoreSession(String baseUrl) async {
    try {
      final session = await tokenStore.getSession();
      if (session == null) {
        return const Right(null);
      }
      
      // Basic expiry check if available
      if (session.expiresAt != null) {
        if (DateTime.now().isAfter(session.expiresAt!)) {
          await tokenStore.clearSession();
          return const Left(TokenExpiredFailure());
        }
      }
      
      // We don't have a 'me' endpoint yet in the contract to strictly validate token origin/liveliness
      // Therefore, if it exists and hasn't explicitly expired, we return it.
      
      return Right(session);
    } catch (e) {
      await tokenStore.clearSession(); // Fallback on corruption
      if (e is Failure) return Left(e);
      return Left(SecureStorageFailure(message: e.toString()));
    }
  }
}
