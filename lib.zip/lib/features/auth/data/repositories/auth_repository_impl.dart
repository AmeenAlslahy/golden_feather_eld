import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/api_exception.dart';
import '../../../../core/network/network_info.dart';
import '../../../../core/utils/logger.dart';
import '../../domain/entities/auth_credentials.dart';
import '../../domain/entities/auth_result.dart';
import '../../domain/entities/user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_local_data_source.dart';
import '../datasources/auth_remote_data_source.dart';
import '../models/user_model.dart';

/// تنفيذ مستودع المصادقة
class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource _remoteDataSource;
  final AuthLocalDataSource _localDataSource;
  final NetworkInfo _networkInfo;

  AuthRepositoryImpl({
    required AuthRemoteDataSource remoteDataSource,
    required AuthLocalDataSource localDataSource,
    required NetworkInfo networkInfo,
  })  : _remoteDataSource = remoteDataSource,
        _localDataSource = localDataSource,
        _networkInfo = networkInfo;

  @override
  Future<Either<Failure, AuthResult>> login(AuthCredentials credentials) async {
    // التحقق من الاتصال
    final isConnected = await _networkInfo.isConnected;
    if (!isConnected) {
      return const Left(NetworkFailure());
    }

    try {
      final result = await _remoteDataSource.login(
        username: credentials.username,
        password: credentials.password,
        serverUrl: credentials.serverUrl,
      );

      // حفظ البيانات محلياً
      await _localDataSource.saveToken(result.token);
      await _localDataSource.saveRefreshToken(result.refreshToken);
      await _localDataSource.saveUser(UserModel.fromEntity(result.user));

      AppLogger.info('User logged in: ${result.user.fullName}');
      return Right(result);
    } catch (e) {
      AppLogger.error('Login failed', e);
      if (e is ApiException) {
        return Left(ServerFailure(
          message: e.message,
          arabicMessage: e.arabicMessage,
          statusCode: e.statusCode,
        ));
      }
      return const Left(ServerFailure(
        message: 'فشل تسجيل الدخول',
        arabicMessage: 'فشل تسجيل الدخول',
      ));
    }
  }

  @override
  Future<Either<Failure, bool>> logout() async {
    try {
      await _remoteDataSource.logout();
    } catch (e) {
      // تجاهل أخطاء الخادم
    }

    await _localDataSource.clearAll();
    AppLogger.info('User logged out');
    return const Right(true);
  }

  // تنفيذ وهمي لإنشاء الحساب
  @override
  Future<Either<Failure, bool>> register({
    required String fullName,
    required String username,
    required String password,
  }) async {
    await Future.delayed(const Duration(seconds: 1));
    return const Right(true); // نجاح وهمي
  }

  // تنفيذ وهمي لاستعادة كلمة المرور
  @override
  Future<Either<Failure, bool>> forgotPassword(String email) async {
    await Future.delayed(const Duration(seconds: 1));
    return const Right(true); // نجاح وهمي
  }

  @override
  Future<Either<Failure, AuthResult>> refreshToken(String refreshToken) async {
    final isConnected = await _networkInfo.isConnected;
    if (!isConnected) {
      return const Left(NetworkFailure());
    }

    try {
      final result = await _remoteDataSource.refreshToken(refreshToken);

      await _localDataSource.saveToken(result.token);
      await _localDataSource.saveRefreshToken(result.refreshToken);
      await _localDataSource.saveUser(UserModel.fromEntity(result.user));

      return Right(result);
    } catch (e) {
      // فشل التجديد - مسح البيانات
      await _localDataSource.clearAll();

      if (e is ApiException) {
        return Left(AuthFailure(
          message: e.message,
          arabicMessage: e.arabicMessage,
        ));
      }
      return const Left(AuthFailure());
    }
  }

  @override
  Future<Either<Failure, User?>> getCurrentUser() async {
    final hasUser = await _localDataSource.hasUser();
    if (!hasUser) return const Right(null);

    final user = await _localDataSource.getUser();
    return Right(user);
  }

  @override
  Future<bool> isLoggedIn() async {
    return _localDataSource.hasUser();
  }

  @override
  Future<Either<Failure, bool>> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    try {
      await _remoteDataSource.login(
        username: '', // غير مطلوب لتغيير كلمة المرور
        password: oldPassword,
      );
      return const Right(true);
    } catch (e) {
      return const Left(ServerFailure(
        message: 'فشل تغيير كلمة المرور',
        arabicMessage: 'كلمة المرور القديمة غير صحيحة',
      ));
    }
  }

  // ========== كلمة المرور المحلية (من password_service.dart الأصلي) ==========

  @override
  Future<bool> verifyLocalPassword(String password) async {
    final storedPassword = await _localDataSource.getLocalPassword();
    if (storedPassword == null || storedPassword.isEmpty) return true;
    return storedPassword == password;
  }

  @override
  Future<void> setLocalPassword(String password) async {
    await _localDataSource.saveLocalPassword(password);
  }

  @override
  Future<void> removeLocalPassword() async {
    await _localDataSource.removeLocalPassword();
  }

  @override
  Future<bool> hasLocalPassword() async {
    final password = await _localDataSource.getLocalPassword();
    return password != null && password.isNotEmpty;
  }
}



