import 'package:fpdart/fpdart.dart';
import '../../../../core/error/failure.dart';
import '../../../../core/network/network_info.dart';
import '../../../../core/config/server_config_provider.dart';

import 'package:golden_feather_eld/core/domain/entities/user.dart';
import '../../domain/entities/auth_session.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../../../backend/contracts/auth_backend.dart';
import '../datasources/user_store.dart';
import '../datasources/auth_session_store.dart';
import '../models/auth_session_dto.dart';
import 'package:golden_feather_eld/core/data/models/user_model.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthBackend _authBackend;
  final AuthSessionStore _sessionStore;
  final UserStore _userStore;
  final ServerConfigProvider _configProvider;
  final NetworkInfo _networkInfo;

  AuthRepositoryImpl({
    required AuthBackend authBackend,
    required AuthSessionStore sessionStore,
    required UserStore userStore,
    required ServerConfigProvider configProvider,
    required NetworkInfo networkInfo,
  })  : _authBackend = authBackend,
        _sessionStore = sessionStore,
        _userStore = userStore,
        _configProvider = configProvider,
        _networkInfo = networkInfo;

  String? _getServerUrl() {
    final url = _configProvider.serverUrl;
    if (url.isEmpty) return null;
    return url;
  }

  @override
  Future<Either<Failure, User>> login({
    required String email,
    required String password,
  }) async {
    final serverUrl = _getServerUrl();
    if (serverUrl == null) return const Left(MissingConfigurationFailure());
    if (!_networkInfo.isConnected) return const Left(NetworkFailure());

    final backendType = _configProvider.backendType;
    final result = await _authBackend.login(
      email: email,
      password: password,
      serverUrl: serverUrl,
      backendType: backendType,
    );

    return result.fold(
      (error) {
        if (error.code == 'unauthorized') return const Left(InvalidCredentialsFailure());
        return Left(ServerFailure(message: error.code));
      },
      (rawJson) async {
        final sessionDto = AuthSessionDto.create(
          serverOrigin: rawJson['serverOrigin'],
          sessionCredential: rawJson['credential'],
          userModel: UserModel.fromMetadata(rawJson['user'], defaultEmail: email),
        );

        await _sessionStore.saveSession(sessionDto.toEntity());
        await _userStore.saveUser(sessionDto.userModel);
        return Right(sessionDto.userModel);
      }
    );
  }

  @override
  Future<Either<Failure, User>> checkAndRestoreSession() async {
    final serverUrl = _getServerUrl();
    if (serverUrl == null) {
      await _clearLocalData();
      return const Left(MissingConfigurationFailure());
    }

    final savedSession = await _sessionStore.getSession();
    if (savedSession == null) return const Left(SessionMissingFailure());

    if (!_isValidOrigin(serverUrl, savedSession)) {
      await _clearLocalData();
      return const Left(SessionMissingFailure());
    }

    if (!_networkInfo.isConnected) {
      return await _handleOfflineSession();
    }

    return await _validateRemoteSession(savedSession);
  }

  Future<void> _clearLocalData() async {
    await _sessionStore.clearSession();
    await _userStore.clearUser();
  }

  bool _isValidOrigin(String serverUrl, AuthSession session) {
    try {
      final currentOrigin = Uri.parse(serverUrl).origin;
      return session.belongsTo(currentOrigin);
    } catch (_) {
      return false;
    }
  }

  Future<Either<Failure, User>> _handleOfflineSession() async {
    final user = await _userStore.getUser();
    if (user != null) return Right(user);
    return const Left(NetworkFailure());
  }

  Future<Either<Failure, User>> _validateRemoteSession(AuthSession savedSession) async {
    final backendType = _configProvider.backendType;
    final sessionDto = AuthSessionDto.fromEntity(savedSession);
    
    final result = await _authBackend.validateSession(
      serverOrigin: sessionDto.serverOrigin,
      sessionCredential: sessionDto.sessionCredential,
      backendType: backendType,
    );

    return result.fold(
      (error) async {
        if (error.code == 'unauthorized') {
          await _clearLocalData();
          return const Left(AuthFailure());
        }
        return Left(ServerFailure(message: error.code));
      },
      (rawJson) async {
        final validSessionDto = AuthSessionDto.create(
          serverOrigin: rawJson['serverOrigin'],
          sessionCredential: rawJson['credential'],
          userModel: UserModel.fromMetadata(rawJson['user']),
        );
        
        await _sessionStore.saveSession(validSessionDto.toEntity());
        await _userStore.saveUser(validSessionDto.userModel);
        return Right(validSessionDto.userModel);
      }
    );
  }

  @override
  Future<Either<Failure, Unit>> logout() async {
    final savedSession = await _sessionStore.getSession();
    if (savedSession != null) {
      if (_networkInfo.isConnected) {
        final sessionDto = AuthSessionDto.fromEntity(savedSession);
        await _authBackend.logout(
          serverOrigin: sessionDto.serverOrigin,
          sessionCredential: sessionDto.sessionCredential,
          backendType: _configProvider.backendType,
        );
      }
    }
    await _clearLocalData();
    return const Right(unit);
  }

  @override
  Future<Either<Failure, User>> getCurrentSession() async {
    final savedSession = await _sessionStore.getSession();
    if (savedSession != null) {
      final serverUrl = _getServerUrl();
      if (serverUrl != null) {
        try {
          final currentOrigin = Uri.parse(serverUrl).origin;
          if (savedSession.belongsTo(currentOrigin)) {
            final user = await _userStore.getUser();
            if (user != null) {
              return Right(user);
            }
          }
        } catch (_) {}
      }
    }
    return const Left(SessionMissingFailure());
  }
}
