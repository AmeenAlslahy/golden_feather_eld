import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../../../core/utils/logger.dart';
import '../models/user_model.dart';

/// مصدر البيانات المحلي للمصادقة
abstract class AuthLocalDataSource {
  /// حفظ رمز المصادقة
  Future<void> saveToken(String token);

  /// حفظ رمز التجديد
  Future<void> saveRefreshToken(String refreshToken);

  /// الحصول على رمز المصادقة
  Future<String?> getToken();

  /// الحصول على رمز التجديد
  Future<String?> getRefreshToken();

  /// حفظ المستخدم
  Future<void> saveUser(UserModel user);

  /// الحصول على المستخدم المحفوظ
  Future<UserModel?> getUser();

  /// التحقق من وجود مستخدم مسجل
  Future<bool> hasUser();

  /// حفظ كلمة المرور المحلية
  Future<void> saveLocalPassword(String password);

  /// الحصول على كلمة المرور المحلية
  Future<String?> getLocalPassword();

  /// إزالة كلمة المرور المحلية
  Future<void> removeLocalPassword();

  /// مسح جميع بيانات المصادقة
  Future<void> clearAll();
}

/// تنفيذ مصدر البيانات المحلي
class AuthLocalDataSourceImpl implements AuthLocalDataSource {
  final FlutterSecureStorage _secureStorage;
  final LocalStorageService _localStorage;

  AuthLocalDataSourceImpl({
    FlutterSecureStorage? secureStorage,
    required LocalStorageService localStorage,
  })  : _secureStorage = secureStorage ?? const FlutterSecureStorage(),
        _localStorage = localStorage;

  static const _tokenKey = 'auth_token';
  static const _refreshTokenKey = 'refresh_token';
//   static const _userKey = 'cached_user';
//   static const _localPasswordKey = 'local_password';

  @override
  Future<void> saveToken(String token) async {
    await _secureStorage.write(key: _tokenKey, value: token);
    AppLogger.debug('Token saved');
  }

  @override
  Future<void> saveRefreshToken(String refreshToken) async {
    await _secureStorage.write(key: _refreshTokenKey, value: refreshToken);
    AppLogger.debug('Refresh token saved');
  }

  @override
  Future<String?> getToken() async {
    return _secureStorage.read(key: _tokenKey);
  }

  @override
  Future<String?> getRefreshToken() async {
    return _secureStorage.read(key: _refreshTokenKey);
  }

  @override
  Future<void> saveUser(UserModel user) async {
    await _localStorage.saveUserData(user.toJson());
    AppLogger.debug('User saved: ${user.fullName}');
  }

  @override
  Future<UserModel?> getUser() async {
    final userData = await _localStorage.getUserData();
    if (userData == null) return null;
    try {
      return UserModel.fromJson(userData);
    } catch (e) {
      AppLogger.error('Failed to parse user data', e);
      return null;
    }
  }

  @override
  Future<bool> hasUser() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }

  @override
  Future<void> saveLocalPassword(String password) async {
    await _localStorage.setPassword(password);
  }

  @override
  Future<String?> getLocalPassword() async {
    final password = _localStorage.password;
    return password.isEmpty ? null : password;
  }

  @override
  Future<void> removeLocalPassword() async {
    await _localStorage.removePassword();
  }

  @override
  Future<void> clearAll() async {
    await _secureStorage.deleteAll();
    await _localStorage.removePassword();
    AppLogger.info('All auth data cleared');
  }
}



