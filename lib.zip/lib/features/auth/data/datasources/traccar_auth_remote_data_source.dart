import 'package:dio/dio.dart';
import '../../../../core/network/api_exception.dart';
import '../../domain/entities/traccar_session.dart';

abstract class TraccarAuthRemoteDataSource {
  /// يقوم بتسجيل الدخول وإنشاء جلسة Traccar
  Future<TraccarSession> login({
    required String email,
    required String password,
    required String serverUrl,
  });

  /// يتحقق من صحة الجلسة الحالية
  Future<TraccarSession> validateSession({
    required TraccarSession currentSession,
  });

  /// ينهي الجلسة من الخادم
  Future<void> logout({
    required TraccarSession currentSession,
  });
}

class TraccarAuthRemoteDataSourceImpl implements TraccarAuthRemoteDataSource {
  final Dio _dio;

  TraccarAuthRemoteDataSourceImpl(this._dio);

  String _normalizeOrigin(String url) {
    if (url.isEmpty) throw const ApiException(message: 'Invalid server URL', arabicMessage: 'عنوان الخادم غير صالح');
    try {
      final uri = Uri.parse(url);
      if (uri.scheme.isEmpty || uri.host.isEmpty) {
        throw const ApiException(message: 'Invalid server URL format', arabicMessage: 'صيغة عنوان الخادم غير صالحة');
      }
      return uri.origin;
    } catch (e) {
      throw const ApiException(message: 'Invalid server URL format', arabicMessage: 'صيغة عنوان الخادم غير صالحة');
    }
  }

  @override
  Future<TraccarSession> login({
    required String email,
    required String password,
    required String serverUrl,
  }) async {
    final origin = _normalizeOrigin(serverUrl);

    try {
      final response = await _dio.post(
        '$origin/api/session',
        data: {
          'email': email,
          'password': password,
        },
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          // لا تتبع التحويلات لضمان عدم تسريب بيانات المصادقة لـ Origin مختلف
          followRedirects: false, 
          // تجنب رمي أخطاء للتمكن من فحص الرد وتوحيد الأخطاء
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      if (response.statusCode == 401) {
        throw const ApiException(message: 'Invalid email or password', arabicMessage: 'البريد الإلكتروني أو كلمة المرور غير صحيحة', statusCode: 401);
      } else if (response.statusCode == 404 || response.statusCode == 405) {
        throw ApiException(message: 'Invalid Traccar API endpoint', arabicMessage: 'نقطة اتصال غير صالحة', statusCode: response.statusCode);
      } else if (response.statusCode != 200) {
        throw ApiException(message: 'Server error: ${response.statusCode}', arabicMessage: 'خطأ في الخادم', statusCode: response.statusCode);
      }

      // تحليل الكوكي لاستخراج JSESSIONID
      final setCookieHeaders = response.headers.map['set-cookie'] ?? [];
      String? jsessionid;
      
      for (var cookie in setCookieHeaders) {
        final parts = cookie.split(';');
        for (var part in parts) {
          part = part.trim();
          if (part.startsWith('JSESSIONID=')) {
            jsessionid = part.substring('JSESSIONID='.length);
            break;
          }
        }
        if (jsessionid != null) break;
      }

      if (jsessionid == null || jsessionid.isEmpty) {
        throw const ApiException(message: 'Missing session cookie from server', arabicMessage: 'ملف تعريف ارتباط الجلسة مفقود');
      }

      final userData = response.data;
      if (userData is! Map<String, dynamic>) {
        throw const ApiException(message: 'Invalid user payload format', arabicMessage: 'صيغة بيانات المستخدم غير صالحة');
      }

      return TraccarSession.create(
        serverOrigin: origin,
        sessionCredential: jsessionid,
        userMetadata: userData,
      );
    } on DioException catch (e) {
      throw ApiException(message: 'Network error: ${e.message}', arabicMessage: 'خطأ في الشبكة');
    }
  }

  @override
  Future<TraccarSession> validateSession({
    required TraccarSession currentSession,
  }) async {
    try {
      final response = await _dio.get(
        '${currentSession.serverOrigin}/api/session',
        options: Options(
          headers: {
            'Cookie': 'JSESSIONID=${currentSession.sessionCredential}',
          },
          followRedirects: false,
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      if (response.statusCode == 401 || response.statusCode == 403 || response.statusCode == 404) {
        throw const ApiException(message: 'Session expired or invalid', arabicMessage: 'الجلسة منتهية أو غير صالحة', statusCode: 401);
      } else if (response.statusCode != 200) {
        throw ApiException(message: 'Server error: ${response.statusCode}', arabicMessage: 'خطأ في الخادم', statusCode: response.statusCode);
      }

      final userData = response.data;
      if (userData is! Map<String, dynamic>) {
        throw const ApiException(message: 'Invalid user payload format', arabicMessage: 'صيغة بيانات المستخدم غير صالحة');
      }

      return TraccarSession.create(
        serverOrigin: currentSession.serverOrigin,
        sessionCredential: currentSession.sessionCredential,
        userMetadata: userData,
      );
    } on DioException catch (e) {
      // نرمي خطأ شبكة للتمييز بين عدم الاتصال وانتهاء الجلسة
      throw ApiException(message: 'Network error during validation: ${e.message}', arabicMessage: 'خطأ شبكي أثناء التحقق من الجلسة');
    }
  }

  @override
  Future<void> logout({
    required TraccarSession currentSession,
  }) async {
    try {
      await _dio.delete(
        '${currentSession.serverOrigin}/api/session',
        options: Options(
          headers: {
            'Cookie': 'JSESSIONID=${currentSession.sessionCredential}',
          },
          followRedirects: false,
          validateStatus: (status) => true,
        ),
      );
    } catch (e) {
      // الفشل في إنهاء الجلسة من الخادم (بسبب الشبكة مثلاً) لا يجب أن يمنع تسجيل الخروج محلياً
    }
  }
}
