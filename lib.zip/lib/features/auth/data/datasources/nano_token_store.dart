import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../domain/entities/nano_auth_entities.dart';
import '../../domain/entities/nano_auth_failures.dart';

abstract class NanoTokenStore {
  Future<void> saveSession(NanoAccessSession session);
  Future<NanoAccessSession?> getSession();
  Future<void> clearSession();
}

class NanoTokenStoreImpl implements NanoTokenStore {
  final FlutterSecureStorage secureStorage;
  static const String _sessionKey = 'nano_access_session';

  NanoTokenStoreImpl({required this.secureStorage});

  @override
  Future<void> saveSession(NanoAccessSession session) async {
    try {
      final jsonMap = {
        'accessToken': session.accessToken,
        'tokenType': session.tokenType,
        'expiresAt': session.expiresAt?.toIso8601String(),
        'userId': session.userId,
        'provider': session.provider,
        'profile': session.profile != null ? {
          'id': session.profile!.id,
          'name': session.profile!.name,
          'email': session.profile!.email,
          'mobile': session.profile!.mobile,
          'companyId': session.profile!.companyId,
          'departmentId': session.profile!.departmentId,
          'refType': session.profile!.refType,
          'refId': session.profile!.refId,
          'isActivated': session.profile!.isActivated,
        } : null,
      };
      
      await secureStorage.write(key: _sessionKey, value: jsonEncode(jsonMap));
    } catch (e) {
      throw SecureStorageFailure(message: 'فشل حفظ جلسة Nano: $e');
    }
  }

  @override
  Future<NanoAccessSession?> getSession() async {
    try {
      final value = await secureStorage.read(key: _sessionKey);
      if (value == null) return null;

      final Map<String, dynamic> jsonMap = jsonDecode(value);
      
      NanoUserProfile? profile;
      if (jsonMap['profile'] != null) {
        final p = jsonMap['profile'];
        profile = NanoUserProfile(
          id: p['id'] as int,
          name: p['name'] as String,
          email: p['email'] as String,
          mobile: p['mobile'] as String,
          companyId: p['companyId'] as String?,
          departmentId: p['departmentId'] as String?,
          refType: p['refType'] as String?,
          refId: p['refId'] as String?,
          isActivated: p['isActivated'] as bool? ?? true,
        );
      }

      return NanoAccessSession(
        accessToken: jsonMap['accessToken'] as String,
        tokenType: jsonMap['tokenType'] as String,
        expiresAt: jsonMap['expiresAt'] != null ? DateTime.tryParse(jsonMap['expiresAt']) : null,
        userId: jsonMap['userId'] as int,
        provider: jsonMap['provider'] as String,
        profile: profile,
      );
    } catch (e) {
      // If parsing fails, the session is corrupted
      await clearSession();
      return null;
    }
  }

  @override
  Future<void> clearSession() async {
    try {
      await secureStorage.delete(key: _sessionKey);
    } catch (e) {
      throw SecureStorageFailure(message: 'فشل مسح جلسة Nano: $e');
    }
  }
}
