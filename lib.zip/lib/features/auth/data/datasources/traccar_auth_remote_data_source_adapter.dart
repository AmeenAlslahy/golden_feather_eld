import '../../../../core/config/app_environment.dart';
import '../../../../core/network/api_exception.dart';
import '../models/auth_result_model.dart';
import '../models/user_model.dart';
import '../../domain/entities/user.dart';
import 'auth_remote_data_source.dart';
import 'traccar_auth_remote_data_source.dart';
import 'traccar_session_store.dart';

/// محول يربط بين واجهة AuthRemoteDataSource العامة ونظام مصادقة Traccar
class TraccarAuthRemoteDataSourceAdapter implements AuthRemoteDataSource {
  final TraccarAuthRemoteDataSource _traccarAuthRemoteDataSource;
  final TraccarSessionStore _sessionStore;

  TraccarAuthRemoteDataSourceAdapter({
    required TraccarAuthRemoteDataSource traccarAuthRemoteDataSource,
    required TraccarSessionStore sessionStore,
  })  : _traccarAuthRemoteDataSource = traccarAuthRemoteDataSource,
        _sessionStore = sessionStore;

  @override
  Future<AuthResultModel> login({
    required String username,
    required String password,
    String? serverUrl,
  }) async {
    final effectiveUrl = (serverUrl != null && serverUrl.trim().isNotEmpty)
        ? serverUrl.trim()
        : AppEnvironmentConfig.traccarBaseUrl;

    if (effectiveUrl.isEmpty) {
      throw const ApiException(
        message: 'Traccar Server URL is missing',
        arabicMessage: 'عنوان خادم Traccar مفقود',
      );
    }

    // استدعاء تسجيل دخول Traccar الفعلي
    final session = await _traccarAuthRemoteDataSource.login(
      email: username,
      password: password,
      serverUrl: effectiveUrl,
    );

    // حفظ الجلسة محلياً
    await _sessionStore.saveSession(session);

    // تحويل بيانات المستخدم من Traccar إلى UserModel
    final userMetaData = session.userMetadata;
    final userModel = UserModel(
      id: userMetaData['id']?.toString() ?? '',
      username: userMetaData['email'] ?? username,
      email: userMetaData['email'] ?? username,
      fullName: userMetaData['name'] ?? username,
      phone: userMetaData['phone'],
      role: (userMetaData['administrator'] == true)
          ? UserRole.admin
          : UserRole.fieldWorker,
      isActive: !(userMetaData['disabled'] == true),
      createdAt: DateTime.now(),
    );

    return AuthResultModel(
      user: userModel,
      token: session.sessionCredential,
      refreshToken: session.sessionCredential,
      expiresAt: DateTime.now().add(const Duration(days: 7)),
    );
  }

  @override
  Future<AuthResultModel> refreshToken(String refreshToken) async {
    final currentSession = await _sessionStore.getSession();
    if (currentSession == null) {
      throw const ApiException(
        message: 'No active Traccar session found',
        arabicMessage: 'لم يتم العثور على جلسة Traccar نشطة',
        statusCode: 401,
      );
    }

    final validatedSession = await _traccarAuthRemoteDataSource.validateSession(
      currentSession: currentSession,
    );
    await _sessionStore.saveSession(validatedSession);

    final userMetaData = validatedSession.userMetadata;
    final userModel = UserModel(
      id: userMetaData['id']?.toString() ?? '',
      username: userMetaData['email'] ?? '',
      email: userMetaData['email'] ?? '',
      fullName: userMetaData['name'] ?? '',
      phone: userMetaData['phone'],
      role: (userMetaData['administrator'] == true)
          ? UserRole.admin
          : UserRole.fieldWorker,
      isActive: !(userMetaData['disabled'] == true),
      createdAt: DateTime.now(),
    );

    return AuthResultModel(
      user: userModel,
      token: validatedSession.sessionCredential,
      refreshToken: validatedSession.sessionCredential,
      expiresAt: DateTime.now().add(const Duration(days: 7)),
    );
  }

  @override
  Future<bool> logout() async {
    try {
      final currentSession = await _sessionStore.getSession();
      if (currentSession != null) {
        await _traccarAuthRemoteDataSource.logout(currentSession: currentSession);
      }
    } catch (_) {
      // التجاهل عند وجود أخطاء شبكة أثناء Logout
    } finally {
      await _sessionStore.clearSession();
    }
    return true;
  }
}
