import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exception.dart';
import '../models/auth_result_model.dart';

/// مصدر البيانات البعيد للمصادقة
abstract class AuthRemoteDataSource {
  /// تسجيل الدخول
  Future<AuthResultModel> login({
    required String username,
    required String password,
    String? serverUrl,
  });

  /// تجديد الرمز
  Future<AuthResultModel> refreshToken(String refreshToken);

  /// تسجيل الخروج من الخادم
  Future<bool> logout();
}

/// تنفيذ مصدر البيانات البعيد
class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final DioClient _client;

  AuthRemoteDataSourceImpl(this._client);

  @override
  Future<AuthResultModel> login({
    required String username,
    required String password,
    String? serverUrl,
  }) async {
    try {
      await Future.delayed(const Duration(seconds: 1)); // محاكاة الاتصال بالشبكة
      
      if (username == 'admin' && password == 'admin123') {
        return AuthResultModel.fromJson({
          'user': const {
            'id': '1',
            'username': 'admin',
            'first_name': 'Admin',
            'last_name': 'User',
            'email': 'admin@example.com',
          },
          'token': 'mock_token_xyz',
          'refresh_token': 'mock_refresh_token_xyz',
          'expires_at': DateTime.now().add(const Duration(days: 7)).toIso8601String(),
        });
      } else {
        throw ApiException(
          message: 'Invalid credentials',
          arabicMessage: 'اسم المستخدم أو كلمة المرور غير صحيحة',
        );
      }
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(
        message: 'فشل تسجيل الدخول',
        arabicMessage: 'فشل تسجيل الدخول، يرجى التحقق من البيانات',
      );
    }
  }

  @override
  Future<AuthResultModel> refreshToken(String refreshToken) async {
    try {
      final response = await _client.post(
        '/api/auth/refresh',
        data: {'refresh_token': refreshToken},
      );

      return AuthResultModel.fromJson(response.data);
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(
        message: 'فشل تجديد الجلسة',
        arabicMessage: 'فشل تجديد الجلسة، يرجى تسجيل الدخول مجدداً',
      );
    }
  }

  @override
  Future<bool> logout() async {
    try {
      // محاكاة تسجيل الخروج نظراً لأن الدخول وهمي حالياً
      await Future.delayed(const Duration(milliseconds: 300));
      return true;
    } catch (e) {
      return true;
    }
  }
}



