import 'package:dio/dio.dart';
import '../../domain/entities/nano_auth_entities.dart';
import '../../domain/entities/nano_auth_failures.dart';
import '../../../../core/errors/failures.dart' hide InvalidCredentialsFailure;

abstract class NanoAuthRemoteDataSource {
  Future<NanoAccessSession> login(NanoCredentials credentials, String baseUrl);
}

class NanoAuthRemoteDataSourceImpl implements NanoAuthRemoteDataSource {
  final Dio dio;

  NanoAuthRemoteDataSourceImpl({required this.dio});

  @override
  Future<NanoAccessSession> login(NanoCredentials credentials, String baseUrl) async {
    try {
      final response = await dio.post(
        '$baseUrl/api/v1/auth/login',
        data: {
          'provider': credentials.provider,
          'loginAttribute': credentials.loginAttribute,
          'login': credentials.login,
          'password': credentials.password, // Still waiting for final contract
          'profile': credentials.profile ? 1 : 0,
          // 'api_version': 'v2', // Included in docs example, might be needed
          // 'is_access_token': 1, // Included in docs example, might be needed
        },
        options: Options(
          headers: {
            'Accept': 'application/json',
          },
        ),
      );

      final data = response.data;

      // Handle custom failure structures specified in docs (HTTP 200 with status: false)
      if (response.statusCode == 200 && data is Map<String, dynamic> && data['status'] == false) {
        return _handleFailedAuthResponse(data);
      }

      // Check for strictly successful structure
      if (response.statusCode == 200 && data is Map<String, dynamic> && data['status'] == true && data['code'] == 200) {
        
        final token = data['token'] as String?;
        final tokenType = data['token_type'] as String?;
        final userId = data['user_id'] as int?;

        if (token == null || token.isEmpty || tokenType == null || userId == null) {
          throw const MalformedAuthResponseFailure(message: 'استجابة الخادم تفتقد للتوكن أو المعرف');
        }

        DateTime? expiresAt;
        if (data['expires_at'] != null) {
          expiresAt = DateTime.tryParse(data['expires_at'].toString());
        }

        NanoUserProfile? profile;
        if (data['profile'] != null && data['profile'] is Map<String, dynamic>) {
          final p = data['profile'];
          profile = NanoUserProfile(
            id: p['id'] as int? ?? userId,
            name: p['name']?.toString() ?? '',
            email: p['email']?.toString() ?? '',
            mobile: p['mobile']?.toString() ?? '',
            companyId: p['companys_id']?.toString(),
            departmentId: p['departments_id']?.toString(),
            refType: p['ref_type']?.toString(),
            refId: p['ref_id']?.toString(),
            isActivated: p['is_activated'] == 1 || p['is_activated'] == true,
          );
        }

        return NanoAccessSession(
          accessToken: token,
          tokenType: tokenType,
          expiresAt: expiresAt,
          userId: userId,
          provider: credentials.provider,
          profile: profile,
        );
      }

      throw const MalformedAuthResponseFailure(message: 'لم يتم العثور على صيغة استجابة صحيحة لتسجيل الدخول');

    } on DioException catch (e) {
      if (e.response != null) {
        final statusCode = e.response!.statusCode;
        final data = e.response!.data;

        if (statusCode == 400 || statusCode == 401 || statusCode == 403) {
          if (data is Map<String, dynamic> && data['error'] != null) {
             final errorMsg = data['error']['message']?.toString();
             if (statusCode == 401 || statusCode == 403) {
               throw PermissionDeniedFailure(message: errorMsg);
             }
             throw InvalidCredentialsFailure(message: errorMsg);
          }
        }
      }
      
      if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout) {
        throw const ServerFailure(message: 'انتهى وقت الاتصال بالخادم');
      }
      
      throw ServerFailure(message: 'فشل الاتصال بالخادم: ${e.message}');
    } catch (e) {
      print('CAUGHT EXCEPTION: \$e (\${e.runtimeType})');
      if (e is Failure) {
        print('IT IS A FAILURE: \$e');
        rethrow;
      }
      final malformed = MalformedAuthResponseFailure(message: e.toString());
      print('THROWING MALFORMED: \$malformed (\${malformed.runtimeType})');
      throw malformed;
    }
  }

  Never _handleFailedAuthResponse(Map<String, dynamic> data) {
    if (data['process_data'] != null && data['process_data'] is Map<String, dynamic>) {
      final processData = data['process_data'];
      
      if (processData['is_banned'] == true) {
        throw const AccountBannedFailure();
      }
      if (processData['is_suspended'] == true) {
        throw const AccountSuspendedFailure();
      }
      if (processData['is_activated'] == false) {
        throw const AccountNotActivatedFailure();
      }
    }
    
    throw InvalidCredentialsFailure(message: data['message']?.toString() ?? data['error']?.toString());
  }
}
