import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/config/app_environment.dart';
import '../../../../core/network/network_providers.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../data/datasources/auth_local_data_source.dart';
import '../../data/datasources/auth_remote_data_source.dart';
import '../../data/datasources/traccar_auth_remote_data_source_adapter.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../domain/repositories/auth_repository.dart';
import 'traccar_auth_provider.dart';

/// مزود مصدر البيانات المحلي
final authLocalDataSourceProvider = Provider<AuthLocalDataSource>((ref) {
  final localStorage = ref.watch(localStorageProvider);
  return AuthLocalDataSourceImpl(localStorage: localStorage);
});

/// مزود مصدر البيانات البعيد
final authRemoteDataSourceProvider = Provider<AuthRemoteDataSource>((ref) {
  if (AppEnvironmentConfig.current == AppEnvironment.temporaryTraccar) {
    final traccarRemoteDataSource = ref.watch(traccarAuthRemoteDataSourceProvider);
    final sessionStore = ref.watch(traccarSessionStoreProvider);
    return TraccarAuthRemoteDataSourceAdapter(
      traccarAuthRemoteDataSource: traccarRemoteDataSource,
      sessionStore: sessionStore,
    );
  }

  final client = ref.watch(dioClientProvider);
  return AuthRemoteDataSourceImpl(client);
});

/// مزود مستودع المصادقة
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  final remoteDataSource = ref.watch(authRemoteDataSourceProvider);
  final localDataSource = ref.watch(authLocalDataSourceProvider);
  final networkInfo = ref.watch(networkInfoProvider);

  return AuthRepositoryImpl(
    remoteDataSource: remoteDataSource,
    localDataSource: localDataSource,
    networkInfo: networkInfo,
  );
});




