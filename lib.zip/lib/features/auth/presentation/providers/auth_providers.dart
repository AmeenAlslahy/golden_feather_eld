import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/core_providers.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../data/datasources/auth_session_store.dart';
import '../../data/datasources/user_store.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../../../backend/providers/backend_providers.dart';
import '../../../../backend/contracts/auth_backend.dart';

final authBackendProviderAlias = Provider<AuthBackend>((ref) {
  return ref.watch(authBackendProvider);
});

final authSessionStoreProvider = Provider<AuthSessionStore>((ref) {
  return AuthSessionStoreImpl();
});

final userStoreProvider = Provider<UserStore>((ref) {
  return UserStoreImpl();
});

final traccarAuthRepositoryProvider = Provider<AuthRepository>((ref) {
  final localStorage = ref.watch(localStorageProvider);
  final authBackend = ref.watch(authBackendProviderAlias);
  final sessionStore = ref.watch(authSessionStoreProvider);
  final userStore = ref.watch(userStoreProvider);
  final networkInfo = ref.watch(networkInfoProvider); // Keep for now

  return AuthRepositoryImpl(
    authBackend: authBackend,
    sessionStore: sessionStore,
    userStore: userStore,
    configProvider: localStorage,
    networkInfo: networkInfo,
  );
});
