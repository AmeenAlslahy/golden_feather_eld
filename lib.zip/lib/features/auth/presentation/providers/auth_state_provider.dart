import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/logger.dart';
import '../../domain/entities/user.dart';
import '../../domain/usercases/login.dart';
import '../../domain/usercases/logout.dart';
import '../../domain/usercases/verify_local_password.dart';
import '../../domain/repositories/auth_repository.dart';
import 'auth_providers.dart';

/// حالة المصادقة
enum AuthStatus {
  initial,      // لم يتم التحقق بعد
  authenticated, // مسجل الدخول
  unauthenticated, // غير مسجل
  loading,       // جاري التحميل
  error,         // خطأ
}

/// حالة المصادقة
class AuthState {
  final AuthStatus status;
  final User? user;
  final String? errorMessage;
  final String? arabicErrorMessage;

  const AuthState({
    this.status = AuthStatus.initial,
    this.user,
    this.errorMessage,
    this.arabicErrorMessage,
  });

  AuthState copyWith({
    AuthStatus? status,
    User? user,
    String? errorMessage,
    String? arabicErrorMessage,
  }) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      errorMessage: errorMessage,
      arabicErrorMessage: arabicErrorMessage,
    );
  }

  bool get isAuthenticated => status == AuthStatus.authenticated && user != null;
}

/// مزود حالة المصادقة
final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final loginUseCase = ref.watch(loginUseCaseProvider);
  final logoutUseCase = ref.watch(logoutUseCaseProvider);
  final verifyPassword = ref.watch(verifyLocalPasswordUseCaseProvider);

  final repository = ref.watch(authRepositoryProvider);
  return AuthNotifier(
    loginUseCase: loginUseCase,
    logoutUseCase: logoutUseCase,
    verifyPassword: verifyPassword,
    repository: repository,
  );
});

class AuthNotifier extends StateNotifier<AuthState> {
  final Login _loginUseCase;
  final Logout _logoutUseCase;
  final VerifyLocalPassword _verifyPassword;
  final AuthRepository _repository;

  AuthNotifier({
    required Login loginUseCase,
    required Logout logoutUseCase,
    required VerifyLocalPassword verifyPassword,
    required AuthRepository repository,
  })  : _loginUseCase = loginUseCase,
        _logoutUseCase = logoutUseCase,
        _verifyPassword = verifyPassword,
        _repository = repository,
        super(const AuthState());

  /// التحقق من حالة المصادقة عند بدء التطبيق
  Future<void> checkAuthStatus() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final isLoggedIn = await _repository.isLoggedIn();
      if (isLoggedIn) {
        final result = await _repository.getCurrentUser();
        result.fold(
          (failure) => state = const AuthState(status: AuthStatus.unauthenticated),
          (user) => state = AuthState(status: AuthStatus.authenticated, user: user),
        );
      } else {
        state = const AuthState(status: AuthStatus.unauthenticated);
      }
    } catch (e) {
      state = const AuthState(status: AuthStatus.unauthenticated);
    }
  }

  /// تسجيل الدخول
  Future<bool> login({
    required String username,
    required String password,
    String? serverUrl,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);

    final result = await _loginUseCase(
      username: username,
      password: password,
      serverUrl: serverUrl,
    );

    return result.fold(
      (failure) {
        state = state.copyWith(
          status: AuthStatus.error,
          errorMessage: failure.message,
          arabicErrorMessage: failure.arabicMessage,
        );
        AppLogger.error('Login failed: ${failure.message}');
        return false;
      },
      (authResult) {
        state = AuthState(
          status: AuthStatus.authenticated,
          user: authResult.user,
        );
        AppLogger.info('Login successful: ${authResult.user.fullName}');
        return true;
      },
    );
  }

  /// تسجيل الخروج
  Future<void> logout() async {
    await _logoutUseCase();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  /// التحقق من كلمة المرور المحلية
  Future<bool> verifyLocalPassword(String password) async {
    return _verifyPassword(password);
  }

  /// مسح الخطأ
  void clearError() {
    state = state.copyWith(
      errorMessage: null,
      arabicErrorMessage: null,
    );
  }
}



