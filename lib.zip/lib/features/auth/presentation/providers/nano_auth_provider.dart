import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/nano_auth_entities.dart';
import '../../domain/repositories/nano_auth_repository.dart';
import '../../../../core/errors/failures.dart';

// State definitions
abstract class NanoAuthState {
  const NanoAuthState();
}

class NanoAuthInitial extends NanoAuthState {
  const NanoAuthInitial();
}

class NanoAuthLoading extends NanoAuthState {
  const NanoAuthLoading();
}

class NanoAuthenticated extends NanoAuthState {
  final NanoAccessSession session;
  const NanoAuthenticated(this.session);
}

class NanoUnauthenticated extends NanoAuthState {
  const NanoUnauthenticated();
}

class NanoAuthError extends NanoAuthState {
  final Failure failure;
  const NanoAuthError(this.failure);
}

// Notifier
class NanoAuthNotifier extends StateNotifier<NanoAuthState> {
  final NanoAuthRepository repository;
  final String baseUrl;

  NanoAuthNotifier({
    required this.repository,
    required this.baseUrl,
  }) : super(const NanoAuthInitial());

  Future<void> checkStatus() async {
    state = const NanoAuthLoading();
    final result = await repository.restoreSession(baseUrl);
    
    result.fold(
      (failure) => state = const NanoUnauthenticated(),
      (session) {
        if (session != null) {
          state = NanoAuthenticated(session);
        } else {
          state = const NanoUnauthenticated();
        }
      }
    );
  }

  Future<void> login(NanoCredentials credentials) async {
    state = const NanoAuthLoading();
    final result = await repository.login(credentials, baseUrl);
    
    result.fold(
      (failure) => state = NanoAuthError(failure),
      (session) => state = NanoAuthenticated(session),
    );
  }

  Future<void> logout() async {
    state = const NanoAuthLoading();
    await repository.logout();
    state = const NanoUnauthenticated();
  }
}
