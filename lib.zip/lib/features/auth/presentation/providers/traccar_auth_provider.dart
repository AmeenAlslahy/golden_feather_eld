import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/network/network_providers.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../domain/entities/traccar_session.dart';
import '../../domain/repositories/traccar_auth_repository.dart';
import '../../data/datasources/traccar_auth_remote_data_source.dart';
import '../../data/datasources/traccar_session_store.dart';
import '../../../../core/utils/logger.dart';
import 'package:dio/dio.dart';

enum TraccarAuthStatus {
  unconfigured,
  unauthenticated,
  authenticating,
  authenticated,
  sessionExpired,
  failure,
}

class TraccarAuthState {
  final TraccarAuthStatus status;
  final TraccarSession? session;
  final Failure? failure;
  final bool isRestoring;

  const TraccarAuthState({
    this.status = TraccarAuthStatus.unconfigured,
    this.session,
    this.failure,
    this.isRestoring = false,
  });

  TraccarAuthState copyWith({
    TraccarAuthStatus? status,
    TraccarSession? session,
    Failure? failure,
    bool? isRestoring,
  }) {
    return TraccarAuthState(
      status: status ?? this.status,
      session: session ?? this.session,
      failure: failure, // We intentionally allow nullifying failure
      isRestoring: isRestoring ?? this.isRestoring,
    );
  }
}

class TraccarAuthNotifier extends StateNotifier<TraccarAuthState> {
  final TraccarAuthRepository _repository;

  TraccarAuthNotifier(this._repository)
      : super(const TraccarAuthState(isRestoring: true)) {
    _init();
  }

  Future<void> _init() async {
    final result = await _repository.checkAndRestoreSession();
    
    // تأكد من عدم تحديث الحالة إذا تم تدمير الـ Notifier
    if (!mounted) return;

    result.fold(
      (failure) {
        if (failure is MissingConfigurationFailure) {
          AppLogger.info('TraccarAuth: Initial state -> unconfigured');
          state = state.copyWith(status: TraccarAuthStatus.unconfigured, isRestoring: false);
        } else if (failure is SessionMissingFailure || failure is AuthFailure) {
          AppLogger.info('TraccarAuth: Initial state -> unauthenticated');
          state = state.copyWith(status: TraccarAuthStatus.unauthenticated, isRestoring: false);
        } else {
          // خطأ شبكي أو غير متوقع أثناء الاستعادة
          AppLogger.info('TraccarAuth: Initial state -> failure (${failure.message})');
          state = state.copyWith(status: TraccarAuthStatus.failure, failure: failure, isRestoring: false);
        }
      },
      (session) {
        AppLogger.info('TraccarAuth: Initial state -> authenticated (Session restored)');
        state = state.copyWith(status: TraccarAuthStatus.authenticated, session: session, isRestoring: false);
      },
    );
  }

  Future<void> login(String email, String password) async {
    AppLogger.info('TraccarAuth: Attempting login... State -> authenticating');
    state = state.copyWith(status: TraccarAuthStatus.authenticating, failure: null);
    
    final result = await _repository.login(email: email, password: password);
    
    if (!mounted) return;

    result.fold(
      (failure) {
        AppLogger.info('TraccarAuth: Login failed -> failure (${failure.message})');
        state = state.copyWith(status: TraccarAuthStatus.failure, failure: failure);
      },
      (session) {
        AppLogger.info('TraccarAuth: Login successful -> authenticated');
        state = state.copyWith(status: TraccarAuthStatus.authenticated, session: session, failure: null);
      },
    );
  }

  Future<void> logout() async {
    AppLogger.info('TraccarAuth: Logging out... State -> unauthenticated');
    await _repository.logout();
    if (mounted) {
      state = const TraccarAuthState(status: TraccarAuthStatus.unauthenticated);
    }
  }

  void resetFailure() {
    state = state.copyWith(failure: null);
  }
}

/// موفر يوفر فقط قيمة JSESSIONID بشكل آمن إذا كانت الجلسة صالحة ومطابقة للخادم
/// هذا العقد سيتم استخدامه لاحقاً من قبل WebSocket لفتح الاتصال
final traccarSessionCredentialProvider = Provider<String?>((ref) {
  // للتبسيط الآن، نحن فقط نوثق الطريقة.
  // في التطبيق الفعلي، سيعتمد على traccarAuthNotifierProvider (سيتم إنشاؤه لاحقاً).
  return null;
});
final traccarAuthRemoteDataSourceProvider = Provider<TraccarAuthRemoteDataSource>((ref) {
  final dio = Dio();
  return TraccarAuthRemoteDataSourceImpl(dio);
});

final traccarSessionStoreProvider = Provider<TraccarSessionStore>((ref) {
  return TraccarSessionStoreImpl();
});

final traccarAuthRepositoryProvider = Provider<TraccarAuthRepository>((ref) {
  final remoteDataSource = ref.watch(traccarAuthRemoteDataSourceProvider);
  final sessionStore = ref.watch(traccarSessionStoreProvider);
  final localStorage = ref.watch(localStorageProvider);
  final networkInfo = ref.watch(networkInfoProvider);

  return TraccarAuthRepositoryImpl(
    remoteDataSource: remoteDataSource,
    sessionStore: sessionStore,
    localStorage: localStorage,
    networkInfo: networkInfo,
  );
});

final traccarAuthNotifierProvider = StateNotifierProvider<TraccarAuthNotifier, TraccarAuthState>((ref) {
  final repository = ref.watch(traccarAuthRepositoryProvider);
  return TraccarAuthNotifier(repository);
});
