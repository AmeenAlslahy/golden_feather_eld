import 'package:equatable/equatable.dart';
import 'user.dart';

/// نتيجة المصادقة
class AuthResult extends Equatable {
  final User user;
  final String token;
  final String refreshToken;
  final DateTime expiresAt;

  const AuthResult({
    required this.user,
    required this.token,
    required this.refreshToken,
    required this.expiresAt,
  });

  bool get isExpired => DateTime.now().isAfter(expiresAt);

  @override
  List<Object?> get props => [user, token, refreshToken, expiresAt];
}



