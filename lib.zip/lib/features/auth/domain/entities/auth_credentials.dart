import 'package:equatable/equatable.dart';

/// بيانات اعتماد المصادقة
class AuthCredentials extends Equatable {
  final String username;
  final String password;
  final String? serverUrl;

  const AuthCredentials({
    required this.username,
    required this.password,
    this.serverUrl,
  });

  @override
  List<Object?> get props => [username, password, serverUrl];
}



