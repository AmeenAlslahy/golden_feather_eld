import 'package:equatable/equatable.dart';

class NanoCredentials extends Equatable {
  final String loginAttribute; // username, email, mobile
  final String login;
  final String password; // Assumed field name, waiting for contract confirmation
  final String provider; // Should be 'frontend' for driver app
  final bool profile; // Should be true

  const NanoCredentials({
    required this.loginAttribute,
    required this.login,
    required this.password,
    this.provider = 'frontend',
    this.profile = true,
  });

  @override
  List<Object?> get props => [loginAttribute, login, password, provider, profile];
}

class NanoUserProfile extends Equatable {
  final int id;
  final String name;
  final String email;
  final String mobile;
  final String? companyId;
  final String? departmentId;
  final String? refType;
  final String? refId;
  final bool isActivated;

  const NanoUserProfile({
    required this.id,
    required this.name,
    required this.email,
    required this.mobile,
    this.companyId,
    this.departmentId,
    this.refType,
    this.refId,
    required this.isActivated,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        email,
        mobile,
        companyId,
        departmentId,
        refType,
        refId,
        isActivated,
      ];
}

class NanoAccessSession extends Equatable {
  final String accessToken;
  final String tokenType; // e.g., 'Bearer'
  final DateTime? expiresAt;
  final int userId;
  final String provider;
  final NanoUserProfile? profile;

  const NanoAccessSession({
    required this.accessToken,
    required this.tokenType,
    this.expiresAt,
    required this.userId,
    required this.provider,
    this.profile,
  });

  @override
  List<Object?> get props => [
        accessToken, // Note: Do not print directly in logs/toString if possible.
        tokenType,
        expiresAt,
        userId,
        provider,
        profile,
      ];
      
  @override
  String toString() {
    // Redacted toString to prevent token leakage
    return 'NanoAccessSession(userId: $userId, provider: $provider, token: [REDACTED], tokenType: $tokenType)';
  }
}
