import '../../../../core/errors/failures.dart';

class InvalidCredentialsFailure extends Failure {
  const InvalidCredentialsFailure({String? message})
      : super(message: message ?? 'بيانات الدخول غير صحيحة');
}

class AccountBannedFailure extends Failure {
  const AccountBannedFailure({String? message})
      : super(message: message ?? 'تم إيقاف هذا الحساب من قبل الإدارة');
}

class AccountNotActivatedFailure extends Failure {
  const AccountNotActivatedFailure({String? message})
      : super(message: message ?? 'هذا الحساب غير منشط');
}

class AccountSuspendedFailure extends Failure {
  const AccountSuspendedFailure({String? message})
      : super(message: message ?? 'هذا الحساب موقوف مؤقتاً');
}

class MissingTokenFailure extends Failure {
  const MissingTokenFailure({String? message})
      : super(message: message ?? 'بيانات الجلسة مفقودة');
}

class TokenExpiredFailure extends Failure {
  const TokenExpiredFailure({String? message})
      : super(message: message ?? 'انتهت صلاحية الجلسة، يرجى تسجيل الدخول مجدداً');
}

class PermissionDeniedFailure extends Failure {
  const PermissionDeniedFailure({String? message})
      : super(message: message ?? 'لا تملك صلاحية للوصول');
}

class MalformedAuthResponseFailure extends Failure {
  const MalformedAuthResponseFailure({String? message})
      : super(message: message ?? 'استجابة غير صحيحة من الخادم');
}

class OriginMismatchFailure extends Failure {
  const OriginMismatchFailure({String? message})
      : super(message: message ?? 'بيانات الجلسة لا تتطابق مع الخادم الحالي');
}

class SecureStorageFailure extends Failure {
  const SecureStorageFailure({String? message})
      : super(message: message ?? 'حدث خطأ أثناء قراءة أو حفظ الجلسة');
}
