import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../../presentation/providers/auth_providers.dart';
import '../entities/auth_credentials.dart';
import '../entities/auth_result.dart';
import '../repositories/auth_repository.dart';

/// حالة استخدام: تسجيل الدخول
class Login {
  final AuthRepository _repository;

  Login(this._repository);

  Future<Either<Failure, AuthResult>> call({
    required String username,
    required String password,
    String? serverUrl,
  }) async {
    // التحقق من البيانات
    if (username.isEmpty) {
      return const Left(ValidationFailure(
        message: 'اسم المستخدم مطلوب',
        arabicMessage: 'اسم المستخدم مطلوب',
      ));
    }

    if (password.isEmpty) {
      return const Left(ValidationFailure(
        message: 'كلمة المرور مطلوبة',
        arabicMessage: 'كلمة المرور مطلوبة',
      ));
    }

    final credentials = AuthCredentials(
      username: username,
      password: password,
      serverUrl: serverUrl,
    );

    return _repository.login(credentials);
  }
}

/// مزود حالة استخدام تسجيل الدخول
final loginUseCaseProvider = Provider<Login>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return Login(repository);
});



