import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../presentation/providers/auth_providers.dart';
import '../repositories/auth_repository.dart';

/// حالة استخدام: التحقق من كلمة المرور المحلية
class VerifyLocalPassword {
  final AuthRepository _repository;

  VerifyLocalPassword(this._repository);

  Future<bool> call(String password) async {
    return _repository.verifyLocalPassword(password);
  }
}

/// مزود حالة استخدام التحقق من كلمة المرور المحلية
final verifyLocalPasswordUseCaseProvider = Provider<VerifyLocalPassword>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return VerifyLocalPassword(repository);
});



