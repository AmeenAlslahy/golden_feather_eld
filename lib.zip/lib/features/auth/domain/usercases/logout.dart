import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../../presentation/providers/auth_providers.dart';
import '../repositories/auth_repository.dart';

/// حالة استخدام: تسجيل الخروج
class Logout {
  final AuthRepository _repository;

  Logout(this._repository);

  Future<Either<Failure, bool>> call() async {
    return _repository.logout();
  }
}

/// مزود حالة استخدام تسجيل الخروج
final logoutUseCaseProvider = Provider<Logout>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return Logout(repository);
});



