import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/nano_auth_entities.dart';

abstract class NanoAuthRepository {
  Future<Either<Failure, NanoAccessSession>> login(NanoCredentials credentials, String baseUrl);
  Future<Either<Failure, void>> logout();
  Future<Either<Failure, NanoAccessSession?>> restoreSession(String baseUrl);
}
