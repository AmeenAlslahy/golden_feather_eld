import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/auth_credentials.dart';
import '../entities/auth_result.dart';
import '../entities/user.dart';

/// واجهة مستودع المصادقة
abstract class AuthRepository {
  /// تسجيل الدخول
  Future<Either<Failure, AuthResult>> login(AuthCredentials credentials);

  /// تسجيل الخروج
  Future<Either<Failure, bool>> logout();

  /// إنشاء حساب جديد
  Future<Either<Failure, bool>> register({
    required String fullName,
    required String username,
    required String password,
  });

  /// استعادة كلمة المرور
  Future<Either<Failure, bool>> forgotPassword(String email);

  /// تجديد الرمز
  Future<Either<Failure, AuthResult>> refreshToken(String refreshToken);

  /// الحصول على المستخدم الحالي
  Future<Either<Failure, User?>> getCurrentUser();

  /// هل المستخدم مسجل الدخول
  Future<bool> isLoggedIn();

  /// تغيير كلمة المرور
  Future<Either<Failure, bool>> changePassword({
    required String oldPassword,
    required String newPassword,
  });

  /// التحقق من كلمة المرور المحلية
  Future<bool> verifyLocalPassword(String password);

  /// تعيين كلمة المرور المحلية
  Future<void> setLocalPassword(String password);

  /// إزالة كلمة المرور المحلية
  Future<void> removeLocalPassword();

  /// هل توجد كلمة مرور محلية
  Future<bool> hasLocalPassword();
}



