import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../data/datasources/tracking_local_data_source.dart';
import '../../data/repositories/tracking_repository_impl.dart';
import '../../data/services/tracking_service.dart';
import '../../domain/repositories/tracking_repository.dart';

/// مزود مصدر البيانات المحلي
final trackingLocalDataSourceProvider = Provider<TrackingLocalDataSource>((ref) {
  final storage = ref.watch(localStorageProvider);
  return TrackingLocalDataSourceImpl(storage);
});

/// مزود خدمة التتبع
final trackingServiceFullProvider = Provider<TrackingService>((ref) {
  final storage = ref.watch(localStorageProvider);
  return TrackingService(storage: storage);
});

/// مزود مستودع التتبع
final trackingRepositoryProvider = Provider<TrackingRepository>((ref) {
  final service = ref.watch(trackingServiceFullProvider);
  final localDataSource = ref.watch(trackingLocalDataSourceProvider);
  return TrackingRepositoryImpl(
    service: service,
    localDataSource: localDataSource,
  );
});



