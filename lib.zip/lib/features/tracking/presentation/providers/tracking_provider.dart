import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/services/battery_optimization_service.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/utils/logger.dart';
import '../../domain/entities/location_entity.dart';
import '../../domain/repositories/tracking_repository.dart';
import 'tracking_providers.dart';

/// حالة التتبع
enum TrackingStatus { initial, active, stopped, loading, error }

enum TrackingErrorType { permission, technical }

/// حالة شاشة التتبع
class TrackingState {
  final TrackingStatus status;
  final LocationEntity? currentLocation;
  final List<TrackingLogEntity> logs;
  final String? errorMessage;
  final String? arabicErrorMessage;
  final TrackingErrorType? errorType;
  final bool isTracking;
  final bool showBatteryDialog; // 🆕

  const TrackingState({
    this.status = TrackingStatus.initial,
    this.currentLocation,
    this.logs = const [],
    this.errorMessage,
    this.arabicErrorMessage,
    this.errorType,
    this.isTracking = false,
    this.showBatteryDialog = false, // 🆕
  });

  TrackingState copyWith({
    TrackingStatus? status,
    LocationEntity? currentLocation,
    List<TrackingLogEntity>? logs,
    String? errorMessage,
    String? arabicErrorMessage,
    TrackingErrorType? errorType,
    bool? isTracking,
    bool? showBatteryDialog,
  }) {
    return TrackingState(
      status: status ?? this.status,
      currentLocation: currentLocation ?? this.currentLocation,
      logs: logs ?? this.logs,
      errorMessage: errorMessage,
      arabicErrorMessage: arabicErrorMessage,
      errorType: errorType,
      isTracking: isTracking ?? this.isTracking,
      showBatteryDialog: showBatteryDialog ?? this.showBatteryDialog,
    );
  }
}

/// مزود حالة التتبع
final trackingStateProvider =
    StateNotifierProvider<TrackingNotifier, TrackingState>((ref) {
  final repository = ref.watch(trackingRepositoryProvider);
  return TrackingNotifier(repository, ref);
});

class TrackingNotifier extends StateNotifier<TrackingState> {
  final TrackingRepository _repository;
  final Ref ref;

  TrackingNotifier(this._repository, this.ref) : super(const TrackingState());

  /// بدء التتبع
  Future<void> startTracking({bool skipBatteryCheck = false}) async {
    state = state.copyWith(status: TrackingStatus.loading);

    // ✅ فحص تحسين البطارية
    if (!skipBatteryCheck) {
      final batteryService = ref.read(batteryOptimizationServiceProvider);
      final isBatteryOptimized = await batteryService.isBatteryOptimizationEnabled();
      
      if (isBatteryOptimized) {
        // نحتاج context لإظهار الحوار - نمرر إشارة للـ UI
        state = state.copyWith(
          status: TrackingStatus.initial,
          showBatteryDialog: true, 
        );
        return; // نوقف التتبع مؤقتاً حتى يستجيب المستخدم للحوار
      }
    }

    final result = await _repository.startTracking();

    result.fold(
      (failure) {
        if (failure is PermissionFailure) {
          state = state.copyWith(
            status: TrackingStatus.error,
            errorMessage: failure.message,
            arabicErrorMessage: failure.arabicMessage,
            errorType: TrackingErrorType.permission,
          );
        } else {
          state = state.copyWith(
            status: TrackingStatus.error,
            errorMessage: failure.message,
            arabicErrorMessage: failure.arabicMessage,
            errorType: TrackingErrorType.technical,
          );
        }
      },
      (_) {
        state = state.copyWith(
          status: TrackingStatus.active,
          isTracking: true,
          errorMessage: null,
          arabicErrorMessage: null,
          errorType: null,
        );
        AppLogger.info('Tracking started successfully');
      },
    );
  }

  /// إيقاف التتبع
  Future<void> stopTracking() async {
    state = state.copyWith(status: TrackingStatus.loading);

    final result = await _repository.stopTracking();

    result.fold(
      (failure) {
        state = state.copyWith(
          status: TrackingStatus.error,
          errorMessage: failure.message,
        );
      },
      (_) {
        state = state.copyWith(
          status: TrackingStatus.stopped,
          isTracking: false,
          errorMessage: null,
        );
        AppLogger.info('Tracking stopped successfully');
      },
    );
  }

  /// طلب الموقع الحالي
  Future<void> requestPosition({String? alarm}) async {
    final result = await _repository.requestPosition(alarm: alarm);

    result.fold(
      (failure) {
        state = state.copyWith(
          errorMessage: failure.message,
          arabicErrorMessage: failure.arabicMessage,
        );
      },
      (location) {
        state = state.copyWith(
          currentLocation: location,
          errorMessage: null,
        );
      },
    );
  }

  /// تحميل السجلات
  Future<void> loadLogs() async {
    final result = await _repository.getLogs();

    result.fold(
      (_) {},
      (logs) {
        state = state.copyWith(logs: logs);
      },
    );
  }

  /// مسح السجلات
  Future<void> clearLogs() async {
    await _repository.clearLogs();
    state = state.copyWith(logs: []);
  }

  /// مسح الخطأ
  void clearError() {
    state = state.copyWith(
      errorMessage: null,
      arabicErrorMessage: null,
      errorType: null,
    );
  }

  void clearBatteryDialog() {
    state = state.copyWith(showBatteryDialog: false);
  }
}



