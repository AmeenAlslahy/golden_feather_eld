import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/widgets/app_card.dart';
import '../../../../l10n/app_localizations.dart';
import '../providers/tracking_provider.dart';

/// بطاقة حالة التتبع
class TrackingStatusCard extends ConsumerWidget {
  const TrackingStatusCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trackingState = ref.watch(trackingStateProvider);
    final isTracking = trackingState.isTracking;
    final location = trackingState.currentLocation;
    final loc = AppLocalizations.of(context)!;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // العنوان
          Row(
            children: [
              Icon(
                Icons.location_on,
                color: isTracking ? AppColors.success : AppColors.textSecondaryLight,
                size: 28,
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  loc.trackingStatus,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              // مؤشر الحالة
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.sm,
                  vertical: AppSpacing.xs,
                ),
                decoration: BoxDecoration(
                  color: isTracking
                      ? AppColors.successLight
                      : AppColors.errorLight,
                  borderRadius: BorderRadius.circular(AppSpacing.xs),
                ),
                child: Text(
                  isTracking ? loc.activeStatus : loc.stoppedStatus,
                  style: TextStyle(
                    color: isTracking ? AppColors.success : AppColors.error,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),

          // الإحداثيات
          if (location != null) ...[
            _buildInfoRow(
              context,
              Icons.my_location,
              loc.coordinatesLabel,
              '${location.latitude.toStringAsFixed(4)}, ${location.longitude.toStringAsFixed(4)}',
            ),
            const SizedBox(height: AppSpacing.sm),
          ],

          // معلومات إضافية
          _buildInfoRow(
            context,
            Icons.access_time,
            loc.lastUpdateLabel,
            location != null
                ? '${location.timestamp.hour}:${location.timestamp.minute.toString().padLeft(2, '0')}'
                : loc.noData,
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(
    BuildContext context,
    IconData icon,
    String label,
    String value,
  ) {
    return Row(
      children: [
        Icon(icon, size: 16, color: AppColors.textSecondaryLight),
        const SizedBox(width: AppSpacing.sm),
        Text(
          '$label: ',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}



