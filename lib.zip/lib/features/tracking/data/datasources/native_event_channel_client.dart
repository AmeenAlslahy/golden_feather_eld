import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';
import '../../domain/entities/native_location_event.dart';

class NativeLocationQualityValidator {
  NativeLocationEvent validate(NativeLocationEvent event, DateTime? lastRecordedAt) {
    // Basic coordinate bounds
    if (event.latitude < -90 || event.latitude > 90 || 
        event.longitude < -180 || event.longitude > 180) {
      return event.copyWith(qualityStatus: LocationQualityStatus.invalid);
    }

    if (event.latitude.isNaN || event.longitude.isNaN || 
        event.latitude.isInfinite || event.longitude.isInfinite) {
      return event.copyWith(qualityStatus: LocationQualityStatus.invalid);
    }

    if (event.accuracyMeters < 0 || event.speedMetersPerSecond < 0) {
      return event.copyWith(qualityStatus: LocationQualityStatus.invalid);
    }

    // Time validation
    final now = DateTime.now().toUtc();
    final timeDiff = event.recordedAt.difference(now).inMinutes;
    if (timeDiff > 5) {
      // Future timestamp (suspicious)
      return event.copyWith(qualityStatus: LocationQualityStatus.suspicious);
    }
    
    if (now.difference(event.recordedAt).inMinutes > 60) {
      // Very old (stale)
      return event.copyWith(qualityStatus: LocationQualityStatus.stale);
    }

    // Ordering validation
    if (lastRecordedAt != null && event.recordedAt.isBefore(lastRecordedAt)) {
      return event.copyWith(qualityStatus: LocationQualityStatus.outOfOrder);
    }

    return event.copyWith(qualityStatus: LocationQualityStatus.valid);
  }
}

class NativeEventChannelClient {
  static const EventChannel _eventChannel = EventChannel('com.goldenfeather.eld/traccar/events');
  
  StreamSubscription? _subscription;
  final StreamController<NativeLocationEvent> _locationController = StreamController<NativeLocationEvent>.broadcast();
  final NativeLocationQualityValidator _validator;
  DateTime? _lastRecordedAt;

  NativeEventChannelClient({NativeLocationQualityValidator? validator}) 
      : _validator = validator ?? NativeLocationQualityValidator();

  Stream<NativeLocationEvent> get locationStream => _locationController.stream;

  void startListening() {
    if (_subscription != null) return; // Prevent multiple subscriptions

    _subscription = _eventChannel.receiveBroadcastStream().listen(
      (dynamic event) {
        if (event is Map) {
          try {
            final parsedEvent = _parseEvent(Map<String, dynamic>.from(event));
            if (parsedEvent != null) {
               final validatedEvent = _validator.validate(parsedEvent, _lastRecordedAt);
               if (validatedEvent.qualityStatus == LocationQualityStatus.valid || 
                   validatedEvent.qualityStatus == LocationQualityStatus.suspicious ||
                   validatedEvent.qualityStatus == LocationQualityStatus.stale) {
                 _lastRecordedAt = validatedEvent.recordedAt;
               }
               _locationController.add(validatedEvent);
            }
          } catch (e) {
            // Malformed event, ignore silently as per requirements to not log full payloads
            // and not break the stream
          }
        }
      },
      onError: (dynamic error) {
        // Handle native errors without killing the stream completely
        // For now, we just swallow them or map them to a status if required.
      },
      cancelOnError: false, // Ensure stream survives malformed events or temporary errors
    );
  }

  NativeLocationEvent? _parseEvent(Map<String, dynamic> data) {
    try {
      final lat = (data['latitude'] as num?)?.toDouble();
      final lon = (data['longitude'] as num?)?.toDouble();
      final speed = (data['speed'] as num?)?.toDouble() ?? 0.0;
      final bearing = (data['bearing'] as num?)?.toDouble() ?? 0.0;
      final altitude = (data['altitude'] as num?)?.toDouble() ?? 0.0;
      final accuracy = (data['accuracy'] as num?)?.toDouble() ?? 0.0;
      final timestampMs = (data['timestamp'] as num?)?.toInt();

      if (lat == null || lon == null || timestampMs == null) return null;

      final recordedAt = DateTime.fromMillisecondsSinceEpoch(timestampMs, isUtc: true);
      final receivedAt = DateTime.now().toUtc(); // Time of receipt in Flutter

      return NativeLocationEvent(
        latitude: lat,
        longitude: lon,
        recordedAt: recordedAt,
        receivedAt: receivedAt,
        speedMetersPerSecond: speed,
        bearingDegrees: bearing,
        altitudeMeters: altitude,
        accuracyMeters: accuracy,
        source: LocationSource.localNative,
        platform: Platform.isIOS ? 'iOS' : 'Android',
        isMock: false, // Default to false unless provided by native
        qualityStatus: LocationQualityStatus.valid, // Will be validated later
      );
    } catch (_) {
      return null;
    }
  }

  void dispose() {
    _subscription?.cancel();
    _subscription = null;
    _locationController.close();
  }
}
