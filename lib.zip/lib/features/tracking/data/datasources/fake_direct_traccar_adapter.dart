import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/entities/native_location_event.dart';
import '../../domain/repositories/location_upload_adapter.dart';

/// A Fake implementation of Direct Traccar Adapter for Staging/Demo.
/// This simulates sending a location event to a Traccar instance (e.g. via OsmAnd HTTP protocol on port 5055).
class FakeDirectTraccarAdapter implements LocationUploadAdapter {
  final String deviceId; // e.g. "50028345"
  final String traccarUrl; // e.g. "http://demo.traccar.org:5055"
  
  // For testing purposes
  final List<NativeLocationEvent> _uploadedEvents = [];
  bool simulateFailure = false;

  FakeDirectTraccarAdapter({
    required this.deviceId,
    required this.traccarUrl,
  });

  List<NativeLocationEvent> get uploadedEvents => List.unmodifiable(_uploadedEvents);

  @override
  Future<Either<Failure, void>> uploadLocation(NativeLocationEvent event) async {
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 200));

    if (simulateFailure) {
      return const Left(ServerFailure(message: 'Simulated connection failure to Traccar Demo'));
    }

    if (event.source != LocationSource.localNative) {
      return const Left(ValidationFailure(message: 'Can only upload localNative locations'));
    }

    // In a real implementation, this would format the event to OsmAnd protocol:
    // GET $traccarUrl/?id=$deviceId&lat=${event.latitude}&lon=${event.longitude}&timestamp=${event.recordedAt.millisecondsSinceEpoch ~/ 1000}&speed=${event.speedMetersPerSecond}
    
    _uploadedEvents.add(event);
    
    return const Right(null);
  }
}
