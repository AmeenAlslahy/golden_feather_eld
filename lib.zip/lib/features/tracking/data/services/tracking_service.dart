import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/network/traccar_client_sdk.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../../../core/utils/logger.dart';

/// خدمة التتبع - متكاملة مع Traccar Client SDK
class TrackingService {
  final TraccarClientInterface _tracker;
  final LocalStorageService _storage;
  StreamSubscription? _locationSubscription;
  bool _isInitialized = false;

  TrackingService({
    TraccarClientInterface? tracker,
    required LocalStorageService storage,
  })  : _tracker = tracker ?? TraccarMockClient(),
        _storage = storage;

  // ========== التهيئة ==========

  /// تهيئة المتتبع مع الإعدادات الحالية
  Future<void> init() async {
    if (_isInitialized) return;

    try {
      final config = _buildConfig();
      await _tracker.setConfig(config);
      _isInitialized = true;
      AppLogger.info('✅ TrackingService initialized with Traccar SDK');
      AppLogger.info('   Server: ${config.serverUrl}');
      AppLogger.info('   Device: ${config.deviceId}');
    } catch (e) {
      AppLogger.error('❌ Failed to initialize Traccar SDK', e);
    }
  }

  /// بناء Config من الإعدادات المحلية
  Config _buildConfig() {
    return Config(
      serverUrl: _storage.serverUrl,
      deviceId: _storage.deviceId,
      location: LocationConfig(
        accuracy: _mapAccuracy(_storage.accuracy),
        distanceMeters: _storage.distance,
        intervalSeconds: _storage.interval,
        angleDegrees: _storage.angle,
        heartbeatIntervalSeconds: _storage.heartbeat,
        stopDetection: _storage.stopDetection,
      ),
      wakeLock: _storage.wakelock,
      buffer: _storage.buffer,
      preferPlatformProviders: _storage.preferPlatformProviders,
    );
  }

  Accuracy _mapAccuracy(String accuracy) {
    return switch (accuracy) {
      'highest' => Accuracy.highest,
      'high' => Accuracy.high,
      'low' => Accuracy.low,
      _ => Accuracy.medium,
    };
  }

  // ========== التحكم في التتبع ==========

  /// بدء التتبع
  Future<void> start() async {
    if (!_isInitialized) await init();
    try {
      await _tracker.start();
      AppLogger.info('📍 Tracking started');
    } catch (e) {
      AppLogger.error('Failed to start tracking', e);
      rethrow;
    }
  }

  /// إيقاف التتبع
  Future<void> stop() async {
    try {
      await _tracker.stop();
      AppLogger.info('⏹️ Tracking stopped');
    } catch (e) {
      AppLogger.error('Failed to stop tracking', e);
      rethrow;
    }
  }

  /// هل التتبع نشط
  Future<bool> isTracking() async {
    try {
      return _tracker.isTracking();
    } catch (e) {
      return false;
    }
  }

  /// طلب الموقع الحالي
  Future<void> requestPosition({String? alarm}) async {
    if (!_isInitialized) await init();
    try {
      await _tracker.requestPosition(alarm: alarm);
      AppLogger.info('📍 Position requested${alarm != null ? " with alarm: $alarm" : ""}');
    } catch (e) {
      AppLogger.error('Failed to request position', e);
      rethrow;
    }
  }

  /// تحديث الإعدادات
  Future<void> updateConfig() async {
    if (!_isInitialized) await init();
    try {
      final config = _buildConfig();
      await _tracker.setConfig(config);
      _isInitialized = true;
      AppLogger.info('⚙️ Tracking config updated');
    } catch (e) {
      AppLogger.error('Failed to update config', e);
      rethrow;
    }
  }

  // ========== السجلات ==========

  /// الحصول على سجلات التتبع
  Future<List<Map<String, dynamic>>> getLogs() async {
    try {
      final logs = await _tracker.getLogs();
      return logs
          .map((log) => {
                'time': log.time,
                'message': log.message,
              })
          .toList();
    } catch (e) {
      // إذا فشل، نعيد سجلات وهمية للتطوير
      if (AppConstants.isDevelopmentMode) {
        return _getMockLogs();
      }
      rethrow;
    }
  }

  /// مسح السجلات
  Future<void> clearLogs() async {
    try {
      await _tracker.clearLogs();
      AppLogger.info('🗑️ Logs cleared');
    } catch (e) {
      AppLogger.error('Failed to clear logs', e);
    }
  }

  // ========== سجلات وهمية للتطوير ==========

  List<Map<String, dynamic>> _getMockLogs() {
    final now = DateTime.now();
    return [
      {
        'time': now.subtract(const Duration(minutes: 5)).millisecondsSinceEpoch,
        'message': 'تم بدء التتبع',
      },
      {
        'time': now.subtract(const Duration(minutes: 3)).millisecondsSinceEpoch,
        'message': 'تم تحديث الموقع: 24.7136, 46.6753',
      },
      {
        'time': now.subtract(const Duration(minutes: 1)).millisecondsSinceEpoch,
        'message': 'تم إرسال الموقع بنجاح',
      },
      {
        'time': now.millisecondsSinceEpoch,
        'message': 'التتبع نشط - في انتظار تحديث الموقع',
      },
    ];
  }

  // ========== التخلص ==========

  void dispose() {
    _locationSubscription?.cancel();
    _isInitialized = false;
    AppLogger.info('TrackingService disposed');
  }
}

/// مزود خدمة التتبع
final trackingServiceProvider = Provider<TrackingService>((ref) {
  final storage = ref.watch(localStorageProvider);
  final tracker = ref.watch(traccarClientProvider);
  return TrackingService(storage: storage, tracker: tracker);
});



