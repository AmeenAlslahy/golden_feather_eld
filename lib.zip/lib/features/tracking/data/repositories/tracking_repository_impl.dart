import 'package:dartz/dartz.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:shared_preferences/shared_preferences.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/services/local_storage_service.dart';
import '../../../../core/utils/logger.dart';
import '../../domain/entities/location_entity.dart';
import '../../domain/repositories/tracking_repository.dart';
import '../datasources/tracking_local_data_source.dart';
import '../models/location_model.dart';
import '../services/tracking_service.dart';

/// تنفيذ مستودع التتبع
class TrackingRepositoryImpl implements TrackingRepository {
  final TrackingService _service;
  final TrackingLocalDataSource _localDataSource;

  TrackingRepositoryImpl({
    required TrackingService service,
    required TrackingLocalDataSource localDataSource,
  })  : _service = service,
        _localDataSource = localDataSource;

  @override
  Future<Either<Failure, bool>> startTracking() async {
    try {
      // ١. فحص صلاحية الموقع دائماً (الخلفية) - مطلوبة لعمل Traccar
      var locationStatus = await Permission.locationAlways.status;
      
      if (!locationStatus.isGranted) {
        // في أندرويد 10+ يجب طلب الصلاحية العادية أولاً ثم الخلفية
        var inUseStatus = await Permission.locationWhenInUse.status;
        if (!inUseStatus.isGranted) {
          inUseStatus = await Permission.locationWhenInUse.request();
        }
        
        if (inUseStatus.isGranted) {
          locationStatus = await Permission.locationAlways.request();
        }
      }

      if (!locationStatus.isGranted) {
        return const Left(PermissionFailure(
          message: 'صلاحية الموقع في الخلفية مطلوبة',
          arabicMessage: 'التتبع يتطلب السماح بالوصول للموقع "طوال الوقت" (Allow all the time) ليعمل في الخلفية، يرجى تفعيلها من الإعدادات.',
        ));
      }

      // ٢. فحص إذا كان GPS مفعلاً
      final isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!isLocationServiceEnabled) {
        return const Left(PermissionFailure(
          message: 'خدمة الموقع غير مفعلة',
          arabicMessage: 'يرجى تفعيل خدمة الموقع (GPS) من إعدادات الهاتف للمتابعة.',
        ));
      }

      // ٣. كل شيء جاهز - ابدأ التتبع
      await _service.start();
      AppLogger.info('Tracking started');
      return const Right(true);
      
    } catch (e) {
      AppLogger.error('Failed to start tracking', e);
      return Left(TrackingFailure(
        message: 'فشل بدء التتبع',
        arabicMessage: 'فشل بدء التتبع: $e',
      ));
    }
  }

  @override
  Future<Either<Failure, bool>> stopTracking() async {
    try {
      await _service.stop();
      AppLogger.info('Tracking stopped');
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to stop tracking', e);
      return Left(TrackingFailure(
        message: 'فشل إيقاف التتبع',
        arabicMessage: 'فشل إيقاف التتبع: $e',
      ));
    }
  }

  @override
  Future<bool> isTracking() async {
    return _service.isTracking();
  }

  @override
  Future<Either<Failure, LocationEntity>> getCurrentLocation() async {
    try {
      // نطلب من Traccar تحديث الموقع (إن أمكن)
      await _service.requestPosition();
      
      // نسترجع آخر موقع مسجل لدينا
      final lastLocation = await _localDataSource.getLastLocation();
      if (lastLocation != null) {
        return Right(lastLocation);
      }
      
      // Fallback to Geolocator
      final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      final fallbackLocation = LocationModel(
        latitude: position.latitude,
        longitude: position.longitude,
        speed: position.speed,
        altitude: position.altitude,
        bearing: position.heading,
        accuracy: position.accuracy,
        timestamp: position.timestamp,
      );
      await _localDataSource.saveLastLocation(fallbackLocation);
      return Right(fallbackLocation);
    } catch (e) {
      return Left(TrackingFailure(
        message: 'فشل الحصول على الموقع',
        arabicMessage: 'فشل الحصول على الموقع الحالي: $e',
      ));
    }
  }

  @override
  Future<Either<Failure, LocationEntity>> requestPosition({String? alarm}) async {
    try {
      await _service.requestPosition(alarm: alarm);
      
      final lastLocation = await _localDataSource.getLastLocation();
      if (lastLocation != null) {
        return Right(lastLocation);
      }
      
      // Fallback to Geolocator
      final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      final fallbackLocation = LocationModel(
        latitude: position.latitude,
        longitude: position.longitude,
        speed: position.speed,
        altitude: position.altitude,
        bearing: position.heading,
        accuracy: position.accuracy,
        timestamp: position.timestamp,
      );
      await _localDataSource.saveLastLocation(fallbackLocation);
      return Right(fallbackLocation);
    } catch (e) {
      return Left(TrackingFailure(
        message: 'فشل طلب الموقع',
        arabicMessage: 'فشل طلب الموقع: $e',
      ));
    }
  }

  @override
  Future<Either<Failure, List<TrackingLogEntity>>> getLogs() async {
    try {
      // في وضع التطوير، نعيد سجلات وهمية
      final now = DateTime.now();
      final mockLogs = [
        TrackingLogEntity(
          time: now.subtract(const Duration(minutes: 5)).millisecondsSinceEpoch,
          message: 'تم بدء التتبع',
        ),
        TrackingLogEntity(
          time: now.subtract(const Duration(minutes: 3)).millisecondsSinceEpoch,
          message: 'تم تحديث الموقع: 24.7136, 46.6753',
        ),
        TrackingLogEntity(
          time: now.subtract(const Duration(minutes: 1)).millisecondsSinceEpoch,
          message: 'تم إرسال الموقع بنجاح',
        ),
      ];
      return Right(mockLogs);
    } catch (e) {
      return const Left(TrackingFailure(
        message: 'فشل جلب السجلات',
        arabicMessage: 'فشل جلب سجلات التتبع',
      ));
    }
  }

  @override
  Future<Either<Failure, bool>> clearLogs() async {
    try {
      await _localDataSource.clearLogs();
      return const Right(true);
    } catch (e) {
      return const Left(TrackingFailure(
        message: 'فشل مسح السجلات',
        arabicMessage: 'فشل مسح السجلات',
      ));
    }
  }

  @override
  Future<Either<Failure, bool>> updateConfig(TrackingConfigEntity config) async {
    try {
      await _service.updateConfig();
      AppLogger.info('Tracking config updated');
      return const Right(true);
    } catch (e) {
      return const Left(TrackingFailure(
        message: 'فشل تحديث الإعدادات',
        arabicMessage: 'فشل تحديث إعدادات التتبع',
      ));
    }
  }

  @override
  Future<TrackingConfigEntity> getCurrentConfig() async {
    final storage = LocalStorageService();
    return TrackingConfigEntity(
      serverUrl: storage.serverUrl,
      deviceId: storage.deviceId,
      accuracy: storage.accuracy,
      distanceMeters: storage.distance,
      intervalSeconds: storage.interval,
      angleDegrees: storage.angle,
      heartbeatSeconds: storage.heartbeat,
      buffer: storage.buffer,
      wakeLock: storage.wakelock,
      stopDetection: storage.stopDetection,
      preferPlatformProviders: storage.preferPlatformProviders,
    );
  }
}



