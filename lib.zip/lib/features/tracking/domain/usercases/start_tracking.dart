import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../repositories/tracking_repository.dart';
import '../../presentation/providers/tracking_providers.dart';

/// حالة استخدام: بدء التتبع
class StartTracking {
  final TrackingRepository _repository;

  StartTracking(this._repository);

  Future<Either<Failure, bool>> call() async {
    return _repository.startTracking();
  }
}

/// مزود
final startTrackingUseCaseProvider = Provider<StartTracking>((ref) {
  final repository = ref.watch(trackingRepositoryProvider);
  return StartTracking(repository);
});



