import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../repositories/tracking_repository.dart';
import '../../presentation/providers/tracking_providers.dart';

/// حالة استخدام: إيقاف التتبع
class StopTracking {
  final TrackingRepository _repository;

  StopTracking(this._repository);

  Future<Either<Failure, bool>> call() async {
    return _repository.stopTracking();
  }
}

/// مزود
final stopTrackingUseCaseProvider = Provider<StopTracking>((ref) {
  final repository = ref.watch(trackingRepositoryProvider);
  return StopTracking(repository);
});



