import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/errors/failures.dart';
import '../entities/location_entity.dart';
import '../repositories/tracking_repository.dart';
import '../../presentation/providers/tracking_providers.dart';

/// حالة استخدام: الحصول على الموقع الحالي
class GetCurrentLocation {
  final TrackingRepository _repository;

  GetCurrentLocation(this._repository);

  Future<Either<Failure, LocationEntity>> call() async {
    return _repository.getCurrentLocation();
  }
}

/// مزود
final getCurrentLocationUseCaseProvider = Provider<GetCurrentLocation>((ref) {
  final repository = ref.watch(trackingRepositoryProvider);
  return GetCurrentLocation(repository);
});



