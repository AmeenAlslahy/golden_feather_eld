import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/native_location_event.dart';

/// The target backend type for location uploads
enum TrackingBackend {
  directTraccarDemo,
  nanoBackend,
}

abstract class LocationUploadAdapter {
  /// Uploads a location event to the backend.
  /// Returns a [Failure] if the upload fails, or void if successful (acknowledged).
  Future<Either<Failure, void>> uploadLocation(NativeLocationEvent event);
}
