import '../../core/result/result.dart';
import '../../domain/shared/value_objects.dart';
import 'raw_json.dart';

abstract interface class DailyLogsBackend {
  /// GET /eld/daily-logs
  // TODO(P2): replace with List<DailyLog>
  Future<Result<RawJson>> list({
    DriverId? driverId,
    DateTime? startDate,
    DateTime? endDate,
    String? status,
    String? certificationStatus,
    int? ruleId,
    bool? requiresAction,
    int limit = 50,
    int offset = 0,
  });

  /// GET /eld/daily-logs/{id}
  // TODO(P2): replace with DailyLog
  Future<Result<RawJson>> getById(DailyLogId logId);

  /// POST /eld/daily-logs/{id}/carrier-edits
  // TODO(P2): replace with CarrierEdit
  Future<Result<RawJson>> proposeCarrierEdit({
    required DailyLogId logId,
    required RawJson edit,
  });

  /// POST /eld/daily-logs/{id}/carrier-edits/{editId}/respond
  Future<Result<void>> respondToCarrierEdit({
    required DailyLogId logId,
    required EditId editId,
    required String action,
    String? driverNotes,
  });

  /// POST /eld/daily-logs/{id}/certify
  // TODO(P2): replace with CertificationResult
  Future<Result<RawJson>> certify({
    required DailyLogId logId,
    required String signatureCertificateId,
    required bool signatureConfirmation,
    required bool certifiedTrue,
  });

  /// POST /eld/daily-logs/{id}/events/{statusId}/reassign-driving
  Future<Result<void>> reassignDriving({
    required DailyLogId logId,
    required DutyStatusId statusId,
    required DriverId targetCoDriverId,
    required String annotation,
  });

  /// GET /eld/daily-logs/{id}/form
  // TODO(P2): replace with DailyForm
  Future<Result<RawJson>> getForm(DailyLogId logId);

  /// PUT /eld/daily-logs/{id}/form
  // TODO(P2): replace with DailyForm
  Future<Result<RawJson>> saveForm({
    required DailyLogId logId,
    required RawJson form,
  });

  /// GET /eld/daily-logs/{id}/graph-grid
  // TODO(P2): replace with GraphGrid
  Future<Result<RawJson>> getGraphGrid(DailyLogId logId);

  /// POST /eld/daily-logs/{id}/lock
  Future<Result<void>> lock(DailyLogId logId);

  /// GET /eld/daily-logs/{id}/readiness
  // TODO(P2): replace with CertificationReadiness
  Future<Result<RawJson>> getReadiness(DailyLogId logId);

  // --- Legacy methods for P5.5 ---
  Future<Result<List<dynamic>>> getLegacyDutyStatusLogs(
      int driverId, DateTime date);
  Future<Result<List<dynamic>>> getLegacySyncLogs(int driverId);
}
