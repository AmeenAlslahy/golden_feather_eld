import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:firebase_core/firebase_core.dart';
import 'app.dart';
import 'core/config/app_environment.dart';
import 'core/utils/logger.dart';
import 'core/services/local_storage_service.dart';
import 'core/services/push_notification_service.dart';
import 'core/services/remote_config_service.dart';
import 'features/tracking/data/services/tracking_service.dart';
import 'features/sync/presentation/providers/sync_provider.dart';
import 'features/sync/presentation/providers/sync_engine_provider.dart';
import 'core/services/utc_sync_service.dart';
import 'core/services/local_database_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // تهيئة البيئة والإعدادات
  await AppEnvironmentConfig.init();
  
  // تهيئة Firebase
  try {
    await Firebase.initializeApp();
  } catch (e) {
    AppLogger.error('Firebase initialization failed', e);
  }

  // تهيئة التخزين المحلي
  final localStorageService = LocalStorageService();
  await localStorageService.init();

  // تهيئة التخزين المحلي للمستودع (Hive)
  final localDatabaseService = LocalDatabaseService();
  await localDatabaseService.init();

  // تهيئة خدمة التتبع
  final trackingService = TrackingService(storage: localStorageService);
  await trackingService.init();

  // تهيئة الإشعارات
  try {
    await PushNotificationService.init(
      trackingService: trackingService,
      storage: localStorageService,
    );
  } catch (e) {
    AppLogger.error('PushNotificationService initialization failed', e);
  }
  
  // تهيئة مزامنة التوقيت
  final utcSync = UtcSyncService();
  await utcSync.syncWithUtc();

  // تثبيت اتجاه التطبيق عمودي
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // إعداد شريط الحالة
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  
  // تسجيل أخطاء Flutter
  FlutterError.onError = (details) {
    AppLogger.error('Flutter Error', details.exception, details.stack);
  };
  
  // إنشاء ProviderContainer
  final container = ProviderContainer(
    overrides: [
      localStorageProvider.overrideWithValue(localStorageService),
      localDatabaseServiceProvider.overrideWithValue(localDatabaseService),
      trackingServiceProvider.overrideWithValue(trackingService),
      utcSyncServiceProvider.overrideWithValue(utcSync),
    ],
  );

  // ✅ أضف هذا:
  try {
    await RemoteConfigService.fetchOnStartup(container);
  } catch (e) {
    AppLogger.error('Failed to fetch remote config on startup', e);
  }

  // ✅ تهيئة خدمة المزامنة
  container.read(syncStateProvider.notifier);
  
  // ✅ تهيئة الـ SyncEngine الجديد
  container.read(syncEngineProvider);

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const GoldenFeatherApp(),
    ),
  );
}


