import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_radius.dart';
import '../theme/app_spacing.dart';
// import '../theme/app_typography.dart';

/// أنواع الأزرار في ELD
enum EldButtonType {
  /// زر اتصال - أخضر (الحل الصحيح)
  connect,
  /// زر متابعة بدون - رمادي غامق (الحل المؤقت)
  continueDisconnected,
  /// زر إرسال - أخضر باهت
  send,
  /// زر موافقة - أخضر
  agree,
  /// زر خطر - أحمر
  danger,
}

/// زر موحد حسب دليل تصميم ELD
class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final EldButtonType type;
  final bool isFullWidth;
  final IconData? icon;
  final bool isLoading;

  const AppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.type = EldButtonType.agree,
    this.isFullWidth = true,
    this.icon,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: isFullWidth ? double.infinity : null,
      height: AppSpacing.buttonHeight,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: _buttonStyle(),
        child: isLoading 
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
              ) 
            : _buildChild(),
      ),
    );
  }

  ButtonStyle _buttonStyle() {
    return ElevatedButton.styleFrom(
      backgroundColor: _backgroundColor,
      foregroundColor: _foregroundColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.button),
      ),
    );
  }

  Color get _backgroundColor {
    return switch (type) {
      EldButtonType.connect => AppColors.successGreen,
      EldButtonType.agree => AppColors.successGreen,
      EldButtonType.continueDisconnected => AppColors.darkButton,
      EldButtonType.send => AppColors.paleGreen,
      EldButtonType.danger => AppColors.dangerRed,
    };
  }

  Color get _foregroundColor {
    return switch (type) {
      EldButtonType.send => AppColors.textPrimary,
      _ => AppColors.surface,
    };
  }

  Widget _buildChild() {
    if (icon != null) {
      return FittedBox(
        fit: BoxFit.scaleDown,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 20),
            const SizedBox(width: AppSpacing.sm),
            Text(label),
          ],
        ),
      );
    }
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(label),
    );
  }
}


