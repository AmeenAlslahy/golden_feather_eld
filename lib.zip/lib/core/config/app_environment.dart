import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../utils/logger.dart';

enum AppEnvironment {
  mock,
  development,
  staging,
  production,
  temporaryTraccar,
}

class AppEnvironmentConfig {
  static AppEnvironment _current = AppEnvironment.development;
  static AppEnvironment get current => _current;
  
  static Map<String, String>? _testEnv;

  static Future<void> init({Map<String, String>? testEnv}) async {
    _testEnv = testEnv;
    try {
      if (testEnv == null) {
        await dotenv.load(fileName: '.env');
      }
      final envString = _getEnv('TRACCAR_ENVIRONMENT') ?? 'development';
      
      switch (envString) {
        case 'mock':
          _current = AppEnvironment.mock;
          break;
        case 'staging':
          _current = AppEnvironment.staging;
          break;
        case 'production':
          _current = AppEnvironment.production;
          break;
        case 'temporaryTraccar':
          _current = AppEnvironment.temporaryTraccar;
          break;
        case 'development':
        default:
          _current = AppEnvironment.development;
      }
      
      AppLogger.info('Environment initialized as: ${_current.name}');
    } catch (e) {
      AppLogger.warning('Failed to load .env file, defaulting to development');
      _current = AppEnvironment.development;
    }
  }

  static String? _getEnv(String key) {
    if (_testEnv != null) return _testEnv![key];
    return dotenv.env[key];
  }

  // Traccar Settings
  static String get traccarBaseUrl => _getEnv('TRACCAR_BASE_URL') ?? '';
  static String get traccarUsername => _getEnv('TRACCAR_USERNAME') ?? '';
  static String get traccarPassword => _getEnv('TRACCAR_PASSWORD') ?? '';
  static String get traccarDeviceId => _getEnv('TRACCAR_DEVICE_ID') ?? '';
  static String get traccarDeviceUniqueId => _getEnv('TRACCAR_DEVICE_UNIQUE_ID') ?? '';
  
  static bool get isValidTemporaryTraccarConfig {
    if (current != AppEnvironment.temporaryTraccar) return true;
    
    final valid = traccarBaseUrl.isNotEmpty &&
        traccarUsername.isNotEmpty &&
        traccarPassword.isNotEmpty &&
        traccarDeviceId.isNotEmpty &&
        traccarDeviceUniqueId.isNotEmpty;
        
    if (!valid) {
      AppLogger.error('Invalid Temporary Traccar Config! Check .env variables.');
    }
    return valid;
  }
}
