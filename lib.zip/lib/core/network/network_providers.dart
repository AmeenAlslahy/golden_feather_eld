import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'network_info.dart';
import 'dio_client.dart';

/// Provider لحالة الاتصال
final isConnectedProvider = StreamProvider<bool>((ref) {
  final networkInfo = ref.watch(networkInfoProvider);
  return networkInfo.onConnectivityChanged;
});

/// Provider للشبكة
final networkInfoProvider = Provider<NetworkInfo>((ref) {
  return NetworkInfoImpl();
});

/// Provider لـ DioClient
final dioClientProvider = Provider<DioClient>((ref) {
  return DioClient();
});


