class ApiException implements Exception {
  final String message;
  final String arabicMessage;
  final int? statusCode;

  const ApiException({
    required this.message,
    required this.arabicMessage,
    this.statusCode,
  });

  @override
  String toString() => 'ApiException: $message';
}


