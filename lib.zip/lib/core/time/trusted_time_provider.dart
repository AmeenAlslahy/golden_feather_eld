abstract class TrustedTimeProvider {
  /// Returns the trusted current UTC time.
  DateTime get currentUtc;

  /// Returns the trusted current time in the fleet's regulatory timezone.
  DateTime get currentFleetTime;

  /// Indicates if the time provider is anchored to a trusted server.
  bool get isAnchored;

  /// Indicates if the time provider is considered stale or invalid (e.g. offline too long).
  bool get isStale;

  /// Anchors the provider to a trusted server time.
  void anchor(DateTime serverUtc);
}

/// A production implementation that uses a monotonic Stopwatch 
/// to calculate elapsed time, preventing wall-clock exploits.
class MonotonicTrustedTimeProvider implements TrustedTimeProvider {
  final Stopwatch _stopwatch = Stopwatch();
  DateTime? _trustedServerUtcAtSync;
  
  // Hardcoded for now until dynamic config is implemented.
  // Represents the timezone offset of the fleet's regulatory zone.
  final Duration _fleetTimezoneOffset = const Duration(hours: -8); // PST

  @override
  bool get isAnchored => _trustedServerUtcAtSync != null;

  @override
  bool get isStale {
    if (!isAnchored) return true;
    // For now, if offline for more than 7 days, consider stale.
    if (_stopwatch.elapsed.inDays >= 7) return true;
    return false;
  }

  @override
  void anchor(DateTime serverUtc) {
    _trustedServerUtcAtSync = serverUtc.toUtc();
    _stopwatch.reset();
    _stopwatch.start();
  }

  @override
  DateTime get currentUtc {
    if (!isAnchored) {
      // Uninitialized / Invalid state fallback (Not trusted!)
      // In a strict implementation, this might throw an exception,
      // but for gradual adoption we fallback to device clock if not anchored.
      return DateTime.now().toUtc();
    }
    return _trustedServerUtcAtSync!.add(_stopwatch.elapsed);
  }

  @override
  DateTime get currentFleetTime {
    // Add offset to UTC to get fleet time
    return currentUtc.add(_fleetTimezoneOffset);
  }
}

/// A fake implementation for deterministic testing.
class FakeTrustedTimeProvider implements TrustedTimeProvider {
  DateTime _mockUtcTime;
  final Duration _fleetTimezoneOffset;
  bool _isAnchored = true;
  bool _isStale = false;

  FakeTrustedTimeProvider({
    required DateTime initialUtcTime,
    Duration fleetTimezoneOffset = const Duration(hours: 0),
  })  : _mockUtcTime = initialUtcTime.toUtc(),
        _fleetTimezoneOffset = fleetTimezoneOffset;

  @override
  DateTime get currentUtc => _mockUtcTime;

  @override
  DateTime get currentFleetTime => currentUtc.add(_fleetTimezoneOffset);

  @override
  bool get isAnchored => _isAnchored;

  @override
  bool get isStale => _isStale;

  @override
  void anchor(DateTime serverUtc) {
    _mockUtcTime = serverUtc.toUtc();
    _isAnchored = true;
    _isStale = false;
  }

  /// TEST ONLY: Advance the fake clock.
  void advance(Duration duration) {
    _mockUtcTime = _mockUtcTime.add(duration);
  }

  /// TEST ONLY: Set state manually.
  void setState({bool? anchored, bool? stale}) {
    if (anchored != null) _isAnchored = anchored;
    if (stale != null) _isStale = stale;
  }
}
