import 'dart:convert';
import 'package:dartz/dartz.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../errors/failures.dart';
import '../utils/logger.dart';

class LocalDatabaseService {
  static const String eventsBoxName = 'events_box';
  static const String periodsBoxName = 'periods_box';
  static const String diagnosticsBoxName = 'diagnostics_box';
  static const String violationsBoxName = 'violations_box';
  static const String auditBoxName = 'audit_box';

  late Box<String> _eventsBox;
  late Box<String> _periodsBox;
  late Box<String> _diagnosticsBox;
  late Box<String> _violationsBox;
  late Box<String> _auditBox;
  late SharedPreferences _prefs;

  Future<void> init() async {
    try {
      await Hive.initFlutter();
      
      _eventsBox = await Hive.openBox<String>(eventsBoxName);
      _periodsBox = await Hive.openBox<String>(periodsBoxName);
      _diagnosticsBox = await Hive.openBox<String>(diagnosticsBoxName);
      _violationsBox = await Hive.openBox<String>(violationsBoxName);
      _auditBox = await Hive.openBox<String>(auditBoxName);
      
      _prefs = await SharedPreferences.getInstance();
      
      AppLogger.info('✅ LocalDatabaseService initialized successfully');
    } catch (e, stack) {
      AppLogger.error('❌ Failed to initialize LocalDatabaseService', e, stack);
      rethrow;
    }
  }

  // --- Events ---
  Future<Either<Failure, bool>> saveEvent(Map<String, dynamic> eventData) async {
    try {
      final dateStr = _extractDateStr(eventData['timestamp'] as String?);
      final currentList = _getEventsByDateStr(dateStr);
      currentList.add(eventData);
      
      await _eventsBox.put(dateStr, jsonEncode(currentList));
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to save event', e);
      return Left(CacheFailure(message: 'Failed to save event: $e', arabicMessage: 'فشل في حفظ الحدث'));
    }
  }

  Future<Either<Failure, List<Map<String, dynamic>>>> getEventsByDate(DateTime date) async {
    try {
      final dateStr = _formatDate(date);
      final list = _getEventsByDateStr(dateStr);
      return Right(list);
    } catch (e) {
      AppLogger.error('Failed to get events', e);
      return Left(CacheFailure(message: 'Failed to get events: $e', arabicMessage: 'فشل في جلب الأحداث'));
    }
  }

  // --- Periods ---
  Future<Either<Failure, bool>> savePeriod(Map<String, dynamic> periodData) async {
    try {
      final dateStr = _extractDateStr(periodData['start_time'] as String?);
      final currentList = _getPeriodsByDateStr(dateStr);
      currentList.add(periodData);
      
      await _periodsBox.put(dateStr, jsonEncode(currentList));
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to save period', e);
      return Left(CacheFailure(message: 'Failed to save period: $e', arabicMessage: 'فشل في حفظ الفترة'));
    }
  }

  Future<Either<Failure, List<Map<String, dynamic>>>> getPeriodsByDate(DateTime date) async {
    try {
      final dateStr = _formatDate(date);
      final list = _getPeriodsByDateStr(dateStr);
      return Right(list);
    } catch (e) {
      AppLogger.error('Failed to get periods', e);
      return Left(CacheFailure(message: 'Failed to get periods: $e', arabicMessage: 'فشل في جلب الفترات'));
    }
  }

  // --- Diagnostics ---
  Future<Either<Failure, bool>> saveDiagnostic(Map<String, dynamic> diagnosticData) async {
    try {
      final dateStr = _extractDateStr(diagnosticData['timestamp'] as String?);
      final currentList = _getDiagnosticsByDateStr(dateStr);
      currentList.add(diagnosticData);
      
      await _diagnosticsBox.put(dateStr, jsonEncode(currentList));
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to save diagnostic', e);
      return Left(CacheFailure(message: 'Failed to save diagnostic: $e', arabicMessage: 'فشل في حفظ التشخيص'));
    }
  }

  Future<Either<Failure, List<Map<String, dynamic>>>> getDiagnostics(DateTime date) async {
    try {
      final dateStr = _formatDate(date);
      final list = _getDiagnosticsByDateStr(dateStr);
      return Right(list);
    } catch (e) {
      AppLogger.error('Failed to get diagnostics', e);
      return Left(CacheFailure(message: 'Failed to get diagnostics: $e', arabicMessage: 'فشل في جلب التشخيصات'));
    }
  }

  // --- Violations ---
  Future<Either<Failure, bool>> saveViolation(Map<String, dynamic> violationData) async {
    try {
      final dateStr = _extractDateStr(violationData['timestamp'] as String?);
      final currentList = _getViolationsByDateStr(dateStr);
      currentList.add(violationData);
      
      await _violationsBox.put(dateStr, jsonEncode(currentList));
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to save violation', e);
      return Left(CacheFailure(message: 'Failed to save violation: $e', arabicMessage: 'فشل في حفظ الانتهاك'));
    }
  }

  Future<Either<Failure, List<Map<String, dynamic>>>> getViolations(DateTime date) async {
    try {
      final dateStr = _formatDate(date);
      final list = _getViolationsByDateStr(dateStr);
      return Right(list);
    } catch (e) {
      AppLogger.error('Failed to get violations', e);
      return Left(CacheFailure(message: 'Failed to get violations: $e', arabicMessage: 'فشل في جلب الانتهاكات'));
    }
  }

  // --- Audit ---
  Future<Either<Failure, bool>> saveAudit(Map<String, dynamic> auditData) async {
    try {
      final dateStr = _extractDateStr(auditData['timestamp'] as String?);
      final currentList = _getAuditByDateStr(dateStr);
      currentList.add(auditData);
      
      await _auditBox.put(dateStr, jsonEncode(currentList));
      return const Right(true);
    } catch (e) {
      AppLogger.error('Failed to save audit', e);
      return Left(CacheFailure(message: 'Failed to save audit: $e', arabicMessage: 'فشل في حفظ سجل التدقيق'));
    }
  }

  Future<Either<Failure, List<Map<String, dynamic>>>> getAudit(DateTime date) async {
    try {
      final dateStr = _formatDate(date);
      final list = _getAuditByDateStr(dateStr);
      return Right(list);
    } catch (e) {
      AppLogger.error('Failed to get audit', e);
      return Left(CacheFailure(message: 'Failed to get audit: $e', arabicMessage: 'فشل في جلب سجل التدقيق'));
    }
  }

  // --- Simple Settings (SharedPreferences) ---
  Future<void> saveSetting(String key, String value) async {
    await _prefs.setString(key, value);
  }

  String? getSetting(String key) {
    return _prefs.getString(key);
  }

  // --- Helpers ---
  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  String _extractDateStr(String? isoString) {
    if (isoString == null) return _formatDate(DateTime.now());
    try {
      return _formatDate(DateTime.parse(isoString));
    } catch (_) {
      return _formatDate(DateTime.now());
    }
  }

  List<Map<String, dynamic>> _getEventsByDateStr(String dateStr) {
    final data = _eventsBox.get(dateStr);
    if (data == null) return [];
    try {
      final decoded = jsonDecode(data) as List;
      return decoded.map((e) => e as Map<String, dynamic>).toList();
    } catch (_) {
      return [];
    }
  }

  List<Map<String, dynamic>> _getPeriodsByDateStr(String dateStr) {
    final data = _periodsBox.get(dateStr);
    if (data == null) return [];
    try {
      final decoded = jsonDecode(data) as List;
      return decoded.map((e) => e as Map<String, dynamic>).toList();
    } catch (_) {
      return [];
    }
  }

  List<Map<String, dynamic>> _getDiagnosticsByDateStr(String dateStr) {
    final data = _diagnosticsBox.get(dateStr);
    if (data == null) return [];
    try {
      final decoded = jsonDecode(data) as List;
      return decoded.map((e) => e as Map<String, dynamic>).toList();
    } catch (_) {
      return [];
    }
  }

  List<Map<String, dynamic>> _getViolationsByDateStr(String dateStr) {
    final data = _violationsBox.get(dateStr);
    if (data == null) return [];
    try {
      final decoded = jsonDecode(data) as List;
      return decoded.map((e) => e as Map<String, dynamic>).toList();
    } catch (_) {
      return [];
    }
  }

  List<Map<String, dynamic>> _getAuditByDateStr(String dateStr) {
    final data = _auditBox.get(dateStr);
    if (data == null) return [];
    try {
      final decoded = jsonDecode(data) as List;
      return decoded.map((e) => e as Map<String, dynamic>).toList();
    } catch (_) {
      return [];
    }
  }
}

final localDatabaseServiceProvider = Provider<LocalDatabaseService>((ref) {
  throw UnimplementedError('Initialize localDatabaseServiceProvider in main.dart');
});
