import 'dart:async';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/tracking/data/services/tracking_service.dart';
import 'local_storage_service.dart';
import '../utils/logger.dart';

/// خدمة الإشعارات - من push_service.dart الأصلي
class PushNotificationService {
  final TrackingService _trackingService;
  final LocalStorageService _storage;

  PushNotificationService({
    required TrackingService trackingService,
    required LocalStorageService storage,
  })  : _trackingService = trackingService,
        _storage = storage;

  /// تهيئة الخدمة
  static Future<void> init({
    required TrackingService trackingService,
    required LocalStorageService storage,
  }) async {
    final service = PushNotificationService(
      trackingService: trackingService,
      storage: storage,
    );

    await FirebaseMessaging.instance.requestPermission();

    FirebaseMessaging.onBackgroundMessage(_backgroundHandler);
    FirebaseMessaging.onMessage.listen(service._onMessage);
    FirebaseMessaging.instance.onTokenRefresh.listen((token) => service._uploadToken(token));

    unawaited(service._uploadInitialToken());
    AppLogger.info('📨 PushNotificationService initialized');
  }

  @pragma('vm:entry-point')
  static Future<void> _backgroundHandler(RemoteMessage message) async {
    await Firebase.initializeApp();
    final storage = LocalStorageService();
    await storage.init();
    
    // معالجة الأمر في الخلفية
    final command = message.data['command'];
    FirebaseCrashlytics.instance.log('push_background: $command');
    
    if (command == 'positionSingle') {
      // لا يمكن بدء التتبع من الخلفية بدون تهيئة كاملة
      AppLogger.info('📨 Background push ignored: $command');
    }
  }

  Future<void> _onMessage(RemoteMessage message) async {
    final command = message.data['command'];
    FirebaseCrashlytics.instance.log('push_command: $command');
    AppLogger.info('📨 Push received: $command');

    try {
      switch (command) {
        case 'positionSingle':
          await _trackingService.requestPosition();
        case 'positionPeriodic':
          await _trackingService.start();
        case 'positionStop':
          await _trackingService.stop();
        case 'factoryReset':
          await _storage.removePassword();
          AppLogger.info('🏭 Factory reset: password cleared');
      }
    } on PlatformException {
      AppLogger.error('Platform exception in push handler');
    }
  }

  Future<void> _uploadToken(String? token) async {
    if (token == null) return;
    final id = _storage.deviceId;
    final url = _storage.serverUrl;
    if (id.isEmpty || url.isEmpty) return;

    try {
      final request = await HttpClient().postUrl(Uri.parse(url));
      request.headers.contentType = ContentType.parse('application/x-www-form-urlencoded');
      request.write('id=${Uri.encodeComponent(id)}&notificationToken=${Uri.encodeComponent(token)}');
      await request.close();
      AppLogger.info('📤 Token uploaded to server');
    } catch (e) {
      AppLogger.error('Failed to upload token', e);
    }
  }

  Future<void> _uploadInitialToken() async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      await _uploadToken(token);
    } catch (e) {
      AppLogger.error('Failed to get initial token', e);
    }
  }
}
