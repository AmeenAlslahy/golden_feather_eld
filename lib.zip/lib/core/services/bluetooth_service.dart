import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../utils/logger.dart';

/// جهاز ELD
class EldDevice {
  final String name;
  final String macAddress;
  final String? vin;
  final int rssi;
  final bool isConnected;

  const EldDevice({
    required this.name,
    required this.macAddress,
    this.vin,
    required this.rssi,
    this.isConnected = false,
  });

  factory EldDevice.fromMap(Map<dynamic, dynamic> map) {
    return EldDevice(
      name: map['name'] as String? ?? 'Unknown',
      macAddress: map['macAddress'] as String? ?? '',
      vin: map['vin'] as String?,
      rssi: map['rssi'] as int? ?? 0,
      isConnected: map['isConnected'] as bool? ?? false,
    );
  }
}

/// حالة اتصال Bluetooth
enum BluetoothConnectionStatus {
  disconnected,
  scanning,
  connecting,
  connected,
  error,
}

/// بيانات وحدة التحكم في المحرك
class EcmData {
  final double speedMph;
  final int engineRpm;
  final double odometerMiles;
  final double engineHours;
  final DateTime timestamp;

  const EcmData({
    required this.speedMph,
    required this.engineRpm,
    required this.odometerMiles,
    required this.engineHours,
    required this.timestamp,
  });

  factory EcmData.fromMap(Map<dynamic, dynamic> map) {
    return EcmData(
      speedMph: (map['speedMph'] as num?)?.toDouble() ?? 0.0,
      engineRpm: (map['engineRpm'] as num?)?.toInt() ?? 0,
      odometerMiles: (map['odometerMiles'] as num?)?.toDouble() ?? 0.0,
      engineHours: (map['engineHours'] as num?)?.toDouble() ?? 0.0,
      timestamp: map['timestamp'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['timestamp'] as int)
          : DateTime.now(),
    );
  }
}

/// واجهة تجريد اتصال البلوتوث
abstract class BluetoothDataSource {
  Stream<List<EldDevice>> startScanning();
  Future<void> stopScanning();
  Future<EldDevice?> connect(String macAddress);
  Future<void> disconnect();
  
  Stream<EcmData> get dataStream;
  Stream<BluetoothConnectionStatus> get statusStream;
  
  void dispose();
}

/// التنفيذ الحقيقي لـ Bluetooth عبر MethodChannel
class RealBluetoothDataSource implements BluetoothDataSource {
  static const MethodChannel _channel = MethodChannel('com.goldenfeather.eld/bluetooth');
  
  final _dataController = StreamController<EcmData>.broadcast();
  final _statusController = StreamController<BluetoothConnectionStatus>.broadcast();
  final _scanController = StreamController<List<EldDevice>>.broadcast();

  RealBluetoothDataSource() {
    _channel.setMethodCallHandler(_handleMethodCall);
  }

  Future<dynamic> _handleMethodCall(MethodCall call) async {
    try {
      switch (call.method) {
        case 'onDevicesFound':
          final list = call.arguments as List;
          final devices = list.map((e) => EldDevice.fromMap(e as Map)).toList();
          _scanController.add(devices);
          break;
        case 'onStatusChanged':
          final statusStr = call.arguments as String;
          final status = BluetoothConnectionStatus.values.firstWhere(
            (e) => e.name == statusStr,
            orElse: () => BluetoothConnectionStatus.error,
          );
          _statusController.add(status);
          break;
        case 'onDataReceived':
          final data = EcmData.fromMap(call.arguments as Map);
          _dataController.add(data);
          break;
      }
    } catch (e) {
      AppLogger.error('Error handling Bluetooth MethodCall: ${call.method}', e);
    }
  }

  @override
  Stream<List<EldDevice>> startScanning() {
    _channel.invokeMethod('startScanning');
    return _scanController.stream;
  }

  @override
  Future<void> stopScanning() async {
    await _channel.invokeMethod('stopScanning');
  }

  @override
  Future<EldDevice?> connect(String macAddress) async {
    final result = await _channel.invokeMethod('connect', {'macAddress': macAddress});
    if (result != null) {
      return EldDevice.fromMap(result as Map);
    }
    return null;
  }

  @override
  Future<void> disconnect() async {
    await _channel.invokeMethod('disconnect');
  }

  @override
  Stream<EcmData> get dataStream => _dataController.stream;

  @override
  Stream<BluetoothConnectionStatus> get statusStream => _statusController.stream;
  
  @override
  void dispose() {
    _dataController.close();
    _statusController.close();
    _scanController.close();
  }
}

/// التنفيذ الوهمي لـ Bluetooth للبيئة التطويرية
class MockBluetoothDataSource implements BluetoothDataSource {
  final _dataController = StreamController<EcmData>.broadcast();
  final _statusController = StreamController<BluetoothConnectionStatus>.broadcast();
  StreamSubscription? _mockDataSub;
  
  @override
  Stream<List<EldDevice>> startScanning() {
    _statusController.add(BluetoothConnectionStatus.scanning);
    return Stream.periodic(
      const Duration(seconds: 2),
      (_) => [
        const EldDevice(name: 'ELD Adapter 9824', macAddress: '00:11:22:33:44:55', rssi: -45),
        const EldDevice(name: 'ELD Adapter 7731', macAddress: 'AA:BB:CC:DD:EE:FF', rssi: -78),
      ],
    );
  }

  @override
  Future<void> stopScanning() async {
    _statusController.add(BluetoothConnectionStatus.disconnected);
  }

  @override
  Future<EldDevice?> connect(String macAddress) async {
    _statusController.add(BluetoothConnectionStatus.connecting);
    await Future.delayed(const Duration(seconds: 1));
    _statusController.add(BluetoothConnectionStatus.connected);
    
    _mockDataSub?.cancel();
    _mockDataSub = Stream.periodic(const Duration(seconds: 1), (_) {
      return EcmData(
        speedMph: 55.0 + (DateTime.now().millisecond % 10),
        engineRpm: 1500 + (DateTime.now().millisecond % 200),
        odometerMiles: 125000.0 + DateTime.now().millisecond / 1000,
        engineHours: 3500.0 + DateTime.now().millisecond / 3600000,
        timestamp: DateTime.now(),
      );
    }).listen((data) => _dataController.add(data));
    
    return EldDevice(
      name: 'ELD Adapter 9824',
      macAddress: macAddress,
      vin: '1FUJGLDR5CSBJ0527',
      rssi: -45,
      isConnected: true,
    );
  }

  @override
  Future<void> disconnect() async {
    _mockDataSub?.cancel();
    _statusController.add(BluetoothConnectionStatus.disconnected);
  }

  @override
  Stream<EcmData> get dataStream => _dataController.stream;

  @override
  Stream<BluetoothConnectionStatus> get statusStream => _statusController.stream;
  
  @override
  void dispose() {
    _mockDataSub?.cancel();
    _dataController.close();
    _statusController.close();
  }
}

/// خدمة Bluetooth محسنة لإدارة الذاكرة
class BluetoothService {
  final BluetoothDataSource _dataSource;
  
  BluetoothConnectionStatus _status = BluetoothConnectionStatus.disconnected;
  EldDevice? _connectedDevice;
  
  StreamSubscription? _dataSubscription;
  StreamSubscription? _statusSubscription;
  
  void Function(EcmData)? _onDataReceived;
  void Function(BluetoothConnectionStatus)? _onStatusChanged;

  BluetoothService({required BluetoothDataSource dataSource}) : _dataSource = dataSource {
    _statusSubscription = _dataSource.statusStream.listen((status) {
      _status = status;
      _onStatusChanged?.call(status);
      if (status == BluetoothConnectionStatus.disconnected) {
        _connectedDevice = null;
      }
    });
    
    _dataSubscription = _dataSource.dataStream.listen((data) {
      _onDataReceived?.call(data);
    });
  }

  BluetoothConnectionStatus get status => _status;
  EldDevice? get connectedDevice => _connectedDevice;
  bool get isConnected => _status == BluetoothConnectionStatus.connected;

  Stream<List<EldDevice>> startScanning() {
    AppLogger.info('🔍 BLE Scanning started');
    return _dataSource.startScanning();
  }

  void stopScanning() {
    AppLogger.info('🔍 BLE Scanning stopped');
    _dataSource.stopScanning();
  }

  Future<bool> connect(String macAddress) async {
    AppLogger.info('🔗 Connecting to $macAddress');
    final device = await _dataSource.connect(macAddress);
    if (device != null) {
      _connectedDevice = device;
      AppLogger.info('✅ Connected to $macAddress');
      return true;
    }
    return false;
  }

  Future<void> disconnect() async {
    await _dataSource.disconnect();
    AppLogger.info('🔌 Disconnected');
  }

  void onDataReceived(void Function(EcmData) callback) {
    _onDataReceived = callback;
  }

  void onStatusChanged(void Function(BluetoothConnectionStatus) callback) {
    _onStatusChanged = callback;
  }

  void dispose() {
    _dataSubscription?.cancel();
    _statusSubscription?.cancel();
    _dataSource.dispose();
    AppLogger.info('BluetoothService disposed');
  }
}

/// مزود مصدر بيانات البلوتوث
final bluetoothDataSourceProvider = Provider<BluetoothDataSource>((ref) {
  const bool useRealBluetooth = bool.fromEnvironment('USE_REAL_BLUETOOTH', defaultValue: false);
  final dataSource = useRealBluetooth ? RealBluetoothDataSource() : MockBluetoothDataSource();
  ref.onDispose(() => dataSource.dispose());
  return dataSource;
});

/// مزود خدمة Bluetooth
final bluetoothServiceProvider = Provider<BluetoothService>((ref) {
  final dataSource = ref.watch(bluetoothDataSourceProvider);
  return BluetoothService(dataSource: dataSource);
});
