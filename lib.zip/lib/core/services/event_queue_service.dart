import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/logger.dart';

/// حدث مؤجل للمزامنة
class QueuedEvent {
  final String id;
  final String type;
  final Map<String, dynamic> data;
  final DateTime createdAt;
  final int retryCount;

  const QueuedEvent({
    required this.id,
    required this.type,
    required this.data,
    required this.createdAt,
    this.retryCount = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'data': data,
        'created_at': createdAt.toIso8601String(),
        'retry_count': retryCount,
      };

  factory QueuedEvent.fromJson(Map<String, dynamic> json) => QueuedEvent(
        id: json['id'],
        type: json['type'],
        data: json['data'],
        createdAt: DateTime.parse(json['created_at']),
        retryCount: json['retry_count'] ?? 0,
      );
}

/// خدمة طابور الأحداث المحلي
/// يضمن عدم فقدان أي حدث عند انقطاع الاتصال
class EventQueueService {
  static const String _queueKey = 'event_queue';
  static const int _maxRetries = 3;
  List<QueuedEvent> _queue = [];

  // ========== التهيئة ==========

  Future<void> init() async {
    await _loadQueue();
    AppLogger.info('EventQueueService initialized with ${_queue.length} pending events');
  }

  /// تحميل الطابور من التخزين
  Future<void> _loadQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_queueKey);
    if (data != null) {
      final List<dynamic> list = jsonDecode(data);
      _queue = list.map((e) => QueuedEvent.fromJson(e)).toList();
    }
  }

  /// حفظ الطابور للتخزين
  Future<void> _saveQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final data = jsonEncode(_queue.map((e) => e.toJson()).toList());
    await prefs.setString(_queueKey, data);
  }

  // ========== إضافة أحداث ==========

  /// إضافة حدث للطابور
  Future<void> enqueue(String type, Map<String, dynamic> data) async {
    final event = QueuedEvent(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: type,
      data: data,
      createdAt: DateTime.now(),
    );
    _queue.add(event);
    await _saveQueue();
    AppLogger.info('📥 Event queued: $type (${_queue.length} pending)');
  }

  /// الحصول على الأحداث المعلقة
  List<QueuedEvent> get pendingEvents => List.unmodifiable(_queue);

  /// عدد الأحداث المعلقة
  int get pendingCount => _queue.length;

  // ========== معالجة ==========

  /// محاولة إرسال جميع الأحداث المعلقة
  Future<int> processQueue(Future<bool> Function(QueuedEvent) processor) async {
    int successCount = 0;
    final failedEvents = <QueuedEvent>[];

    for (final event in _queue) {
      try {
        final success = await processor(event);
        if (success) {
          successCount++;
          AppLogger.info('✅ Event processed: ${event.type}');
        } else {
          failedEvents.add(event);
        }
      } catch (e) {
        final retryCount = event.retryCount + 1;
        if (retryCount < _maxRetries) {
          failedEvents.add(QueuedEvent(
            id: event.id,
            type: event.type,
            data: event.data,
            createdAt: event.createdAt,
            retryCount: retryCount,
          ));
        } else {
          AppLogger.error('❌ Event failed after $_maxRetries retries: ${event.type}');
        }
      }
    }

    _queue = failedEvents;
    await _saveQueue();
    AppLogger.info('📊 Queue processed: $successCount succeeded, ${failedEvents.length} pending');
    return successCount;
  }

  /// مسح الطابور
  Future<void> clear() async {
    _queue.clear();
    await _saveQueue();
  }
}

/// مزود خدمة الطابور
final eventQueueServiceProvider = Provider<EventQueueService>((ref) {
  return EventQueueService();
});


