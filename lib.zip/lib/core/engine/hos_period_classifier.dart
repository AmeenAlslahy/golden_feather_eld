/// أنواع الفترات في HOS
enum HosPeriodType {
  drive('قيادة', 'Drive'),
  stop('توقف', 'Stop'),
  rest('راحة طويلة', 'Rest'),
  breakPeriod('استراحة قصيرة', 'Break'),
  gap('فجوة بيانات', 'Gap');

  final String arabicName;
  final String englishName;
  const HosPeriodType(this.arabicName, this.englishName);
}

/// نموذج فترة HOS
class HosPeriod {
  final HosPeriodType type;
  final DateTime startTime;
  final DateTime endTime;
  final Duration duration;
  final double? distanceKm;

  const HosPeriod({
    required this.type,
    required this.startTime,
    required this.endTime,
    required this.duration,
    this.distanceKm,
  });

  double get durationHours => duration.inMinutes / 60.0;
}

/// مصنف فترات HOS
class HosPeriodClassifier {
  static const double speedThreshold = 8.0; // كم/س
  static const Duration longRestThreshold = Duration(hours: 3);
  static const Duration dataGapThreshold = Duration(minutes: 5);

  /// تصنيف فترة بناءً على السرعة والمدة
  static HosPeriodType classify({
    required double avgSpeed,
    required Duration duration,
    required bool hasDataGap,
  }) {
    if (hasDataGap) return HosPeriodType.gap;
    if (avgSpeed > speedThreshold) return HosPeriodType.drive;
    if (duration >= longRestThreshold) return HosPeriodType.rest;
    if (duration < longRestThreshold && avgSpeed <= speedThreshold) {
      return HosPeriodType.breakPeriod;
    }
    return HosPeriodType.stop;
  }

  /// حساب المسافة بين نقطتين (Haversine Formula)
  static double calculateDistance({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    const double earthRadiusKm = 6371.0;

    final dLat = _degreesToRadians(lat2 - lat1);
    final dLon = _degreesToRadians(lon2 - lon1);

    final a = _sinSquared(dLat / 2) +
        _cos(_degreesToRadians(lat1)) *
            _cos(_degreesToRadians(lat2)) *
            _sinSquared(dLon / 2);

    final c = 2 * _atan2(_sqrt(a), _sqrt(1 - a));

    return earthRadiusKm * c;
  }

  static double _degreesToRadians(double degrees) => degrees * 3.14159265359 / 180.0;
  static double _sinSquared(double x) => _sin(x) * _sin(x);
  static double _sin(double x) => _sinLookup(x);
  static double _cos(double x) => _cosLookup(x);
  static double _sqrt(double x) => x <= 0 ? 0 : _sqrtLookup(x);
  static double _atan2(double y, double x) => _atan2Lookup(y, x);

  // استخدام دوال dart:math في التنفيذ الحقيقي
  static double _sinLookup(double x) {
    double result = x;
    double term = x;
    for (int i = 1; i <= 10; i++) {
      term *= -x * x / ((2 * i) * (2 * i + 1));
      result += term;
    }
    return result;
  }

  static double _cosLookup(double x) {
    double result = 1.0;
    double term = 1.0;
    for (int i = 1; i <= 10; i++) {
      term *= -x * x / ((2 * i - 1) * (2 * i));
      result += term;
    }
    return result;
  }

  static double _sqrtLookup(double x) {
    double guess = x / 2;
    for (int i = 0; i < 20; i++) {
      guess = (guess + x / guess) / 2;
    }
    return guess;
  }

  static double _atan2Lookup(double y, double x) {
    if (x > 0) return _atan(y / x);
    if (x < 0 && y >= 0) return _atan(y / x) + 3.14159265359;
    if (x < 0 && y < 0) return _atan(y / x) - 3.14159265359;
    if (x == 0 && y > 0) return 3.14159265359 / 2;
    if (x == 0 && y < 0) return -3.14159265359 / 2;
    return 0;
  }

  static double _atan(double x) {
    double result = x;
    double term = x;
    for (int i = 1; i <= 20; i++) {
      term *= -x * x;
      result += term / (2 * i + 1);
    }
    return result;
  }
}
