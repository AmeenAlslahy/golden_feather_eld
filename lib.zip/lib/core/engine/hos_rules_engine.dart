// import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/utils/logger.dart';
import 'hos_calculator.dart';
import 'hos_state_machine.dart';

/// محرك قواعد ساعات الخدمة (HOS Rules Engine)
/// معزول تماماً عن واجهة المستخدم لضمان الدقة والاختبار
class HosRulesEngine {
  final HosCalculator _calculator;
  final HosStateMachine _stateMachine;

  HosRulesEngine({
    required HosCalculator calculator,
    required HosStateMachine stateMachine,
  })  : _calculator = calculator,
        _stateMachine = stateMachine;

  /// معالجة حدث جديد من جهاز ELD
  HosStatusUpdate processEvent(EldEvent event) {
    // 1. التحقق من التبديل الآلي للقيادة
    if (_shouldAutoTransitionToDriving(event)) {
      _stateMachine.transitionTo(DutyStatus.driving);
      AppLogger.info('🔄 Auto transition to DRIVING');
    }

    // 2. حساب الحدود الأربعة
    final limits = _calculator.calculateAllLimits(
      drivingHours: _stateMachine.totalDrivingHours,
      shiftStartTime: _stateMachine.shiftStartTime,
      cycleHours: _stateMachine.cycleHours,
    );

    // 3. التحقق من التنبيهات
    final alerts = _generateAlerts(limits);

    // 4. التحقق من الانتهاكات
    final violations = _checkViolations(limits);

    return HosStatusUpdate(
      currentStatus: _stateMachine.currentStatus,
      limits: limits,
      alerts: alerts,
      violations: violations,
      remainingDriveMinutes: limits.remainingDriveMinutes,
      remainingShiftMinutes: limits.remainingShiftMinutes,
      remainingCycleHours: limits.remainingCycleHours,
      breakRequired: limits.breakRequired,
      breakRemainingMinutes: limits.breakRemainingMinutes,
    );
  }

  /// التبديل الآلي إلى القيادة
  bool _shouldAutoTransitionToDriving(EldEvent event) {
    return event.speedMph > 5.0 &&
           event.speedDurationSeconds >= 60 &&
           _stateMachine.currentStatus != DutyStatus.driving;
  }

  /// تبديل يدوي للحالة
  void manualTransition(DutyStatus newStatus, {String? annotation}) {
    // منع التغيير اليدوي أثناء القيادة
    if (_stateMachine.currentStatus == DutyStatus.driving &&
        newStatus != DutyStatus.driving) {
      AppLogger.warning('⚠️ Cannot manually change from DRIVING');
      return;
    }

    _stateMachine.transitionTo(newStatus, annotation: annotation);
    AppLogger.info('👤 Manual transition to ${newStatus.name}');
  }

  /// توليد التنبيهات
  List<HosAlert> _generateAlerts(HosLimits limits) {
    final alerts = <HosAlert>[];

    // تنبيهات القيادة
    if (limits.remainingDriveMinutes <= 15 && limits.remainingDriveMinutes > 0) {
      alerts.add(HosAlert(
        type: HosAlertType.drivingExpiring,
        message: '⚠️ 15 دقيقة متبقية للقيادة',
        severity: AlertSeverity.critical,
        remainingMinutes: limits.remainingDriveMinutes,
      ));
    } else if (limits.remainingDriveMinutes <= 30 && limits.remainingDriveMinutes > 15) {
      alerts.add(HosAlert(
        type: HosAlertType.drivingExpiring,
        message: '⚠️ 30 دقيقة متبقية للقيادة',
        severity: AlertSeverity.warning,
        remainingMinutes: limits.remainingDriveMinutes,
      ));
    } else if (limits.remainingDriveMinutes <= 60 && limits.remainingDriveMinutes > 30) {
      alerts.add(HosAlert(
        type: HosAlertType.drivingExpiring,
        message: 'تنبيه: 60 دقيقة متبقية للقيادة',
        severity: AlertSeverity.info,
        remainingMinutes: limits.remainingDriveMinutes,
      ));
    }

    // تنبيه الاستراحة الإلزامية
    if (limits.breakRequired && limits.breakRemainingMinutes > 0) {
      alerts.add(HosAlert(
        type: HosAlertType.breakRequired,
        message: 'استراحة مطلوبة: ${limits.breakRemainingMinutes} دقيقة متبقية',
        severity: AlertSeverity.warning,
        remainingMinutes: limits.breakRemainingMinutes,
      ));
    }

    // تنبيه نافذة العمل
    if (limits.remainingShiftMinutes <= 60 && limits.remainingShiftMinutes > 0) {
      alerts.add(HosAlert(
        type: HosAlertType.shiftExpiring,
        message: 'نافذة العمل على وشك الانتهاء',
        severity: AlertSeverity.warning,
        remainingMinutes: limits.remainingShiftMinutes,
      ));
    }

    return alerts;
  }

  /// التحقق من الانتهاكات
  List<HosViolation> _checkViolations(HosLimits limits) {
    final violations = <HosViolation>[];

    if (limits.remainingDriveMinutes <= 0) {
      violations.add(const HosViolation(
        type: HosViolationType.drivingLimitExceeded,
        message: '❌ تجاوز حد القيادة 11 ساعة',
      ));
    }

    if (limits.remainingShiftMinutes <= 0) {
      violations.add(const HosViolation(
        type: HosViolationType.shiftWindowExceeded,
        message: '❌ تجاوز نافذة العمل 14 ساعة',
      ));
    }

    if (limits.remainingCycleHours <= 0) {
      violations.add(const HosViolation(
        type: HosViolationType.cycleLimitExceeded,
        message: '❌ تجاوز حد الدورة الأسبوعية',
      ));
    }

    return violations;
  }

  /// الحالة الحالية
  HosStatusUpdate get currentStatus => HosStatusUpdate(
        currentStatus: _stateMachine.currentStatus,
        limits: _calculator.calculateAllLimits(
          drivingHours: _stateMachine.totalDrivingHours,
          shiftStartTime: _stateMachine.shiftStartTime,
          cycleHours: _stateMachine.cycleHours,
        ),
        alerts: [],
        violations: [],
        remainingDriveMinutes: 0,
        remainingShiftMinutes: 0,
        remainingCycleHours: 0,
        breakRequired: false,
        breakRemainingMinutes: 0,
      );

  /// إعادة تعيين
  void reset() {
    _stateMachine.reset();
  }

  void dispose() {
    _stateMachine.dispose();
  }
}

// ========== النماذج ==========

/// حالات الخدمة المعتمدة من FMCSA
enum DutyStatus {
  offDuty('Off Duty', 'خارج الخدمة'),
  sleeperBerth('Sleeper Berth', 'النوم'),
  onDutyNotDriving('On Duty', 'على أهبة العمل'),
  driving('Driving', 'قيادة'),
  personalUse('Personal Use', 'استخدام شخصي');

  final String englishName;
  final String arabicName;
  const DutyStatus(this.englishName, this.arabicName);
}

/// أنواع التنبيهات
enum HosAlertType {
  drivingExpiring,
  shiftExpiring,
  cycleExpiring,
  breakRequired,
}

/// مستويات الخطورة
enum AlertSeverity {
  info,
  warning,
  critical,
}

/// أنواع الانتهاكات
enum HosViolationType {
  drivingLimitExceeded,
  shiftWindowExceeded,
  cycleLimitExceeded,
}

/// تنبيه
class HosAlert {
  final HosAlertType type;
  final String message;
  final AlertSeverity severity;
  final int remainingMinutes;

  const HosAlert({
    required this.type,
    required this.message,
    required this.severity,
    required this.remainingMinutes,
  });
}

/// انتهاك
class HosViolation {
  final HosViolationType type;
  final String message;

  const HosViolation({
    required this.type,
    required this.message,
  });
}


/// حدث من جهاز ELD
class EldEvent {
  final double speedMph;
  final int speedDurationSeconds;
  final double odometerMiles;
  final double engineHours;
  final DateTime timestamp;

  const EldEvent({
    required this.speedMph,
    required this.speedDurationSeconds,
    required this.odometerMiles,
    required this.engineHours,
    required this.timestamp,
  });
}

/// تحديث حالة HOS
class HosStatusUpdate {
  final DutyStatus currentStatus;
  final HosLimits limits;
  final List<HosAlert> alerts;
  final List<HosViolation> violations;
  final int remainingDriveMinutes;
  final int remainingShiftMinutes;
  final double remainingCycleHours;
  final bool breakRequired;
  final int breakRemainingMinutes;

  const HosStatusUpdate({
    required this.currentStatus,
    required this.limits,
    required this.alerts,
    required this.violations,
    required this.remainingDriveMinutes,
    required this.remainingShiftMinutes,
    required this.remainingCycleHours,
    required this.breakRequired,
    required this.breakRemainingMinutes,
  });

  bool get hasViolations => violations.isNotEmpty;
  bool get hasCriticalAlerts => alerts.any((a) => a.severity == AlertSeverity.critical);
}


