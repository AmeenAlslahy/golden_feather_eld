import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/utils/logger.dart';
import '../../../features/logs/domain/repositories/log_repository.dart';
import '../../../features/logs/data/repositories/log_repository_impl.dart';
import '../../services/live_tracking_data_source.dart';
import '../hos_rules_engine.dart'; // For EldEvent

/// حدث تغيير حالة (تُستخدم للحفظ أو للتاريخ)
class DutyStatusEvent {
  final String status;
  final DateTime timestamp;
  final double? latitude;
  final double? longitude;
  final double? odometer;
  final double? engineHours;

  const DutyStatusEvent({
    required this.status,
    required this.timestamp,
    this.latitude,
    this.longitude,
    this.odometer,
    this.engineHours,
  });
}

/// فترة زمنية
class DutyPeriod {
  final String status;
  final DateTime startTime;
  final DateTime endTime;
  final double? startOdometer;
  final double? endOdometer;
  final double? startLat;
  final double? startLon;
  final double? endLat;
  final double? endLon;

  const DutyPeriod({
    required this.status,
    required this.startTime,
    required this.endTime,
    this.startOdometer,
    this.endOdometer,
    this.startLat,
    this.startLon,
    this.endLat,
    this.endLon,
  });

  Duration get duration => endTime.difference(startTime);
  double? get distanceKm {
    if (startLat != null && startLon != null && endLat != null && endLon != null) {
      return null; // سيتم استخدامه لاحقا مع Haversine
    }
    return null;
  }
}

/// متتبع حالة السائق
class DutyStatusTracker {
  final LogRepository _logRepository;
  final LiveTrackingDataSource _trackingDataSource;
  
  StreamSubscription<EldEvent>? _eventSubscription;

  final List<DutyStatusEvent> _events = [];
  final List<DutyPeriod> _periods = [];
  String _currentStatus = 'off_duty';
  DutyStatusEvent? _lastEvent;

  DutyStatusTracker(this._logRepository, this._trackingDataSource) {
    _startListening();
  }

  List<DutyStatusEvent> get events => List.unmodifiable(_events);
  List<DutyPeriod> get periods => List.unmodifiable(_periods);
  String get currentStatus => _currentStatus;

  void _startListening() {
    _eventSubscription = _trackingDataSource.events.listen((eldEvent) {
      _processEldEvent(eldEvent);
    });
  }

  void _processEldEvent(EldEvent eldEvent) {
    // 1. التحقق من التبديل الآلي (سرعة > 5 ميل/س)
    // EldEvent doesn't have lat/lon in this mock format directly, but we rely on what we have.
    String newStatus = _currentStatus;
    if (eldEvent.speedMph > 5.0) {
      newStatus = 'driving';
    } else if (eldEvent.speedMph == 0.0 && _currentStatus == 'driving') {
      // Simplification: if stopped, switch to on_duty.
      // A real engine waits 5 mins, but for now we transition.
      newStatus = 'on_duty';
    }

    if (newStatus != _currentStatus || _lastEvent == null) {
      _transitionTo(
        newStatus: newStatus,
        timestamp: eldEvent.timestamp,
        odometer: eldEvent.odometerMiles,
        engineHours: eldEvent.engineHours,
      );
    }
  }

  void _transitionTo({
    required String newStatus,
    required DateTime timestamp,
    double? latitude,
    double? longitude,
    double? odometer,
    double? engineHours,
  }) {
    final event = DutyStatusEvent(
      status: newStatus,
      timestamp: timestamp,
      latitude: latitude,
      longitude: longitude,
      odometer: odometer,
      engineHours: engineHours,
    );

    _events.add(event);

    // إنشاء فترة منتهية
    if (_lastEvent != null) {
      final period = DutyPeriod(
        status: _lastEvent!.status,
        startTime: _lastEvent!.timestamp,
        endTime: event.timestamp,
        startOdometer: _lastEvent!.odometer,
        endOdometer: event.odometer,
        startLat: _lastEvent!.latitude,
        startLon: _lastEvent!.longitude,
        endLat: event.latitude,
        endLon: event.longitude,
      );
      
      _periods.add(period);
      
      // حفظ الفترة عبر LogRepository
      _logRepository.savePeriod(period).then((result) {
        result.fold(
          (failure) => AppLogger.error('Failed to save period', failure.message),
          (success) => AppLogger.info('Period saved successfully'),
        );
      });
    }

    _currentStatus = newStatus;
    _lastEvent = event;
    AppLogger.info('📊 Duty Status: $currentStatus');
  }

  /// تبديل يدوي للحالة
  void manualTransition(String newStatus, {double? lat, double? lon}) {
    if (_currentStatus == 'driving' && newStatus != 'driving') {
       AppLogger.warning('Cannot manually transition from driving while moving.');
       // In a real app we check speed first. 
    }
    _transitionTo(
      newStatus: newStatus, 
      timestamp: DateTime.now(),
      latitude: lat,
      longitude: lon,
    );
  }

  /// الحصول على إحصائيات اليوم
  Map<String, double> getTodayStats() {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);

    double driving = 0, onDuty = 0, offDuty = 0, sleeper = 0;
    double totalDistance = 0;

    for (final period in _periods) {
      if (period.startTime.isAfter(todayStart)) {
        final hours = period.duration.inMinutes / 60.0;
        switch (period.status) {
          case 'driving':
            driving += hours;
            break;
          case 'on_duty':
            onDuty += hours;
            break;
          case 'off_duty':
            offDuty += hours;
            break;
          case 'sleeper_berth':
            sleeper += hours;
            break;
        }
        if (period.distanceKm != null) {
          totalDistance += period.distanceKm!;
        }
      }
    }

    return {
      'driving': driving,
      'on_duty': onDuty,
      'off_duty': offDuty,
      'sleeper': sleeper,
      'distance': totalDistance,
    };
  }

  /// الحصول على إحصائيات الأسبوع
  Map<String, double> getWeekStats() {
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));

    double driving = 0, work = 0, rest = 0;
    double totalDistance = 0;

    for (final period in _periods) {
      if (period.startTime.isAfter(weekStart)) {
        final hours = period.duration.inMinutes / 60.0;
        switch (period.status) {
          case 'driving':
            driving += hours;
            work += hours;
            break;
          case 'on_duty':
            work += hours;
            break;
          case 'off_duty':
          case 'sleeper_berth':
            rest += hours;
            break;
        }
        if (period.distanceKm != null) {
          totalDistance += period.distanceKm!;
        }
      }
    }

    return {
      'driving': driving,
      'work': work,
      'rest': rest,
      'distance': totalDistance,
    };
  }

  /// مسح البيانات
  void clear() {
    _events.clear();
    _periods.clear();
    _lastEvent = null;
    _currentStatus = 'off_duty';
  }

  void dispose() {
    _eventSubscription?.cancel();
  }
}

/// مزود متتبع الحالة
final dutyStatusTrackerProvider = Provider<DutyStatusTracker>((ref) {
  final repo = ref.watch(logRepositoryProvider);
  final tracking = ref.watch(liveTrackingDataSourceProvider);
  final tracker = DutyStatusTracker(repo, tracking);
  ref.onDispose(() {
    tracker.dispose();
  });
  return tracker;
});
