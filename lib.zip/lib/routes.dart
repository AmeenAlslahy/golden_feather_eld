import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'features/auth/presentation/pages/auth_page.dart';
import 'features/auth/presentation/pages/splash_page.dart';
import 'features/auth/presentation/providers/auth_state_provider.dart';
import 'features/home/presentation/pages/home_page.dart';
import 'features/tracking/presentation/pages/tracking_page.dart';
import 'features/tracking/presentation/pages/tracking_logs_page.dart';
// import 'features/home/presentation/widgets/eld_drawer.dart';
import 'features/connection/presentation/pages/eld_connection_page.dart';
import 'features/hos/presentation/pages/hos_page.dart';
import 'features/permissions/presentation/pages/permissions_page.dart';
import 'features/logs/presentation/pages/logs_list_page.dart';
import 'features/logs/presentation/pages/log_detail_page.dart';
import 'features/logs/presentation/pages/edit_log_page.dart';
import 'features/settings/presentation/pages/settings_page.dart';
import 'features/dvir/presentation/pages/dvir_list_page.dart';
import 'features/dvir/presentation/pages/dvir_form_page.dart';
import 'features/vehicle/presentation/pages/select_vehicle_page.dart';
import 'features/inspection/presentation/pages/dot_inspection_page.dart';
import 'features/inspection/presentation/pages/send_logs_page.dart';
import 'features/codriver/presentation/pages/codriver_page.dart';
import 'features/account/presentation/pages/account_page.dart';
import 'features/account/presentation/pages/rules_page.dart';
import 'features/account/presentation/pages/info_packet_page.dart';
import 'features/account/presentation/pages/user_manual_page.dart';
import 'features/settings/presentation/pages/developer_options_page.dart';
import 'features/reports/presentation/pages/reports_page.dart';
// import 'core/extensions/context_extensions.dart';

/// مسارات التطبيق
class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String permissions = '/permissions';
  static const String connection = '/connection';
  static const String login = '/login';
  static const String home = '/home';
  static const String status = '/status';
  static const String logs = '/logs';
  static const String logDetail = '/logs/:id';
  static const String editLog = '/logs/:id/edit';
  static const String tracking = '/tracking';
  static const String trackingLogs = '/tracking-logs';
  static const String dvir = '/dvir';
  static const String dvirForm = '/dvir/create';
  static const String inspection = '/inspection';
  static const String sendLogs = '/inspection/send';
  static const String codriver = '/codriver';
  static const String account = '/account';
  static const String rules = '/rules';
  static const String infoPacket = '/info-packet';
  static const String settings = '/settings';
  static const String hos = '/hos';
  static const String selectVehicle = '/select-vehicle';
  static const String userManual = '/user-manual';
  static const String developerOptions = '/developer-options';
  static const String reports = '/reports';
}

/// منبه (Notifier) يربط بين Riverpod و GoRouter لتحديث المسارات
class RouterNotifier extends ChangeNotifier {
  final Ref _ref;

  RouterNotifier(this._ref) {
    _ref.listen<AuthState>(
      authStateProvider,
      (_, __) => notifyListeners(),
    );
  }
}

final _rootNavigatorKey = GlobalKey<NavigatorState>();

/// تكوين GoRouter
final routerProvider = Provider<GoRouter>((ref) {
  final notifier = RouterNotifier(ref);

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppRoutes.splash,
    refreshListenable: notifier,
    redirect: (context, state) {
      final authState = ref.read(authStateProvider);
      final isLoggedIn = authState.isAuthenticated;
      final isLoginRoute = state.matchedLocation == AppRoutes.login;
      final isSplashRoute = state.matchedLocation == AppRoutes.splash;

      // السماح بمسار splash و permissions دائماً حتى نتحقق
      if (isSplashRoute || state.matchedLocation == AppRoutes.permissions) return null;

      // إذا لم يسجل الدخول، توجيه إلى صفحة الدخول
      if (!isLoggedIn && !isLoginRoute) return AppRoutes.login;

      // إذا سجل الدخول ويحاول الوصول لصفحة الدخول، توجيه لصفحة الاتصال
      if (isLoggedIn && isLoginRoute) return AppRoutes.connection;

      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        name: 'splash',
        builder: (context, state) => const SplashPage(),
      ),
      GoRoute(
        path: AppRoutes.permissions,
        name: 'permissions',
        builder: (context, state) => const PermissionsPage(),
      ),
      GoRoute(
        path: AppRoutes.login,
        name: 'login',
        builder: (context, state) => const AuthPage(),
      ),
      GoRoute(
        path: AppRoutes.connection,
        name: 'connection',
        builder: (context, state) => const EldConnectionPage(),
      ),
      GoRoute(
        path: AppRoutes.home,
        name: 'home',
        builder: (context, state) => const HomePage(),
      ),
      GoRoute(
        path: AppRoutes.status,
        name: 'status',
        builder: (context, state) => const StatusDashboard(),
      ),
      GoRoute(
        path: AppRoutes.tracking,
        name: 'tracking',
        builder: (context, state) => const TrackingPage(),
      ),
      GoRoute(
        path: AppRoutes.trackingLogs,
        name: 'trackingLogs',
        builder: (context, state) => const TrackingLogsPage(),
      ),
      GoRoute(
        path: AppRoutes.hos,
        name: 'hos',
        builder: (context, state) => const HosPage(),
      ),
      GoRoute(
        path: AppRoutes.logs,
        name: 'logs',
        builder: (context, state) => const LogsListPage(),
      ),
      GoRoute(
        path: AppRoutes.logDetail,
        name: 'logDetail',
        builder: (context, state) => const LogDetailPage(),
      ),
      GoRoute(
        path: AppRoutes.editLog,
        name: 'editLog',
        builder: (context, state) {
          final event = state.extra; // تمرير الـ event كـ extra
          return EditLogPage(event: event);
        },
      ),
      GoRoute(
        path: AppRoutes.dvir,
        name: 'dvir',
        builder: (context, state) => const DvirListPage(),
      ),
      GoRoute(
        path: AppRoutes.dvirForm,
        name: 'dvirForm',
        builder: (context, state) => const DvirFormPage(),
      ),
      GoRoute(
        path: AppRoutes.inspection,
        name: 'inspection',
        builder: (context, state) => const DotInspectionPage(),
      ),
      GoRoute(
        path: AppRoutes.sendLogs,
        name: 'sendLogs',
        builder: (context, state) => const SendLogsPage(),
      ),
      GoRoute(
        path: AppRoutes.codriver,
        name: 'codriver',
        builder: (context, state) => const CoDriverPage(),
      ),
      GoRoute(
        path: AppRoutes.account,
        name: 'account',
        builder: (context, state) => const AccountPage(),
      ),
      GoRoute(
        path: AppRoutes.rules,
        name: 'rules',
        builder: (context, state) => const RulesPage(),
      ),
      GoRoute(
        path: AppRoutes.infoPacket,
        name: 'info-packet',
        builder: (context, state) => const InfoPacketPage(),
      ),
      GoRoute(
        path: AppRoutes.settings,
        name: 'settings',
        builder: (context, state) => const SettingsPage(),
      ),
      GoRoute(
        path: AppRoutes.selectVehicle,
        name: 'selectVehicle',
        builder: (context, state) => const SelectVehiclePage(),
      ),
      GoRoute(
        path: AppRoutes.userManual,
        name: 'userManual',
        builder: (context, state) => const UserManualPage(),
      ),
      GoRoute(
        path: AppRoutes.developerOptions,
        name: 'developerOptions',
        builder: (context, state) => const DeveloperOptionsPage(),
      ),
      GoRoute(
        path: AppRoutes.reports,
        name: 'reports',
        builder: (context, state) => const ReportsPage(),
      ),
    ],
  );
});

