import 'app_error.dart';

/// Message shown to the driver. Never the exception, stack, or `toString()`.
String appErrorUserMessage(AppError error, {required bool isArabic}) {
  final server = error.context?['serverMessage'];
  if (server is String && server.trim().isNotEmpty) return server.trim();
  final nested = error.context?['message'];
  if (nested is String && nested.trim().isNotEmpty) return nested.trim();

  return switch (error) {
    NetworkError() => isArabic
        ? 'تعذر الاتصال بالخادم. تحقق من الشبكة ثم أعد المحاولة.'
        : 'Could not reach the server. Check the network and try again.',
    ValidationError() => isArabic
        ? 'الخادم رفض الطلب.'
        : 'The server rejected this request.',
    SessionExpiredError() => isArabic
        ? 'انتهت الجلسة. سجّل الدخول مرة أخرى.'
        : 'The session expired. Sign in again.',
    PermissionError() => isArabic
        ? 'ليست لديك صلاحية لهذا الإجراء.'
        : 'You are not allowed to do this.',
    NotFoundError() => isArabic
        ? 'العنصر غير موجود على الخادم.'
        : 'The server did not find this item.',
    ServerError() => isArabic
        ? 'حدث خطأ في الخادم. أعد المحاولة.'
        : 'The server returned an error. Try again.',
    _ => isArabic
        ? 'تعذر إكمال الطلب.'
        : 'The request could not be completed.',
  };
}
