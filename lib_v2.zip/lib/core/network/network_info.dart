import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

abstract class NetworkInfo {
  Stream<bool> get onConnectionChange;
  bool get isConnected;
}

class NetworkInfoImpl implements NetworkInfo {
  final Connectivity _connectivity;
  // الحالة الابتدائية "غير متصل" (صادقة) — الافتراض السابق true كان
  // يكذب على المستهلكين حتى يصل أول حدث من Connectivity.
  bool _currentStatus = false;
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  final _controller = StreamController<bool>.broadcast();

  NetworkInfoImpl() : _connectivity = Connectivity() {
    _subscription = _connectivity.onConnectivityChanged.listen((result) {
      _currentStatus = !result.contains(ConnectivityResult.none);
      _controller.add(_currentStatus);
    });
  }

  @override
  Stream<bool> get onConnectionChange => _controller.stream;

  @override
  bool get isConnected => _currentStatus;

  void dispose() {
    _subscription?.cancel();
    _controller.close();
  }
}
