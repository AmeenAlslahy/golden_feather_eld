import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/theme/app_colors.dart';
// import '../../../../core/theme/app_radius.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../routes.dart';
import '../../../home/presentation/widgets/eld_drawer.dart';
import '../providers/inspection_provider.dart';
import '../widgets/inspection_log_header_table.dart';
import 'send_logs_page.dart';

/// شاشة DOT Inspection
class DotInspectionPage extends ConsumerStatefulWidget {
  const DotInspectionPage({super.key});

  @override
  ConsumerState<DotInspectionPage> createState() => _DotInspectionPageState();
}

class _DotInspectionPageState extends ConsumerState<DotInspectionPage> {
  int _currentDayIndex = 0;

  @override
  Widget build(BuildContext context) {
    final inspectionState = ref.watch(inspectionProvider);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: !inspectionState.isInspectionMode,
        title: Text(
          context.loc.dotInspection,
          style: context.styles.appBarTitle,
        ),
        leading: inspectionState.isInspectionMode
            ? null
            : Builder(
                builder: (context) => IconButton(
                  icon: const Icon(Icons.menu, color: AppColors.surface),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                ),
              ),
      ),
      drawer: inspectionState.isInspectionMode ? null : const EldDrawer(),
      body: PopScope(
        canPop: true,
        onPopInvokedWithResult: (didPop, result) {
          if (inspectionState.isInspectionMode && didPop) {
            ref.read(inspectionProvider.notifier).endInspection();
          }
        },
        child: inspectionState.isLoading
            ? const Center(child: CircularProgressIndicator())
            : !inspectionState.isInspectionMode
                ? _buildStartInspection()
                : _buildInspectionView(inspectionState),
      ),
    );
  }

  Widget _buildStartInspection() {
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final error = ref.watch(inspectionProvider).error;
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
      children: [
        if (error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Text(error, textAlign: TextAlign.center),
          ),
        Text(
          isArabic
              ? 'افحص سجلات فترة 24 ساعة والأيام السابقة لدورة واحدة'
              : 'Inspect logs for the 24-hour period and the previous days for one HOS cycle',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, height: 1.35),
        ),
        const SizedBox(height: 8),
        Text(
          isArabic
              ? 'اختر «بدء التفتيش» وسلّم الجهاز للضابط'
              : 'Select "Start Inspection" and give your device to the officer',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14, color: Color(0xFF9E9E9E)),
        ),
        const SizedBox(height: 16),
        AppButton(
          label: isArabic ? 'بدء التفتيش' : 'START INSPECTION',
          type: EldButtonType.dark,
          onPressed: () =>
              ref.read(inspectionProvider.notifier).startInspection(),
        ),
        const SizedBox(height: 28),
        const Divider(height: 1),
        const SizedBox(height: 28),
        Text(
          isArabic
              ? 'أرسل السجلات لفترة 24 ساعة والأيام السابقة لدورة واحدة'
              : 'Send logs for the 24-hour period and the previous days for one HOS cycle',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, height: 1.35),
        ),
        const SizedBox(height: 8),
        Text(
          isArabic
              ? 'أرسل سجلاتك للضابط إذا طلب ذلك'
              : 'Send your logs to the officer if they request',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14, color: Color(0xFF9E9E9E)),
        ),
        const SizedBox(height: 16),
        AppButton(
          label: isArabic ? 'إرسال السجلات' : 'SEND LOGS',
          type: EldButtonType.dark,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SendLogsPage()),
            );
          },
        ),
        const SizedBox(height: 28),
        const Divider(height: 1),
        const SizedBox(height: 28),
        Text(
          isArabic
              ? 'أرسل السجلات بالبريد لفترة 24 ساعة والأيام السابقة كملف PDF'
              : 'Email logs for the 24-hour period and the previous days for one HOS cycle as PDF',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16, height: 1.35),
        ),
        const SizedBox(height: 8),
        Text(
          isArabic
              ? 'أرسل سجلاتك بصيغة PDF'
              : 'Email your logs in the PDF format',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14, color: Color(0xFF9E9E9E)),
        ),
        const SizedBox(height: 16),
        AppButton(
          label: isArabic ? 'بريد السجلات' : 'EMAIL LOGS',
          type: EldButtonType.dark,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const SendLogsPage(isEmailMode: true),
              ),
            );
          },
        ),
        const SizedBox(height: 28),
        const Divider(height: 1),
        const SizedBox(height: 28),
        Text(
          isArabic
              ? 'يشهد التطبيق أن استخدامه مع الجهاز يستوفي متطلبات ELD في 49 CFR part 395 Subpart B.'
              : 'This ELD certifies that use of the app with the ELD device complies with all requirements for ELD as defined in Federal Motor Carrier Safety regulation 49 CFR part 395 Subpart B.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14, height: 1.4),
        ),
        const SizedBox(height: 16),
        AppButton(
          label: isArabic ? 'حزمة المعلومات' : 'INFORMATION PACKET',
          type: EldButtonType.dark,
          onPressed: () => context.push(AppRoutes.infoPacket),
        ),
      ],
    );
  }

  /// عرض التفتيش مع السجلات
  Widget _buildInspectionView(InspectionState state) {
    final log = state.log;
    final day = _currentDayIndex >= 0 && _currentDayIndex < state.cycle.length
        ? state.cycle[_currentDayIndex]
        : null;
    return Column(
      children: [
        Container(
          color: AppColors.primaryGold.withValues(alpha: 0.05),
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left),
                onPressed: _currentDayIndex < state.cycle.length - 1
                    ? () {
                        final next = _currentDayIndex + 1;
                        setState(() => _currentDayIndex = next);
                        ref.read(inspectionProvider.notifier).loadLog(state.cycle[next].logDate);
                      }
                    : null,
              ),
              Text(
                day?.displayDate.isNotEmpty == true
                    ? day!.displayDate
                    : (log?.displayDate ?? ''),
                style: context.styles.bodyBold,
              ),
              IconButton(
                icon: const Icon(Icons.chevron_right),
                onPressed: _currentDayIndex > 0
                    ? () {
                        final next = _currentDayIndex - 1;
                        setState(() => _currentDayIndex = next);
                        ref.read(inspectionProvider.notifier).loadLog(state.cycle[next].logDate);
                      }
                    : null,
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: log == null
              ? Center(child: Text(state.error ?? context.loc.noData))
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      InspectionLogHeaderTable(log: log, day: day),
                      const SizedBox(height: AppSpacing.lg),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: AppButton(
                          label: context.loc.endInspection.toUpperCase(),
                          type: EldButtonType.danger,
                          onPressed: () => ref
                              .read(inspectionProvider.notifier)
                              .endInspection(),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.lg),
                    ],
                  ),
                ),
        ),
      ],
    );
  }

}
