import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../backend/contracts/inspection_backend.dart';
import '../../../../backend/providers/backend_providers.dart';
import '../../../../core/error/app_error.dart';
import '../../../../core/error/user_facing_message.dart';
import '../../../../core/network/core_providers.dart';
import '../../../../domain/inspection/dot_inspection.dart';
import '../../../../domain/shared/value_objects.dart';
import '../../../auth/presentation/providers/auth_state_provider.dart';
import '../../data/repositories/inspection_repository_impl.dart';
import '../../domain/entities/inspection_data.dart';
import '../../domain/inspection_transfer.dart';
import '../../domain/repositories/inspection_repository.dart';

// --- Dependency Injection Providers ---

final inspectionBackendProviderAlias = Provider<InspectionBackend>((ref) {
  return ref.watch(inspectionBackendProvider);
});

final inspectionRepositoryProvider = Provider<InspectionRepository>((ref) {
  return InspectionRepositoryImpl(
    inspectionBackend: ref.watch(inspectionBackendProviderAlias),
    networkInfo: ref.watch(networkInfoProvider),
  );
});

// --- State and Notifier ---

/// حالة التفتيش
class InspectionState {
  final bool isInspectionMode;
  final bool isPinLocked;
  final String? pinCode;
  final List<InspectionDayData> days;
  final List<DotInspectionCycleDay> cycle;
  final DotInspectionLog? log;
  final bool isLoading;
  final String? error;
  final String? transferMessage;

  const InspectionState({
    this.isInspectionMode = false,
    this.isPinLocked = false,
    this.pinCode,
    this.days = const [],
    this.cycle = const [],
    this.log,
    this.isLoading = false,
    this.error,
    this.transferMessage,
  });

  InspectionState copyWith({
    bool? isInspectionMode,
    bool? isPinLocked,
    String? pinCode,
    List<InspectionDayData>? days,
    List<DotInspectionCycleDay>? cycle,
    DotInspectionLog? log,
    bool clearLog = false,
    bool? isLoading,
    String? error,
    String? transferMessage,
    bool clearTransferMessage = false,
  }) {
    return InspectionState(
      isInspectionMode: isInspectionMode ?? this.isInspectionMode,
      isPinLocked: isPinLocked ?? this.isPinLocked,
      pinCode: pinCode ?? this.pinCode,
      days: days ?? this.days,
      cycle: cycle ?? this.cycle,
      log: clearLog ? log : (log ?? this.log),
      isLoading: isLoading ?? this.isLoading,
      error: error,
      transferMessage:
          clearTransferMessage ? transferMessage : (transferMessage ?? this.transferMessage),
    );
  }
}

/// مزود التفتيش
final inspectionProvider =
    StateNotifierProvider<InspectionNotifier, InspectionState>((ref) {
  return InspectionNotifier(
    backend: ref.watch(inspectionBackendProvider),
    driverId: ref.watch(currentDriverIdProvider) ?? 0,
  );
});

final informationPacketProvider =
    FutureProvider.autoDispose<InformationPacketView>((ref) async {
  final driverId = ref.watch(currentDriverIdProvider);
  final result = await ref.watch(inspectionBackendProvider).getInformationPacket(
        driverId: driverId == null || driverId <= 0 ? null : DriverId(driverId),
      );
  return result.fold((error) => throw error, parseInformationPacket);
});

class InspectionNotifier extends StateNotifier<InspectionState> {
  final InspectionBackend _backend;
  final int _driverId;

  InspectionNotifier({
    required InspectionBackend backend,
    required int driverId,
  })  : _backend = backend,
        _driverId = driverId,
        super(const InspectionState());

  String _message(AppError error) {
    return appErrorUserMessage(error, isArabic: false);
  }

  /// بدء وضع التفتيش
  Future<void> startInspection() async {
    state = state.copyWith(isLoading: true, error: null, clearLog: true);

    if (_driverId <= 0) {
      state = state.copyWith(
        isLoading: false,
        error: 'Driver session is missing. Sign in again before inspection.',
      );
      return;
    }

    final driver = DriverId(_driverId);
    final started = await _backend.startInspection(driverId: driver);
    if (!mounted) return;
    final startError = started.fold(_message, (_) => null);
    if (startError != null) {
      state = state.copyWith(
        isLoading: false,
        isInspectionMode: false,
        error: startError,
      );
      return;
    }

    final cycleResult = await _backend.getCycle(driverId: driver, days: 8);
    if (!mounted) return;
    final cycle = cycleResult.fold((_) => const <DotInspectionCycleDay>[], (days) => days);
    final logResult = cycle.isEmpty
        ? await _backend.getLogs(driverId: driver)
        : await _backend.getLogs(driverId: driver, date: cycle.first.logDate);
    if (!mounted) return;
    logResult.fold(
      (error) => state = state.copyWith(
        isLoading: false,
        isInspectionMode: true,
        cycle: cycle,
        clearLog: true,
        error: _message(error),
      ),
      (log) => state = state.copyWith(
        isLoading: false,
        isInspectionMode: true,
        cycle: cycle,
        log: log,
        error: null,
      ),
    );
  }

  Future<void> loadLog(DateTime date) async {
    if (_driverId <= 0) return;
    state = state.copyWith(isLoading: true, error: null);
    final result = await _backend.getLogs(
      driverId: DriverId(_driverId),
      date: date,
    );
    if (!mounted) return;
    result.fold(
      (error) => state = state.copyWith(
        isLoading: false,
        clearLog: true,
        error: _message(error),
      ),
      (log) => state = state.copyWith(isLoading: false, log: log, error: null),
    );
  }

  /// تعيين رمز PIN
  void setPinCode(String pin) {
    state = state.copyWith(pinCode: pin);
  }

  /// فتح القفل
  bool unlock(String pin) {
    if (pin == state.pinCode) {
      state = state.copyWith(isPinLocked: false);
      return true;
    }
    return false;
  }

  /// قفل الشاشة
  void lock() {
    state = state.copyWith(isPinLocked: true);
  }

  /// إنهاء التفتيش
  void endInspection() {
    state = const InspectionState();
  }

  /// إرسال السجلات
  Future<bool> sendLogs(
    TransferMethod method, {
    String? email,
    String? routingCode,
    required String comment,
  }) async {
    final commentError = inspectionCommentError(comment);
    if (commentError != null) {
      state = state.copyWith(isLoading: false, error: commentError, clearTransferMessage: true);
      return false;
    }
    if (_driverId <= 0) {
      state = state.copyWith(
        isLoading: false,
        error: 'Driver session is missing. Sign in again before sending logs.',
        clearTransferMessage: true,
      );
      return false;
    }

    state = state.copyWith(isLoading: true, error: null, clearTransferMessage: true);
    final driver = DriverId(_driverId);
    final note = comment.trim();
    final route = routingCode?.trim();
    final recipient = email?.trim() ?? '';
    final result = method == TransferMethod.email && recipient.isNotEmpty
        ? await _backend.emailLogs(
            driverId: driver,
            recipientEmail: recipient,
            comment: note,
            routingCode: route == null || route.isEmpty ? null : route,
          )
        : await _backend.sendLogs(
            driverId: driver,
            transferType: transferTypeFor(method),
            outputFileComment: note,
            routingCode: route == null || route.isEmpty ? null : route,
            recipientEmail: (email == null || email.trim().isEmpty) ? null : email.trim(),
          );
    if (!mounted) return false;
    return result.fold(
      (error) {
        state = state.copyWith(isLoading: false, error: _message(error));
        return false;
      },
      (json) {
        final outcome = readTransferOutcome(json);
        state = state.copyWith(
          isLoading: false,
          error: outcome.accepted ? null : outcome.text,
          transferMessage: outcome.accepted ? outcome.text : null,
        );
        return outcome.accepted;
      },
    );
  }
}
