import 'package:fpdart/fpdart.dart';

import '../../../../backend/contracts/contract_enums.dart';
import '../../../../backend/contracts/driver_session_backend.dart';
import '../../../../core/error/failure.dart';
import '../../../../core/network/network_info.dart';
import '../../../../domain/shared/value_objects.dart';
import '../../domain/current_codriver.dart';
import '../../domain/entities/codriver.dart';
import '../../domain/repositories/codriver_repository.dart';

class CoDriverRepositoryImpl implements CoDriverRepository {
  final DriverSessionBackend driverSessionBackend;
  final NetworkInfo networkInfo;

  CoDriverRepositoryImpl({
    required this.driverSessionBackend,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<CoDriver>>> getAvailableDrivers() async {
    if (networkInfo.isConnected) {
      try {
        final result = await driverSessionBackend.getAvailableDrivers();
        return result.fold(
          (error) => Left(ServerFailure(message: error.code)),
          (rawDrivers) {
            final drivers = rawDrivers
            .map((json) => CoDriver(
                  id: json['id']?.toString() ?? '',
                  name: json['name'] ?? 'Unknown',
                  licenseNumber: json['attributes']?['licenseNumber'],
                ))
            .toList();

            return Right(drivers);
          }
        );
      } catch (e) {
        return const Left(ServerFailure(message: 'Unexpected error occurred'));
      }
    } else {
      return const Left(NetworkFailure());
    }
  }

  @override
  Future<Either<Failure, CurrentCoDriverRead>> getCurrentCoDriver() async {
    if (!networkInfo.isConnected) return const Left(NetworkFailure());
    try {
      final result = await driverSessionBackend.getCurrentCoDriver();
      return result.fold(
        (error) => Left(ServerFailure(message: error.code)),
        (json) {
          final read = parseCurrentCoDriver(json);
          if (read == null) {
            return const Left(
              ServerFailure(message: 'co_driver_response_unreadable'),
            );
          }
          return Right(read);
        },
      );
    } catch (_) {
      return const Left(ServerFailure(message: 'Unexpected error occurred'));
    }
  }

  @override
  Future<Either<Failure, bool>> switchPrimary({required int coDriverId}) async {
    if (!networkInfo.isConnected) return const Left(NetworkFailure());
    if (coDriverId <= 0) {
      return const Left(ServerFailure(message: 'Select a co-driver before switching.'));
    }
    final result = await driverSessionBackend.switchPrimaryDriver(
      action: DutyStatusAction.switchPrimary,
      coDriverId: DriverId(coDriverId),
    );
    return result.fold(
      (error) => Left(ServerFailure(message: error.code)),
      (_) => const Right(true),
    );
  }
}
