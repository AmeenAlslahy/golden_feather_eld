import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:signature/signature.dart';

import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/time/trusted_time_provider.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../account/presentation/providers/account_provider.dart';
import '../../../auth/presentation/providers/auth_state_provider.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import '../../../tracking/presentation/providers/tracking_provider.dart';
import '../../domain/dvir_submission.dart';
import '../../domain/entities/dvir_report.dart';
import '../providers/dvir_provider.dart';

class DvirFormPage extends ConsumerStatefulWidget {
  final DvirReport? existingReport;

  const DvirFormPage({super.key, this.existingReport});

  @override
  ConsumerState<DvirFormPage> createState() => _DvirFormPageState();
}

class _DvirFormPageState extends ConsumerState<DvirFormPage> {
  final _formKey = GlobalKey<FormState>();

  // Controllers for the new flat layout
  late TextEditingController _locationController;
  late TextEditingController _odometerController;
  late TextEditingController _vehicleDefectsController;
  late TextEditingController _trailerDefectsController;
  late TextEditingController _companyController;
  late TextEditingController _remarksController;

  final SignatureController _signatureController = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );

  bool _isSubmitting = false;

  String _selectedStatus = 'Vehicle Condition Satisfactory';
  bool _signed = false;

  @override
  void initState() {
    super.initState();
    final r = widget.existingReport;
    _locationController = TextEditingController(text: r?.location ?? '');
    _odometerController =
        TextEditingController(text: r?.odometer?.toString() ?? '');
    _vehicleDefectsController =
        TextEditingController(text: r?.vehicleDefects ?? '');
    _trailerDefectsController =
        TextEditingController(text: r?.trailerDefects ?? '');
    _companyController = TextEditingController(text: r?.companyName ?? '');
    _remarksController = TextEditingController(text: r?.notes ?? '');
    if (r != null) {
      _selectedStatus = r.condition == VehicleCondition.safe
          ? 'Vehicle Condition Satisfactory'
          : 'Has Defects';
      _signed = r.signature != null;
    }
  }

  @override
  void dispose() {
    _locationController.dispose();
    _odometerController.dispose();
    _vehicleDefectsController.dispose();
    _trailerDefectsController.dispose();
    _companyController.dispose();
    _remarksController.dispose();
    _signatureController.dispose();
    super.dispose();
  }

  Future<void> _openStatusModal() async {
    final hasDefect = _vehicleDefectsController.text.trim().isNotEmpty ||
        _trailerDefectsController.text.trim().isNotEmpty;
    final selected = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: const Text('Vehicle Condition Satisfactory'),
              enabled: !hasDefect,
              subtitle: hasDefect ? const Text('— a defect is recorded') : null,
              onTap: hasDefect
                  ? null
                  : () => Navigator.pop(
                      context, 'Vehicle Condition Satisfactory'),
            ),
            ListTile(
              title: const Text('Has Defects'),
              onTap: () => Navigator.pop(context, 'Has Defects'),
            ),
            const ListTile(
              enabled: false,
              title: Text('Defects Corrected'),
              subtitle: Text('No repair certification yet'),
            ),
            const ListTile(
              enabled: false,
              title: Text('Defects Need Not Be Corrected'),
              subtitle: Text('Set by the carrier, not the driver'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _selectedStatus),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    if (selected == null || !mounted) return;
    setState(() => _selectedStatus = selected);
  }

  String _automaticLocation() {
    final existing = widget.existingReport?.location;
    final point = ref.read(trackingStateProvider).currentLocation;
    if (point != null) {
      return '${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}';
    }
    if (existing != null && existing.isNotEmpty) return existing;
    return 'Location unavailable';
  }

  String _companyName() {
    final existing = widget.existingReport?.companyName;
    if (existing != null && existing.isNotEmpty) return existing;
    return ref.read(accountProvider).accountData?.carrier ??
        'Company unavailable';
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;
    final time = ref.read(trustedTimeProvider).currentTime;
    if (time is! TrustedTimeAvailable) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Inspection time is unavailable. Connect and try again.'),
        ),
      );
      return;
    }

    final dashboard = ref.read(dashboardDataProvider);
    final previous = ref
        .read(dvirProvider)
        .reports
        .where((report) => report.vehicleId == dashboard.vehicleId)
        .toList();

    if (widget.existingReport != null) {
      _snack('A saved report cannot be edited on this device.');
      return;
    }

    final signatureData = dvirSignatureData(await _signatureController.toPngBytes());
    if (!mounted) return;
    if (signatureData == null) {
      _snack('A signature is required.');
      return;
    }
    final driverId = ref.read(currentDriverIdProvider);
    if (driverId == null || driverId <= 0) {
      _snack('Driver session is missing. Sign in again before signing the report.');
      return;
    }
    if (dashboard.vehicleId.trim().isEmpty || dashboard.vehicleId == 'No Vehicle') {
      _snack('Vehicle id is missing. Select a vehicle before signing.');
      return;
    }

    if (previous.isNotEmpty && previous.first.nextDriverReviewed != true) {
      final latest = previous.first;
      final previousId = int.tryParse(latest.id);
      if (previousId == null) {
        _snack('The previous report has no server id and cannot be reviewed.');
        return;
      }
      final reviewed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Previous inspection'),
          content: Text(
            'Review and sign the previous report before driving.\n'
            '${latest.date.toLocal()} — ${latest.condition.englishName}',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(MaterialLocalizations.of(context).cancelButtonLabel),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Reviewed'),
            ),
          ],
        ),
      );
      if (reviewed != true || !mounted) return;
      final reviewError = await ref.read(dvirProvider.notifier).reviewDvir(
            dvirId: '$previousId',
            reviewingDriverId: driverId,
            reviewingDriverName: dashboard.driverName,
            signatureData: signatureData,
            driverAgreed: true,
          );
      if (!mounted) return;
      if (reviewError != null) {
        _snack(reviewError);
        return;
      }
    }

    setState(() => _isSubmitting = true);
    final hasDefects = _vehicleDefectsController.text.trim().isNotEmpty ||
        _trailerDefectsController.text.trim().isNotEmpty;
    final report = DvirReport(
      id: '',
      type: InspectionType.preTrip,
      date: time.utc,
      driverName: dashboard.driverName,
      vehicleId: dashboard.vehicleId,
      trailerId: dashboard.trailerId,
      odometer: double.tryParse(_odometerController.text),
      items: const [],
      notes: _remarksController.text.isNotEmpty ? _remarksController.text : null,
      signature: signatureData,
      condition: hasDefects || _selectedStatus == 'Has Defects'
          ? VehicleCondition.needsRepair
          : VehicleCondition.safe,
      isSubmitted: false,
      location: _automaticLocation(),
      companyName: _companyName(),
      vehicleDefects: _vehicleDefectsController.text,
      trailerDefects: _trailerDefectsController.text,
      hasDefects: hasDefects || _selectedStatus == 'Has Defects',
    );
    final saved = await ref.read(dvirProvider.notifier).createReport(
          report,
          driverId: driverId,
          status: _selectedStatus,
        );
    if (!mounted) return;
    setState(() => _isSubmitting = false);
    if (!saved) {
      _snack(ref.read(dvirProvider).error ?? 'The server did not accept the report.');
      return;
    }
    setState(() => _signed = true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(context.loc.reportSavedSuccess),
        backgroundColor: AppColors.successGreen,
      ),
    );
    Navigator.pop(context);
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final dashboard = ref.watch(dashboardDataProvider);
    final account = ref.watch(accountProvider).accountData;
    final location = ref.watch(trackingStateProvider).currentLocation;
    final trusted = ref.watch(trustedTimeProvider).currentTime;
    final timeAvailable = trusted is TrustedTimeAvailable;
    final automaticLocation = location == null
        ? (widget.existingReport?.location ?? 'Location unavailable')
        : '${location.latitude.toStringAsFixed(5)}, ${location.longitude.toStringAsFixed(5)}';
    final companyName = widget.existingReport?.companyName ??
        account?.carrier ??
        'Company unavailable';
    final brightness = Theme.of(context).brightness;
    final surfaceColor = AppColors.surfaceFor(brightness);
    final textColor = AppColors.textPrimaryFor(brightness);
    final borderColor = AppColors.borderFor(brightness);

    final String currentTime = timeAvailable
        ? DateFormat('d MMM yy, hh:mm a').format(trusted.utc.toLocal())
        : 'Time unavailable';

    return Scaffold(
      backgroundColor: surfaceColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.surface),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Insert DVIR',
          style: context.styles.appBarTitle,
        ),
        centerTitle: true,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            if (ref.watch(dvirProvider).reports.any((report) =>
                report.vehicleId == dashboard.vehicleId &&
                report.id != widget.existingReport?.id))
              Container(
                width: double.infinity,
                color: AppColors.warningYellow.withValues(alpha: 0.2),
                padding: const EdgeInsets.all(AppSpacing.md),
                child: const Text(
                  'Previous DVIR Review — §396.13. Opening the report is not a review.',
                ),
              ),
            _buildFieldGroup(
              title: 'Time',
              child: Text(currentTime,
                  style: TextStyle(color: textColor, fontSize: 14)),
              borderColor: borderColor,
              textColor: textColor,
            ),
            _buildFieldGroup(
              title: 'Location',
              child: Text(automaticLocation,
                  style: TextStyle(color: textColor, fontSize: 14)),
              borderColor: borderColor,
              textColor: textColor,
            ),
            _buildFieldGroup(
              title: 'Odometer (mi)',
              child: _buildFlatTextField(
                  _odometerController, 'Odometer', textColor,
                  keyboardType: TextInputType.number),
              borderColor: borderColor,
              textColor: textColor,
            ),

            // Grid for Vehicle and Trailers
            Container(
              decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: borderColor))),
              padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.md, vertical: AppSpacing.sm),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.loc.vehicle,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: textColor)),
                        const SizedBox(height: 4),
                        Text(dashboard.vehicleDisplayName,
                            style: TextStyle(color: textColor, fontSize: 14)),
                        const SizedBox(height: AppSpacing.md),
                        Text(context.loc.trailers,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: textColor)),
                        const SizedBox(height: 4),
                        Text(dashboard.trailerId ?? context.loc.trailers,
                            style: TextStyle(
                                color: AppColors.textSecondaryFor(
                                    brightness),
                                fontSize: 14)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.loc.defectsTitle,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: textColor)),
                        _buildFlatTextField(_vehicleDefectsController,
                            context.loc.defectsTitle, textColor),
                        const SizedBox(height: AppSpacing.sm),
                        Text(context.loc.defectsTitle,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: textColor)),
                        _buildFlatTextField(_trailerDefectsController,
                            context.loc.defectsTitle, textColor),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            _buildFieldGroup(
              title: 'Company',
              child: Text(companyName,
                  style: TextStyle(color: textColor, fontSize: 14)),
              borderColor: borderColor,
              textColor: textColor,
            ),
            _buildFieldGroup(
              title: 'Remarks',
              child:
                  _buildFlatTextField(_remarksController, 'Remarks', textColor),
              borderColor: borderColor,
              textColor: textColor,
            ),
            _buildFieldGroup(
              title: 'Status',
              child: InkWell(
                onTap: _openStatusModal,
                child: Row(
                  children: [
                    Expanded(
                      child: Text(_selectedStatus,
                          style: TextStyle(color: textColor, fontSize: 14)),
                    ),
                    Icon(Icons.arrow_drop_down, color: textColor),
                  ],
                ),
              ),
              borderColor: borderColor,
              textColor: textColor,
            ),

            // Signature Section
            Padding(
              padding: const EdgeInsets.all(AppSpacing.xl),
              child: Column(
                children: [
                  Container(
                    height: 200,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border:
                          Border.all(color: borderColor.withValues(alpha: 0.5)),
                      color: Colors
                          .white, // Ensure signature pad is visible against white
                    ),
                    child: Stack(
                      children: [
                        Center(
                          child: Text(
                            'Image not available.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey.shade300,
                            ),
                          ),
                        ),
                        Signature(
                          controller: _signatureController,
                          backgroundColor: Colors.transparent,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  InkWell(
                    onTap: () => _signatureController.clear(),
                    child: const Text(
                      'Clear signature',
                      style: TextStyle(
                        fontSize: 14,
                        decoration: TextDecoration.underline,
                        decorationStyle: TextDecorationStyle.dotted,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.lg, vertical: AppSpacing.sm),
              child: AppButton(
                label: _signed ? 'SIGNED' : 'SIGN',
                type: EldButtonType.agree,
                isLoading: _isSubmitting,
                onPressed: _isSubmitting || !timeAvailable || _signed
                    ? null
                    : _handleSubmit,
              ),
            ),
            const SizedBox(height: 32.0),
          ],
        ),
      ),
    );
  }

  Widget _buildFieldGroup({
    required String title,
    required Widget child,
    required Color borderColor,
    required Color textColor,
  }) {
    return Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: borderColor)),
      ),
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 4),
          child,
        ],
      ),
    );
  }

  Widget _buildFlatTextField(
      TextEditingController controller, String hint, Color textColor,
      {TextInputType keyboardType = TextInputType.text}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      style: TextStyle(color: textColor, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
        border: InputBorder.none,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(vertical: 4),
      ),
    );
  }

}
