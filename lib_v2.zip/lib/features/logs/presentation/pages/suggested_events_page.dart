import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../providers/suggested_events_provider.dart';

class SuggestedEventsPage extends ConsumerStatefulWidget {
  const SuggestedEventsPage({super.key});

  @override
  ConsumerState<SuggestedEventsPage> createState() =>
      _SuggestedEventsPageState();
}

class _SuggestedEventsPageState extends ConsumerState<SuggestedEventsPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(suggestedEventsProvider.notifier).load();
    });
  }

  Future<void> _respond(int id, bool accept) async {
    final controller = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(accept ? 'Accept suggestion' : 'Reject suggestion'),
        content: TextField(
          controller: controller,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Annotation is required before the log can change',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(MaterialLocalizations.of(context).cancelButtonLabel),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: Text(MaterialLocalizations.of(context).okButtonLabel),
          ),
        ],
      ),
    );
    controller.dispose();
    if (text == null || !mounted) return;
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An annotation is required.')),
      );
      return;
    }
    final error = await ref.read(suggestedEventsProvider.notifier).respond(
          id: id,
          accept: accept,
          annotation: text,
        );
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    await ref.read(suggestedEventsProvider.notifier).load();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(suggestedEventsProvider);
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          context.loc.suggestedEvents,
          style: context.styles.appBarTitle,
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.surface),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: AppColors.surface),
            onPressed: () => ref.read(suggestedEventsProvider.notifier).load(),
          ),
        ],
      ),
      body: state.loading
          ? const Center(child: CircularProgressIndicator())
          : state.items.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    child: Text(
                      state.error ?? context.loc.noRecords,
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(AppSpacing.md),
                  itemCount: state.items.length,
                  separatorBuilder: (_, __) =>
                      const SizedBox(height: AppSpacing.sm),
                  itemBuilder: (context, index) {
                    final item = state.items[index];
                    final id = int.tryParse('${item['id']}');
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(AppSpacing.md),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${item['proposedStatus'] ?? item['dutyStatus'] ?? 'Suggested edit'}',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text('${item['startTime'] ?? item['timestamp'] ?? ''}'),
                            if (item['annotation'] != null)
                              Text('${item['annotation']}'),
                            if (id != null)
                              Row(
                                children: [
                                  TextButton(
                                    onPressed: () => _respond(id, true),
                                    child: const Text('Accept'),
                                  ),
                                  TextButton(
                                    onPressed: () => _respond(id, false),
                                    child: const Text('Reject'),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
