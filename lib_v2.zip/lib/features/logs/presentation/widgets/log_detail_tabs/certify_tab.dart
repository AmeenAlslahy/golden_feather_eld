import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:signature/signature.dart';

import '../../../../../core/extensions/context_extensions.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_spacing.dart';
import '../../../../../core/widgets/app_button.dart';
import '../../../../../domain/shared/value_objects.dart';
import '../../../../auth/presentation/providers/auth_state_provider.dart';
import '../../../domain/entities/daily_log.dart';
import '../../providers/certify_log_provider.dart';
import '../../providers/logs_provider.dart';

class CertifyTab extends ConsumerStatefulWidget {
  final DailyLog selectedLog;

  const CertifyTab({super.key, required this.selectedLog});

  @override
  ConsumerState<CertifyTab> createState() => _CertifyTabState();
}

class _CertifyTabState extends ConsumerState<CertifyTab> {
  late SignatureController _signatureController;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(certifyLogProvider.notifier).checkReadiness(widget.selectedLog.id);
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _signatureController = SignatureController(
      penStrokeWidth: 3,
      penColor: Theme.of(context).colorScheme.primary,
      exportBackgroundColor: Theme.of(context).colorScheme.surface,
    );
  }

  @override
  void dispose() {
    _signatureController.dispose();
    super.dispose();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppColors.dangerRed),
    );
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppColors.successGreen),
    );
  }

  String _formatDate(DateTime date) {
    return DateFormat('yyyy-MM-dd').format(date);
  }

  Future<void> _onAgree() async {
    final signatureBytes = await _signatureController.toPngBytes();
    if (signatureBytes == null || signatureBytes.isEmpty) {
      _showError('Please draw a signature first.');
      return;
    }

    final driverId = ref.read(authStateProvider).user?.id;
    if (driverId == null || driverId.isEmpty) {
      _showError('Session missing. Please log in again.');
      return;
    }

    final logId = widget.selectedLog.id;
    
    await ref.read(certifyLogProvider.notifier).saveAndCertify(
      logId: logId,
      driverId: DriverId(int.parse(driverId)),
      logDate: _formatDate(widget.selectedLog.date),
      signatureBytes: signatureBytes,
    );
    
    if (!mounted) return;
    
    final certifyState = ref.read(certifyLogProvider);
    if (certifyState.isSuccess) {
      _showSuccess('Log successfully certified.');
      ref.read(logsProvider.notifier).loadLogs(refresh: true);
      if (mounted) Navigator.of(context).pop();
    } else if (certifyState.error != null) {
      _showError(certifyState.error!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(certifyLogProvider);

    if (state.isLoading && state.readinessData == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(AppSpacing.xl),
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (state.error != null && state.readinessData == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 48, color: AppColors.dangerRed),
            const SizedBox(height: AppSpacing.md),
            Text(state.error!, textAlign: TextAlign.center, style: context.styles.error),
            const SizedBox(height: AppSpacing.lg),
            AppButton(
              label: 'RETRY',
              onPressed: () => ref.read(certifyLogProvider.notifier).checkReadiness(widget.selectedLog.id),
            )
          ],
        ),
      );
    }

    final readinessData = state.readinessData;
    if (readinessData == null) {
      return const SizedBox.shrink();
    }

    if (!state.isReady) {
      return SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.warning_amber_rounded, size: 64, color: AppColors.warningYellow),
            const SizedBox(height: AppSpacing.md),
            Text(
              'Not Ready for Certification',
              textAlign: TextAlign.center,
              style: context.styles.pageTitle,
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              'Please resolve the following issues before certifying your log:',
              style: context.styles.body,
            ),
            const SizedBox(height: AppSpacing.md),
            ...readinessData.missingRequirements.map((req) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Row(
                children: [
                  const Icon(Icons.circle, size: 8, color: AppColors.dangerRed),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(child: Text(req, style: context.styles.body)),
                ],
              ),
            )),
            const SizedBox(height: AppSpacing.xl),
            AppButton(
              label: 'NOT READY',
              type: EldButtonType.send,
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        children: [
          Container(
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.border, width: 1),
              color: Colors.white,
            ),
            child: Stack(
              children: [
                const Center(
                  child: Text(
                    'Image not available.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFFD0D0D0),
                    ),
                  ),
                ),
                Signature(
                  controller: _signatureController,
                  height: 200,
                  backgroundColor: AppColors.transparent,
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          InkWell(
            onTap: () => _signatureController.clear(),
            child: const Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'Clear signature',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                  decorationStyle: TextDecorationStyle.dotted,
                ),
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xl),
          Text(
            readinessData.legalStatement.trim().isEmpty
                ? 'I hereby certify that my data entries and my record of duty status for this 24-hour period are true and correct.'
                : readinessData.legalStatement,
            textAlign: TextAlign.center,
            style: context.styles.body.copyWith(height: 1.5, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: AppSpacing.md),
          if (!widget.selectedLog.isFormComplete)
            Padding(
              padding: const EdgeInsets.only(bottom: AppSpacing.md),
              child: Text(
                context.loc.fillFormFirst,
                textAlign: TextAlign.center,
                style: context.styles.error,
              ),
            ),
          AppButton(
            label: 'NOT READY',
            type: EldButtonType.muted,
            onPressed: () {},
          ),
          const SizedBox(height: AppSpacing.md),
          ListenableBuilder(
            listenable: _signatureController,
            builder: (context, _) {
              return AppButton(
                label: context.loc.agree.toUpperCase(),
                type: EldButtonType.agree,
                isLoading: state.isLoading,
                onPressed: () {
                  if (state.isLoading) return;
                  if (_signatureController.isEmpty ||
                      !widget.selectedLog.isFormComplete) {
                    _showError(context.loc.fillFormFirst);
                    return;
                  }
                  _onAgree();
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
