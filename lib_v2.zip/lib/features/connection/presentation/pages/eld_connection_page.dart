import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../backend/providers/backend_providers.dart';
import '../../../../core/extensions/context_extensions.dart';
import '../../../../core/network/core_providers.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';

import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../routes.dart';
import '../../../home/presentation/providers/dashboard_provider.dart';
import '../../../vehicle/presentation/providers/vehicle_provider.dart';
import '../providers/hardware_status_provider.dart';

class EldConnectionState {
  final bool isConnecting;
  final bool hasFailed;
  final String? errorMessage;
  final String? infoMessage;

  EldConnectionState({
    this.isConnecting = false,
    this.hasFailed = false,
    this.errorMessage,
    this.infoMessage,
  });

  EldConnectionState copyWith({
    bool? isConnecting,
    bool? hasFailed,
    String? errorMessage,
    String? infoMessage,
  }) {
    return EldConnectionState(
      isConnecting: isConnecting ?? this.isConnecting,
      hasFailed: hasFailed ?? this.hasFailed,
      errorMessage: errorMessage,
      infoMessage: infoMessage,
    );
  }
}

class EldConnectionNotifier extends StateNotifier<EldConnectionState> {
  final Ref _ref;

  EldConnectionNotifier(this._ref) : super(EldConnectionState());

  Future<void> attemptConnection(String macAddress) async {
    state = state.copyWith(isConnecting: true, hasFailed: false, errorMessage: null);

    try {
      final bluetoothService = _ref.read(bluetoothServiceProvider);
      
      // 1. الاتصال المحلي بالبلوتوث
      try {
        await bluetoothService.connect(macAddress);
      } catch (e) {
        if (mounted) {
          state = state.copyWith(
            isConnecting: false,
            hasFailed: true,
            errorMessage: 'فشل الاتصال عبر البلوتوث: ${e.toString()}',
          );
        }
        return;
      }

      // 2. التحقق من السيرفر وبدء الجلسة
      final hardwareBackend = _ref.read(hardwareBackendProvider);
      
      final selectedUniqueId =
          _ref.read(vehicleProvider).selectedVehicle?.uniqueId;
      final result = await hardwareBackend.connectSession(
        uniqueId: selectedUniqueId,
      );

      if (mounted) {
        result.fold(
          (error) {
            state = state.copyWith(
              isConnecting: false,
              hasFailed: true,
              errorMessage: error.l10nKey,
            );
          },
          (data) {
            state = state.copyWith(
              isConnecting: false,
              hasFailed: false,
            );
          },
        );
      }
    } catch (e) {
      if (mounted) {
        state = state.copyWith(
          isConnecting: false,
          hasFailed: true,
          errorMessage: e.toString(),
        );
      }
    }
  }

  /// `POST /eld/hardware/connect?disconnected=true`. No reason form and no duty event.
  Future<void> continueDisconnected() async {
    state = state.copyWith(
      isConnecting: true,
      hasFailed: false,
      errorMessage: null,
      infoMessage: null,
    );
    try {
      final uniqueId = _ref.read(vehicleProvider).selectedVehicle?.uniqueId;
      final result = await _ref.read(hardwareBackendProvider).connectSession(
            uniqueId: uniqueId,
            disconnected: true,
          );
      if (!mounted) return;
      result.fold(
        (error) {
          final message = error.context?['serverMessage']?.toString().trim();
          state = state.copyWith(
            isConnecting: false,
            hasFailed: true,
            errorMessage: message == null || message.isEmpty ? error.code : message,
          );
        },
        (_) => state = state.copyWith(
          isConnecting: false,
          hasFailed: false,
          infoMessage: 'disconnected_accepted',
        ),
      );
    } catch (e) {
      if (mounted) {
        state = state.copyWith(
          isConnecting: false,
          hasFailed: true,
          errorMessage: e.toString(),
        );
      }
    }
  }
}

final eldConnectionProvider = StateNotifierProvider.autoDispose<
    EldConnectionNotifier, EldConnectionState>((ref) {
  return EldConnectionNotifier(ref);
});

class EldConnectionPage extends ConsumerStatefulWidget {
  const EldConnectionPage({super.key});

  @override
  ConsumerState<EldConnectionPage> createState() => _EldConnectionPageState();
}

class _EldConnectionPageState extends ConsumerState<EldConnectionPage> {
  final TextEditingController _macController = TextEditingController();

  @override
  void dispose() {
    _macController.dispose();
    super.dispose();
  }

  Future<void> _attemptConnection() async {
    final notifier = ref.read(eldConnectionProvider.notifier);
    await notifier.attemptConnection(_macController.text);
  }

  @override
  Widget build(BuildContext context) {
    final dashboard = ref.watch(dashboardDataProvider);
    final connectionState = ref.watch(eldConnectionProvider);

    // الانتقال للرئيسية عند النجاح
    ref.listen<EldConnectionState>(eldConnectionProvider, (previous, current) {
      if (previous != null &&
          previous.isConnecting &&
          !current.isConnecting &&
          !current.hasFailed) {
        if (current.infoMessage == 'disconnected_accepted') {
          final isArabic = Localizations.localeOf(context).languageCode == 'ar';
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                isArabic
                    ? 'قبل الخادم المتابعة دون اتصال. لم يُنشأ حدث واجب محلي.'
                    : 'The server accepted disconnected mode. No local duty event was created.',
              ),
            ),
          );
        }
        context.go(AppRoutes.home);
      } else if (previous != null &&
          previous.isConnecting &&
          !current.isConnecting) {
        ref.invalidate(hardwareStatusProvider);
      }
    });

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.compare_arrows,
              color: AppColors.surface, size: 28),
          onPressed: () {
            if (GoRouter.of(context).canPop()) {
              GoRouter.of(context).pop();
            } else {
              context.go(AppRoutes.selectVehicle);
            }
          },
        ),
        title: Text(
          dashboard.vehicleDisplayName.isNotEmpty &&
                  dashboard.vehicleDisplayName != 'No Vehicle'
              ? dashboard.vehicleDisplayName
              : dashboard.vehicleId,
          style: context.styles.appBarTitle,
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const _ConnectivityPanel(),
            // شريط التنبيه الأحمر
            if (connectionState.hasFailed)
              Container(
                color: AppColors.dangerRed,
                padding: const EdgeInsets.symmetric(
                  vertical: AppSpacing.md,
                  horizontal: AppSpacing.md,
                ),
                child: Text(
                  connectionState.errorMessage ?? '${context.loc.unableToConnect} "${_macController.text}".',
                  style: context.styles.button,
                  textAlign: TextAlign.center,
                ),
              ),

            Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (connectionState.hasFailed) ...[
                    // عنوان قائمة التحقق
                    Text(
                      context.loc.verifyFollowingItems,
                      style: context.styles.body,
                    ),
                    const SizedBox(height: AppSpacing.md),
                    _buildChecklistItem(context.loc.macEnteredCorrectly),
                    _buildChecklistItem(context.loc.hardwareProperlyInstalled),
                    _buildChecklistItem(context.loc.vehiclePowerOn),
                    _buildChecklistItem(context.loc.bluetoothEnabled),
                    _buildChecklistItem(context.loc.gpsEnabled),
                    const SizedBox(height: AppSpacing.lg),
                    Divider(color: Theme.of(context).dividerColor, height: 1),
                    const SizedBox(height: AppSpacing.lg),
                  ] else ...[
                    const SizedBox(height: AppSpacing.xl),
                  ],

                  // عنوان حقل MAC
                  Text(
                    context.loc.enterMacAddress,
                    style: context.styles.body,
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ✅ حقل إدخال موحد
                  AppTextField(
                    controller: _macController,
                    hint: 'AA:BB:CC:DD:EE:FF',
                    isUnderlined: true,
                    keyboardType: TextInputType.text,
                  ),

                  const SizedBox(height: AppSpacing.xl),

                  // ✅ زر اتصال
                  AppButton(
                    label: context.loc.connect,
                    type: EldButtonType.connect,
                    isLoading: connectionState.isConnecting,
                    onPressed: connectionState.isConnecting
                        ? null
                        : _attemptConnection,
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ✅ زر متابعة بدون اتصال
                  AppButton(
                    label: context.loc.continueDisconnected,
                    type: EldButtonType.continueDisconnected,
                    onPressed: connectionState.isConnecting
                        ? null
                        : () => ref
                            .read(eldConnectionProvider.notifier)
                            .continueDisconnected(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ✅ بناء عنصر القائمة بشكل صحيح
  Widget _buildChecklistItem(String text) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: AppSpacing.sm,
        left: AppSpacing.sm,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ✅ نقطة بسيطة بدلاً من CircleAvatar
          const Padding(
            padding: EdgeInsets.only(top: 8.0, right: AppSpacing.sm),
            child: Icon(
              Icons.circle,
              size: 6,
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: context.styles.subtitle,
            ),
          ),
        ],
      ),
    );
  }
}

class _ConnectivityPanel extends ConsumerWidget {
  const _ConnectivityPanel();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isArabic = Localizations.localeOf(context).languageCode == 'ar';
    final status = ref.watch(hardwareStatusProvider);
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, 0),
      child: status.when(
        loading: () => Text(
          isArabic ? 'جارٍ قراءة حالة الاتصال...' : 'Reading connection status...',
          style: context.styles.body,
        ),
        error: (error, _) => Text(
          isArabic
              ? 'تعذر قراءة حالة الاتصال: $error'
              : 'Connection status could not be read: $error',
          style: context.styles.error,
        ),
        data: (data) => _statusBody(context, data, isArabic),
      ),
    );
  }

  Widget _statusBody(BuildContext context, ConnectivityStatus data, bool isArabic) {
    final lines = <String>[
      _statusLine(data, isArabic),
      if (data.hasDiagnostic)
        isArabic
            ? 'تشخيص: ${data.diagnostics.join(', ')}'
            : 'Diagnostic: ${data.diagnostics.join(', ')}',
      if (data.malfunctions.isNotEmpty)
        isArabic
            ? 'عطل: ${data.malfunctions.join(', ')}'
            : 'Malfunction: ${data.malfunctions.join(', ')}',
      if (data.dataAgeSeconds != null)
        isArabic
            ? 'عمر البيانات: ${data.dataAgeSeconds} ثانية'
            : 'Data age: ${data.dataAgeSeconds} seconds',
      if (data.normalOperationAllowed == false)
        isArabic ? 'غير جاهز للتشغيل الطبيعي.' : 'Not ready for normal operation.',
      if (data.isReliable == false)
        isArabic ? 'البيانات غير موثوقة.' : 'Data is not reliable.',
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final line in lines)
          Padding(
            padding: const EdgeInsets.only(bottom: AppSpacing.xs),
            child: Text(line, style: context.styles.body),
          ),
      ],
    );
  }

  String _statusLine(ConnectivityStatus data, bool isArabic) {
    switch (data.connectionStatus?.toUpperCase()) {
      case 'CONNECTED':
        return isArabic ? 'متصل' : 'Connected';
      case 'DISCONNECTED':
        return isArabic ? 'غير متصل' : 'Disconnected';
      case 'UNAVAILABLE':
        return isArabic ? 'غير متاح' : 'Unavailable';
      case 'MALFUNCTION':
        return isArabic ? 'عطل' : 'Malfunction';
      case null:
        return isArabic
            ? 'الخادم لم يُرجع حالة اتصال.'
            : 'The server did not return a connection status.';
      default:
        return data.connectionStatus!;
    }
  }
}

